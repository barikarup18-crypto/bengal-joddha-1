import React from 'react';
import { QUICK_FALLBACK_PROMPTS } from '../game/apsaraSystem';
import { ApsaraVoiceState } from '../game/types';
import { ApsaraSilhouette } from './ApsaraSilhouette';

interface ApsaraStageProps {
  voiceState: ApsaraVoiceState;
  speechText: string;
  transcript: string;
  voiceMuted: boolean;
  micNotice: string | null;
  auraBoosted: boolean;
  onToggleListen: () => void;
  onToggleVoiceMute: () => void;
  onSendPrompt: (utterance: string) => void;
}

export const ApsaraStage: React.FC<ApsaraStageProps> = ({
  voiceState,
  speechText,
  transcript,
  voiceMuted,
  micNotice,
  auraBoosted,
  onToggleListen,
  onToggleVoiceMute,
  onSendPrompt,
}) => {
  const isListening = voiceState === 'listening';
  const isSpeaking = voiceState === 'speaking';

  return (
    <div className="pointer-events-auto flex max-h-full w-[156px] shrink-0 flex-col items-center justify-center sm:w-[238px] [@media(max-height:520px)]:w-[196px]">
      {/* Animated Bengali Speech Bubble */}
      <div
        className={`relative mb-1.5 w-full rounded-2xl border px-2.5 py-1.5 text-left shadow-[0_10px_28px_rgba(0,0,0,0.58)] transition-colors duration-200 sm:mb-2 sm:px-3.5 sm:py-2 [@media(max-height:520px)]:mb-1 [@media(max-height:520px)]:px-2.5 [@media(max-height:520px)]:py-1.5 ${
          isListening
            ? 'border-[#63eaff]/75 bg-[#0e1b26]/92'
            : isSpeaking
              ? 'border-[#ffd974]/80 bg-[#18131d]/94'
              : 'border-[#73d9ec]/45 bg-[#12131b]/90'
        }`}
      >
        {/* Top Header Row inside Speech Bubble: Name + Speaker Mute/Unmute */}
        <div className="mb-0.5 flex items-center justify-between gap-2 sm:mb-1">
          <div className="flex items-center gap-1.5">
            <span className="font-bengali-display text-xs font-bold tracking-wide text-[#ffe082] sm:text-sm">
              অপ্সরা
            </span>
            <span className="font-bengali-ui text-[10px] font-medium text-[#7fe6f8]">
              {isListening ? 'শুনছি...' : isSpeaking ? 'বলছে' : 'ছায়া সঙ্গিনী'}
            </span>
          </div>

          <button
            type="button"
            onClick={onToggleVoiceMute}
            aria-label={voiceMuted ? 'অপ্সরার কণ্ঠ চালু করুন' : 'অপ্সরার কণ্ঠ মিউট করুন'}
            title={voiceMuted ? 'কণ্ঠ চালু করুন' : 'কণ্ঠ বন্ধ করুন'}
            className={`flex h-7 w-7 shrink-0 items-center justify-center rounded-lg border transition-colors ${
              voiceMuted
                ? 'border-[#e07068]/50 bg-[#2e1717] text-[#ffb0aa]'
                : 'border-[#6ee0f5]/45 bg-[#132533] text-[#a6f0ff] hover:bg-[#1a3347]'
            }`}
          >
            {voiceMuted ? (
              <svg viewBox="0 0 24 24" className="h-3.5 w-3.5 fill-none stroke-current stroke-2">
                <path d="M11 5L6 9H2v6h4l5 4V5z" strokeLinejoin="round" />
                <line x1="22" y1="9" x2="16" y2="15" strokeLinecap="round" />
                <line x1="16" y1="9" x2="22" y2="15" strokeLinecap="round" />
              </svg>
            ) : (
              <svg viewBox="0 0 24 24" className="h-3.5 w-3.5 fill-none stroke-current stroke-2">
                <path d="M11 5L6 9H2v6h4l5 4V5z" strokeLinejoin="round" />
                <path d="M15.5 8.5a5 5 0 0 1 0 7" strokeLinecap="round" />
                <path d="M18.8 5.5a9 9 0 0 1 0 13" strokeLinecap="round" />
              </svg>
            )}
          </button>
        </div>

        {/* Speech Bubble Copy */}
        <p className="font-bengali-ui line-clamp-2 text-[10px] leading-snug text-[#f2efe8] sm:line-clamp-3 sm:text-xs [@media(max-height:520px)]:line-clamp-2 [@media(max-height:520px)]:text-[10px]">
          {isListening && transcript ? `“${transcript}”` : speechText}
        </p>

        {micNotice && (
          <div
            role="status"
            className="font-bengali-ui mt-1 rounded-xl border border-amber-400/60 bg-amber-950/75 px-2 py-1 text-[10px] font-semibold leading-snug text-amber-200"
          >
            {micNotice}
          </div>
        )}

        {/* Speech Bubble Tail Pointer */}
        <div
          className={`absolute -bottom-1.5 left-1/2 h-3 w-3 -translate-x-1/2 rotate-45 border-b border-r ${
            isListening
              ? 'border-[#63eaff]/75 bg-[#0e1b26]'
              : isSpeaking
                ? 'border-[#ffd974]/80 bg-[#18131d]'
                : 'border-[#73d9ec]/45 bg-[#12131b]'
          }`}
        />
      </div>

      {/* Mysterious Dark Shadow Silhouette of অপ্সরা */}
      <ApsaraSilhouette voiceState={voiceState} size="lobby" auraBoosted={auraBoosted} />

      {/* Prominent Pulsing Microphone Button Below Her Shadow Figure */}
      <div className="relative mt-1 flex w-full justify-center">
        <span
          aria-hidden="true"
          className={`pointer-events-none absolute inset-0 rounded-full border-2 ${
            isListening
              ? 'apsara-mic-ripple-fast border-[#66f0ff]/85'
              : 'apsara-mic-ripple border-[#ffd56b]/60'
          }`}
        />
        <button
          type="button"
          onClick={onToggleListen}
          aria-pressed={isListening}
          className={`font-bengali-ui relative flex w-full items-center justify-center gap-1.5 whitespace-nowrap rounded-full border-2 px-2.5 py-1.5 text-[11px] font-bold shadow-[0_8px_22px_rgba(0,0,0,0.58)] transition-transform active:scale-95 sm:gap-2 sm:px-4 sm:py-2 sm:text-sm [@media(max-height:520px)]:py-1.5 [@media(max-height:520px)]:text-[11px] ${
            isListening
              ? 'border-[#9af7ff] bg-gradient-to-r from-[#0e5a78] via-[#1785a8] to-[#0e5a78] text-[#ffffff]'
              : 'border-[#ffe28a] bg-gradient-to-r from-[#23192e] via-[#1c2f42] to-[#23192e] text-[#fff3d2] hover:brightness-110'
          }`}
        >
          <span aria-hidden="true" className="text-xs sm:text-base">
            🎤
          </span>
          <span className="truncate">
            {isListening ? 'শুনছি... (থামতে ট্যাপ)' : 'অপ্সরার সাথে কথা বলুন'}
          </span>
        </button>
      </div>

      {/* Quick-Tap Fallback Prompt Pills (immediately speak Apsara's female voice reply out loud) */}
      <div className="mt-1.5 grid w-full grid-cols-2 gap-1 sm:mt-2 sm:gap-1.5 [@media(max-height:460px)]:hidden">
        {QUICK_FALLBACK_PROMPTS.slice(0, 4).map((item) => (
          <button
            key={item.label}
            type="button"
            onClick={() => onSendPrompt(item.utterance)}
            className="font-bengali-ui truncate rounded-full border border-amber-400/45 bg-black/50 px-2 py-1 text-[10px] font-semibold text-[#e2f3fa] backdrop-blur-md transition-colors hover:border-[#ffd773]/80 hover:bg-[#1c2233] hover:text-[#fff2cc] active:scale-95 sm:px-2.5 sm:text-[11px]"
          >
            {item.label}
          </button>
        ))}
      </div>
    </div>
  );
};
