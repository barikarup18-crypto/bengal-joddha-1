import React from 'react';
import { ApsaraVoiceState } from '../game/types';

interface ApsaraSilhouetteProps {
  voiceState: ApsaraVoiceState;
  size?: 'lobby' | 'compact';
  auraBoosted?: boolean;
}

/**
 * Graceful, mysterious obsidian shadow silhouette of "অপ্সরা" (Apsara):
 * - Strictly no visible facial features (no nose, mouth, or facial lines)
 * - Soft golden-cyan ethereal aura halo + subtle glowing eyes
 * - Flowing hair outline that pulses & sways in sync when speaking or listening
 */
export const ApsaraSilhouette: React.FC<ApsaraSilhouetteProps> = ({
  voiceState,
  size = 'lobby',
  auraBoosted = false,
}) => {
  const isSpeaking = voiceState === 'speaking';
  const isListening = voiceState === 'listening';
  const isCompact = size === 'compact';

  const dimensions = isCompact
    ? 'h-[86px] w-[76px]'
    : 'h-[136px] w-[118px] sm:h-[186px] sm:w-[160px] [@media(max-height:520px)]:h-[82px] [@media(max-height:520px)]:w-[70px]';

  return (
    <div
      className={`relative flex shrink-0 items-center justify-center ${dimensions}`}
      aria-label="অপ্সরা ছায়া সঙ্গিনী"
    >
      {/* Outer Golden-Cyan Ethereal Aura Corona */}
      <div
        className={`pointer-events-none absolute inset-[-10%] rounded-full ${
          isSpeaking ? 'apsara-aura-speaking' : 'apsara-aura-idle'
        }`}
        style={{
          background: isListening
            ? 'radial-gradient(circle at 50% 42%, rgba(74, 232, 255, 0.44) 0%, rgba(248, 198, 92, 0.24) 46%, rgba(16, 22, 32, 0) 74%)'
            : auraBoosted
              ? 'radial-gradient(circle at 50% 42%, rgba(255, 214, 102, 0.46) 0%, rgba(70, 226, 255, 0.28) 48%, rgba(14, 18, 28, 0) 76%)'
              : 'radial-gradient(circle at 50% 42%, rgba(245, 198, 92, 0.34) 0%, rgba(62, 216, 248, 0.22) 48%, rgba(14, 18, 28, 0) 75%)',
        }}
      />

      {/* Sculpted Vector Shadow Figure */}
      <svg
        viewBox="0 0 200 240"
        className="relative h-full w-full overflow-visible"
        role="img"
        aria-label="অপ্সরার রহস্যময় ছায়ামূর্তি"
      >
        <defs>
          <radialGradient id="apsaraAuraGrad" cx="50%" cy="42%" r="54%">
            <stop offset="0%" stopColor={isListening ? '#58ecff' : '#ffd977'} stopOpacity="0.6" />
            <stop offset="52%" stopColor={isListening ? '#2bbbe0' : '#45d7f2'} stopOpacity="0.22" />
            <stop offset="100%" stopColor="#090c14" stopOpacity="0" />
          </radialGradient>

          <linearGradient id="apsaraRimGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#ffe188" stopOpacity={isSpeaking ? '0.95' : '0.72'} />
            <stop offset="50%" stopColor="#5ce6ff" stopOpacity={isSpeaking || isListening ? '0.92' : '0.62'} />
            <stop offset="100%" stopColor="#f5be58" stopOpacity="0.78" />
          </linearGradient>

          <linearGradient id="apsaraShadowBody" x1="50%" y1="0%" x2="50%" y2="100%">
            <stop offset="0%" stopColor="#0a0c14" />
            <stop offset="55%" stopColor="#07080f" />
            <stop offset="100%" stopColor="#05060b" stopOpacity="0.92" />
          </linearGradient>

          <filter id="apsaraEyeGlow" x="-60%" y="-60%" width="220%" height="220%">
            <feGaussianBlur stdDeviation="2.6" result="blur" />
            <feMerge>
              <feMergeNode in="blur" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>

          <filter id="apsaraRimGlow" x="-25%" y="-25%" width="150%" height="150%">
            <feGaussianBlur stdDeviation={isSpeaking ? '4.5' : '2.8'} result="glow" />
            <feMerge>
              <feMergeNode in="glow" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>
        </defs>

        {/* Soft Ethereal Crescent Halo behind Head */}
        <circle
          cx="100"
          cy="94"
          r={isSpeaking ? '72' : '64'}
          fill="url(#apsaraAuraGrad)"
        />
        <circle
          cx="100"
          cy="78"
          r={auraBoosted ? '52' : '46'}
          fill="none"
          stroke="url(#apsaraRimGrad)"
          strokeWidth={isSpeaking ? '2' : '1.2'}
          strokeDasharray="6 6"
          opacity={isSpeaking || isListening ? '0.88' : '0.45'}
        />

        {/* Flowing Hair Outline Ribbons (pulses & sways dynamically when speaking) */}
        <g className={isSpeaking ? 'apsara-hair-speaking' : 'apsara-hair-idle'}>
          {/* Left Flowing Hair Veil */}
          <path
            d="M 74 44 C 46 58, 30 96, 36 144 C 40 174, 24 198, 16 218 C 36 208, 56 188, 62 158 C 66 136, 70 118, 76 104 Z"
            fill="url(#apsaraShadowBody)"
            stroke="url(#apsaraRimGrad)"
            strokeWidth={isSpeaking ? '2.2' : '1.4'}
            filter="url(#apsaraRimGlow)"
          />
          {/* Right Flowing Hair Veil */}
          <path
            d="M 126 44 C 154 58, 170 96, 164 144 C 160 174, 176 198, 184 218 C 164 208, 144 188, 138 158 C 134 136, 130 118, 124 104 Z"
            fill="url(#apsaraShadowBody)"
            stroke="url(#apsaraRimGrad)"
            strokeWidth={isSpeaking ? '2.2' : '1.4'}
            filter="url(#apsaraRimGlow)"
          />
          {/* Delicate Outer Hair Wisps */}
          <path
            d="M 60 66 C 34 84, 24 126, 30 170"
            fill="none"
            stroke="#5ce8ff"
            strokeWidth={isSpeaking ? '2' : '1.2'}
            strokeLinecap="round"
            opacity={isSpeaking ? '0.88' : '0.45'}
          />
          <path
            d="M 140 66 C 166 84, 176 126, 170 170"
            fill="none"
            stroke="#ffd874"
            strokeWidth={isSpeaking ? '2' : '1.2'}
            strokeLinecap="round"
            opacity={isSpeaking ? '0.88' : '0.45'}
          />
          {/* Ethereal Hair Crown / Flowing Top Crest */}
          <path
            d="M 68 54 C 76 26, 124 26, 132 54 C 144 68, 152 94, 146 126 C 136 102, 128 84, 122 66 C 110 52, 90 52, 78 66 C 72 84, 64 102, 54 126 C 48 94, 56 68, 68 54 Z"
            fill="url(#apsaraShadowBody)"
            stroke="url(#apsaraRimGrad)"
            strokeWidth="1.3"
          />
        </g>

        {/* Graceful Shadow Head, Neck & Draped Ethereal Shoulders (zero facial features) */}
        <path
          d="M 100 44
             C 82 44, 71 58, 72 78
             C 73 95, 84 108, 92 114
             L 91 127
             C 72 132, 52 146, 42 174
             C 36 192, 34 212, 32 230
             L 168 230
             C 166 212, 164 192, 158 174
             C 148 146, 128 132, 109 127
             L 108 114
             C 116 108, 127 95, 128 78
             C 129 58, 118 44, 100 44 Z"
          fill="url(#apsaraShadowBody)"
          stroke="url(#apsaraRimGrad)"
          strokeWidth={isSpeaking ? '2.1' : '1.5'}
          filter="url(#apsaraRimGlow)"
        />

        {/* Subtle Draped Ethereal Shawl Line (pure silhouette contour) */}
        <path
          d="M 60 156 Q 100 182 140 156"
          fill="none"
          stroke="url(#apsaraRimGrad)"
          strokeWidth="1.2"
          opacity="0.58"
        />
        <path
          d="M 48 192 Q 100 214 152 192"
          fill="none"
          stroke="#5be6ff"
          strokeWidth="1"
          opacity="0.34"
        />

        {/* Subtle Glowing Eyes Only (no nose, no mouth, purely luminous slits) */}
        <g filter="url(#apsaraEyeGlow)">
          <path
            d="M 82 77 Q 88 73.5 94 77 Q 88 79.8 82 77 Z"
            fill={isListening ? '#7cf7ff' : '#ffe38c'}
            opacity={isSpeaking || isListening ? '1' : '0.88'}
          />
          <path
            d="M 106 77 Q 112 73.5 118 77 Q 112 79.8 106 77 Z"
            fill={isListening ? '#7cf7ff' : '#ffe38c'}
            opacity={isSpeaking || isListening ? '1' : '0.88'}
          />
          <circle cx="88" cy="76.8" r="1.35" fill="#ffffff" />
          <circle cx="112" cy="76.8" r="1.35" fill="#ffffff" />
        </g>

        {/* Subtle Golden Forehead Crescent Mark (mystical Bengal motif, not a facial feature) */}
        {auraBoosted && (
          <path
            d="M 96 63 Q 100 66.5 104 63 Q 100 64.2 96 63 Z"
            fill="#ffd966"
            opacity="0.9"
          />
        )}

        {/* Voice Resonance Wave Arcs at Base when Speaking or Listening */}
        {(isSpeaking || isListening) && (
          <g>
            <path
              d="M 62 222 Q 100 236 138 222"
              fill="none"
              stroke={isListening ? '#6bf0ff' : '#ffd86b'}
              strokeWidth="2.4"
              strokeLinecap="round"
              opacity="0.9"
            />
            <path
              d="M 44 230 Q 100 248 156 230"
              fill="none"
              stroke={isListening ? '#32c7e8' : '#58e3ff'}
              strokeWidth="1.6"
              strokeLinecap="round"
              opacity="0.65"
            />
          </g>
        )}
      </svg>
    </div>
  );
};
