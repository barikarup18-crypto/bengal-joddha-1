import React from 'react';
import { toBengaliNumber } from '../game/GameEngine';
import {
  ApsaraProgressState,
  ApsaraVoiceState,
  HudSnapshot,
  MissionId,
} from '../game/types';
import { ApsaraSilhouette } from './ApsaraSilhouette';

interface StatusModalProps {
  hud: HudSnapshot;
  progress: ApsaraProgressState;
  apsaraVoiceState: ApsaraVoiceState;
  apsaraSpeechText: string;
  apsaraTranscript: string;
  apsaraVoiceMuted: boolean;
  apsaraMicNotice?: string | null;
  onToggleApsaraListen: () => void;
  onToggleApsaraVoiceMute: () => void;
  onSendApsaraPrompt: (utterance: string) => void;
  onClaimMissionReward: (missionId: MissionId) => void;
  onResume: () => void;
  onRestart: () => void;
  onMainMenu: () => void;
}

export const StatusModal: React.FC<StatusModalProps> = ({
  hud,
  progress,
  apsaraVoiceState,
  apsaraSpeechText,
  apsaraTranscript,
  apsaraVoiceMuted,
  apsaraMicNotice,
  onToggleApsaraListen,
  onToggleApsaraVoiceMute,
  onSendApsaraPrompt,
  onClaimMissionReward,
  onResume,
  onRestart,
  onMainMenu,
}) => {
  if (hud.phase !== 'paused' && hud.phase !== 'gameover') return null;

  const isGameOver = hud.phase === 'gameover';
  const totalShotsHit = hud.headshots + hud.bodyshots;
  const headshotRate =
    totalShotsHit > 0 ? Math.round((hud.headshots / totalShotsHit) * 100) : 0;
  const isListening = apsaraVoiceState === 'listening';

  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center overflow-y-auto bg-[#120b08]/84 pb-[max(1rem,env(safe-area-inset-bottom))] pl-[max(1rem,env(safe-area-inset-left))] pr-[max(1rem,env(safe-area-inset-right))] pt-[max(1rem,env(safe-area-inset-top))]">
      <div className="my-auto w-full max-w-lg rounded-2xl border border-[#e8ba68]/55 bg-[#20140e] p-5 text-center shadow-[0_20px_60px_rgba(0,0,0,0.75)] sm:p-6">
        {/* Gamcha decorative top trim */}
        <div className="mx-auto mb-3 flex h-1.5 w-32 overflow-hidden rounded-full border border-[#5e2418]">
          <div className="flex-1 bg-[#c41e25]" />
          <div className="flex-1 bg-[#faf2e3]" />
          <div className="flex-1 bg-[#c41e25]" />
          <div className="flex-1 bg-[#faf2e3]" />
          <div className="flex-1 bg-[#c41e25]" />
        </div>

        <h2 className="font-bengali-display text-2xl font-bold text-[#ffd87d] sm:text-3xl">
          {isGameOver ? 'খেলা শেষ' : 'খেলা বিরতি'}
        </h2>
        <p className="font-bengali-ui mt-1 text-xs text-[#e3cbb0] sm:text-sm">
          {isGameOver
            ? 'হুগলির তীর রক্ষায় আপনি বীরত্বের সাথে লড়েছেন!'
            : 'আবার যুদ্ধ শুরু করতে প্রস্তুত?'}
        </p>

        {/* Primary Stats Grid */}
        <div className="mt-4 grid grid-cols-3 gap-2 rounded-xl border border-[#e7b96b]/25 bg-[#150d09] p-3">
          <div>
            <div className="font-bengali-ui text-xs text-[#c7a882]">স্কোর</div>
            <div className="font-bengali-ui tabular-nums mt-0.5 text-lg font-bold text-[#ffe296] sm:text-xl">
              {toBengaliNumber(hud.score)}
            </div>
          </div>
          <div>
            <div className="font-bengali-ui text-xs text-[#c7a882]">তরঙ্গ</div>
            <div className="font-bengali-ui tabular-nums mt-0.5 text-lg font-bold text-[#f9ebd4] sm:text-xl">
              {toBengaliNumber(hud.wave)}
            </div>
          </div>
          <div>
            <div className="font-bengali-ui text-xs text-[#c7a882]">পরাজিত শত্রু</div>
            <div className="font-bengali-ui tabular-nums mt-0.5 text-lg font-bold text-[#ff846e] sm:text-xl">
              {toBengaliNumber(hud.kills)}
            </div>
          </div>
        </div>

        {/* Headshot & Body Shot Breakdown */}
        <div className="mt-2 grid grid-cols-2 gap-2 rounded-xl border border-[#e7b96b]/22 bg-[#170f0a] px-3 py-2">
          <div className="flex flex-col items-center">
            <div className="font-bengali-ui text-xs font-semibold text-[#ff7c75]">মোট হেডশট</div>
            <div className="font-bengali-ui tabular-nums mt-0.5 text-lg font-extrabold text-[#ff4b4b] sm:text-xl">
              {toBengaliNumber(hud.headshots)}
            </div>
          </div>
          <div className="flex flex-col items-center border-l border-[#e7b96b]/20">
            <div className="font-bengali-ui text-xs font-semibold text-[#f3cf7c]">মোট বডিশট</div>
            <div className="font-bengali-ui tabular-nums mt-0.5 text-lg font-extrabold text-[#ffe9b3] sm:text-xl">
              {toBengaliNumber(hud.bodyshots)}
            </div>
          </div>
        </div>

        {/* Apsara Match Summary Voice Companion & Cross-Match Mission Rewards */}
        {isGameOver && (
          <>
            <div className="mt-3.5 flex items-center gap-3 rounded-xl border border-[#6adcf2]/40 bg-[#111520] p-3 text-left">
              <ApsaraSilhouette
                voiceState={apsaraVoiceState}
                size="compact"
                auraBoosted={progress.auraBoostUnlocked}
              />

              <div className="min-w-0 flex-1">
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-1.5">
                    <span className="font-bengali-display text-sm font-bold text-[#ffe082]">
                      অপ্সরা
                    </span>
                    <span className="font-bengali-ui text-[10px] text-[#7fe6f8]">
                      {isListening
                        ? 'শুনছি...'
                        : apsaraVoiceState === 'speaking'
                          ? 'ম্যাচ বিশ্লেষণ বলছে'
                          : 'ছায়া সঙ্গিনী'}
                    </span>
                  </div>

                  <button
                    type="button"
                    onClick={onToggleApsaraVoiceMute}
                    aria-label={apsaraVoiceMuted ? 'অপ্সরার কণ্ঠ চালু করুন' : 'অপ্সরার কণ্ঠ বন্ধ করুন'}
                    className={`flex h-7 w-7 shrink-0 items-center justify-center rounded-lg border ${
                      apsaraVoiceMuted
                        ? 'border-[#e07068]/50 bg-[#2e1717] text-[#ffb0aa]'
                        : 'border-[#6ee0f5]/45 bg-[#132533] text-[#a6f0ff]'
                    }`}
                  >
                    {apsaraVoiceMuted ? (
                      <svg viewBox="0 0 24 24" className="h-3.5 w-3.5 fill-none stroke-current stroke-2">
                        <path d="M11 5L6 9H2v6h4l5 4V5z" strokeLinejoin="round" />
                        <line x1="22" y1="9" x2="16" y2="15" strokeLinecap="round" />
                        <line x1="16" y1="9" x2="22" y2="15" strokeLinecap="round" />
                      </svg>
                    ) : (
                      <svg viewBox="0 0 24 24" className="h-3.5 w-3.5 fill-none stroke-current stroke-2">
                        <path d="M11 5L6 9H2v6h4l5 4V5z" strokeLinejoin="round" />
                        <path d="M15.5 8.5a5 5 0 0 1 0 7" strokeLinecap="round" />
                      </svg>
                    )}
                  </button>
                </div>

                <p className="font-bengali-ui mt-1 text-xs leading-relaxed text-[#f2efe8]">
                  {isListening && apsaraTranscript ? `“${apsaraTranscript}”` : apsaraSpeechText}
                </p>

                {apsaraMicNotice && (
                  <p className="font-bengali-ui mt-1.5 rounded-xl border border-amber-400/55 bg-amber-950/70 px-2.5 py-1 text-[10px] font-semibold text-amber-200">
                    {apsaraMicNotice}
                  </p>
                )}

                <div className="mt-2 flex flex-wrap items-center gap-1.5">
                  <button
                    type="button"
                    onClick={onToggleApsaraListen}
                    className={`font-bengali-ui flex items-center gap-1 rounded-full border px-3 py-1 text-[11px] font-bold transition-colors ${
                      isListening
                        ? 'border-[#8df5ff] bg-[#146c8c] text-white'
                        : 'border-[#ffd973]/65 bg-[#231d29] text-[#ffe8a6] hover:bg-[#30263a]'
                    }`}
                  >
                    <span aria-hidden="true">🎤</span>
                    <span>{isListening ? 'শুনছি...' : 'কথা বলুন'}</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => onSendApsaraPrompt('তুমি কেমন আছো?')}
                    className="font-bengali-ui rounded-full border border-amber-400/45 bg-black/45 px-2.5 py-1 text-[10px] font-semibold text-[#d9f3ff] hover:border-[#ffd973]/75"
                  >
                    তুমি কেমন আছো?
                  </button>
                  <button
                    type="button"
                    onClick={() => onSendApsaraPrompt('জেতার টিপস দাও')}
                    className="font-bengali-ui rounded-full border border-amber-400/45 bg-black/45 px-2.5 py-1 text-[10px] font-semibold text-[#d9f3ff] hover:border-[#ffd973]/75"
                  >
                    জেতার টিপস দাও
                  </button>
                </div>
              </div>
            </div>

            {/* Cross-Match Missions Progress & Instant Claim */}
            <div className="mt-3 rounded-xl border border-[#e7b96b]/25 bg-[#160e0a] p-3 text-left">
              <div className="mb-2 flex items-center justify-between">
                <span className="font-bengali-ui text-xs font-bold text-[#ffd978]">
                  অপ্সরার চ্যালেঞ্জ অগ্রগতি
                </span>
                <span className="font-bengali-ui tabular-nums text-[11px] font-bold text-[#ffe59e]">
                  স্বর্ণমুদ্রা: {toBengaliNumber(progress.goldCoins)}
                </span>
              </div>
              <div className="space-y-2">
                {progress.missions.map((mission) => {
                  const pct = Math.min(100, Math.round((mission.progress / mission.target) * 100));
                  const completed = mission.progress >= mission.target;
                  const canClaim = completed && !mission.claimed;
                  return (
                    <div key={mission.id} className="flex items-center gap-2">
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center justify-between text-[11px]">
                          <span className="font-bengali-ui truncate font-semibold text-[#f5e6cb]">
                            {mission.title}
                          </span>
                          <span className="font-bengali-ui tabular-nums ml-2 text-[10px] text-[#d9bc91]">
                            {toBengaliNumber(mission.progress)}/{toBengaliNumber(mission.target)}
                          </span>
                        </div>
                        <div className="mt-1 h-1.5 w-full overflow-hidden rounded-full bg-[#312117]">
                          <div
                            style={{ width: `${pct}%` }}
                            className={`h-full rounded-full ${
                              mission.claimed
                                ? 'bg-[#45d982]'
                                : completed
                                  ? 'bg-gradient-to-r from-[#ffd645] to-[#63e8ff]'
                                  : 'bg-[#e8a435]'
                            }`}
                          />
                        </div>
                      </div>
                      {canClaim ? (
                        <button
                          type="button"
                          onClick={() => onClaimMissionReward(mission.id)}
                          className="font-bengali-ui shrink-0 whitespace-nowrap rounded-lg border border-[#fff2b2] bg-gradient-to-b from-[#ffe047] to-[#d98406] px-2.5 py-1 text-[11px] font-extrabold text-[#241205] shadow-[0_0_12px_rgba(255,202,48,0.5)]"
                        >
                          উপহার নিন
                        </button>
                      ) : (
                        <span className="font-bengali-ui shrink-0 text-[10px] font-bold text-[#95b89d]">
                          {mission.claimed ? 'সংগৃহীত' : `+${toBengaliNumber(mission.rewardCoins)}`}
                        </span>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="mt-2.5 flex flex-wrap items-center justify-center gap-x-4 gap-y-1 text-xs font-semibold text-[#e6c48a]">
              {hud.highScore > 0 && (
                <span>
                  সেরা স্কোর:{' '}
                  <span className="tabular-nums text-[#ffd26a]">{toBengaliNumber(hud.highScore)}</span>
                </span>
              )}
              {totalShotsHit > 0 && (
                <span>
                  হেডশট হার:{' '}
                  <span className="tabular-nums text-[#ff8e88]">{toBengaliNumber(headshotRate)}%</span>
                </span>
              )}
            </div>
          </>
        )}

        {/* Action Buttons */}
        <div className="mt-4 flex flex-col gap-2">
          {!isGameOver ? (
            <button
              type="button"
              onClick={onResume}
              className="font-bengali-ui w-full rounded-xl border border-[#ffe199] bg-[#c42027] py-2.5 text-base font-bold text-[#fff6e6] shadow hover:bg-[#d6262e]"
            >
              খেলা চালিয়ে যান
            </button>
          ) : (
            <button
              type="button"
              onClick={onRestart}
              className="font-bengali-ui w-full rounded-xl border border-[#ffe199] bg-[#c42027] py-2.5 text-base font-bold text-[#fff6e6] shadow hover:bg-[#d6262e]"
            >
              আবার খেলুন
            </button>
          )}

          {!isGameOver && (
            <button
              type="button"
              onClick={onRestart}
              className="font-bengali-ui w-full rounded-xl border border-[#e7b96b]/45 bg-[#2e1e15] py-2 text-sm font-semibold text-[#f8e6c8] hover:bg-[#3d291d]"
            >
              নতুন করে শুরু করুন
            </button>
          )}

          <button
            type="button"
            onClick={onMainMenu}
            className="font-bengali-ui w-full rounded-xl border border-[#e7b96b]/30 bg-transparent py-2 text-sm font-semibold text-[#d9bfa0] hover:bg-[#2a1b13]"
          >
            মূল মেনু
          </button>
        </div>
      </div>
    </div>
  );
};
