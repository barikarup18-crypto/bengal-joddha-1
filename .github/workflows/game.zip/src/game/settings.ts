export type GraphicsQuality = 'low' | 'medium' | 'high';

export type HudControlId =
  | 'joystick'
  | 'shoot'
  | 'scope'
  | 'reload'
  | 'sprint'
  | 'weapons'
  | 'sanjibani'
  | 'grenade';

export interface HudControlLayout {
  x: number; // viewport width % (4..96)
  y: number; // viewport height % (8..94)
  size: number; // scale multiplier (0.5..1.5)
  opacity: number; // opacity (0.3..1.0)
}

export type CustomHudLayout = Record<HudControlId, HudControlLayout>;

export interface GameSettings {
  generalSensitivity: number; // 0..100
  scopeSensitivity: number; // 0..100
  graphicsQuality: GraphicsQuality;
  sfxEnabled: boolean;
  sfxVolume: number; // 0..100
  customHud: CustomHudLayout;
}

export interface HudControlMeta {
  id: HudControlId;
  label: string;
  shortLabel: string;
}

export const HUD_CONTROL_ORDER: HudControlId[] = [
  'joystick',
  'shoot',
  'scope',
  'reload',
  'sprint',
  'weapons',
  'sanjibani',
  'grenade',
];

export const HUD_CONTROL_META: Record<HudControlId, HudControlMeta> = {
  joystick: { id: 'joystick', label: 'চলাচল জয়স্টিক', shortLabel: 'চলাচল' },
  shoot: { id: 'shoot', label: 'গুলি / আঘাত বাটন', shortLabel: 'গুলি' },
  scope: { id: 'scope', label: 'স্কোপ / জুম বাটন', shortLabel: 'স্কোপ' },
  reload: { id: 'reload', label: 'রিলোড বাটন', shortLabel: 'রিলোড' },
  sprint: { id: 'sprint', label: 'দৌড় বাটন', shortLabel: 'দৌড়' },
  weapons: { id: 'weapons', label: 'অস্ত্র বার', shortLabel: 'অস্ত্র বার' },
  sanjibani: { id: 'sanjibani', label: 'সঞ্জীবনী গাছ', shortLabel: 'সঞ্জীবনী' },
  grenade: { id: 'grenade', label: 'বজ্র গোলা', shortLabel: 'বজ্র গোলা' },
};

export const DEFAULT_CUSTOM_HUD: CustomHudLayout = {
  joystick: { x: 14, y: 74, size: 1.0, opacity: 0.92 },
  shoot: { x: 88, y: 74, size: 1.0, opacity: 0.95 },
  scope: { x: 88, y: 47, size: 1.0, opacity: 0.92 },
  reload: { x: 74, y: 60, size: 1.0, opacity: 0.9 },
  sprint: { x: 74, y: 79, size: 1.0, opacity: 0.9 },
  weapons: { x: 50, y: 91, size: 1.0, opacity: 0.94 },
  sanjibani: { x: 11, y: 46, size: 1.0, opacity: 0.92 },
  grenade: { x: 28, y: 46, size: 1.0, opacity: 0.92 },
};

export const DEFAULT_GAME_SETTINGS: GameSettings = {
  generalSensitivity: 50,
  scopeSensitivity: 45,
  graphicsQuality: 'medium',
  sfxEnabled: true,
  sfxVolume: 80,
  customHud: cloneCustomHud(DEFAULT_CUSTOM_HUD),
};

const STORAGE_KEY_SETTINGS = 'banglar_joddha_settings_v1';

function clamp(v: number, min: number, max: number): number {
  if (!Number.isFinite(v)) return min;
  return Math.max(min, Math.min(max, v));
}

export function clampHudControl(ctrl: HudControlLayout): HudControlLayout {
  return {
    x: Math.round(clamp(ctrl.x, 6, 94) * 10) / 10,
    y: Math.round(clamp(ctrl.y, 10, 92) * 10) / 10,
    size: Math.round(clamp(ctrl.size, 0.5, 1.5) * 100) / 100,
    opacity: Math.round(clamp(ctrl.opacity, 0.3, 1.0) * 100) / 100,
  };
}

export function cloneCustomHud(hud: CustomHudLayout): CustomHudLayout {
  const out = {} as CustomHudLayout;
  for (const id of HUD_CONTROL_ORDER) {
    out[id] = { ...hud[id] };
  }
  return out;
}

export function loadGameSettings(): GameSettings {
  try {
    const raw = localStorage.getItem(STORAGE_KEY_SETTINGS);
    if (!raw) {
      return {
        ...DEFAULT_GAME_SETTINGS,
        customHud: cloneCustomHud(DEFAULT_CUSTOM_HUD),
      };
    }
    const parsed = JSON.parse(raw) as Partial<GameSettings>;
    const quality: GraphicsQuality =
      parsed.graphicsQuality === 'low' ||
      parsed.graphicsQuality === 'medium' ||
      parsed.graphicsQuality === 'high'
        ? parsed.graphicsQuality
        : DEFAULT_GAME_SETTINGS.graphicsQuality;

    const customHud = cloneCustomHud(DEFAULT_CUSTOM_HUD);
    if (parsed.customHud && typeof parsed.customHud === 'object') {
      for (const id of HUD_CONTROL_ORDER) {
        const savedCtrl = parsed.customHud[id];
        if (savedCtrl && typeof savedCtrl === 'object') {
          customHud[id] = clampHudControl({
            x: typeof savedCtrl.x === 'number' ? savedCtrl.x : DEFAULT_CUSTOM_HUD[id].x,
            y: typeof savedCtrl.y === 'number' ? savedCtrl.y : DEFAULT_CUSTOM_HUD[id].y,
            size: typeof savedCtrl.size === 'number' ? savedCtrl.size : DEFAULT_CUSTOM_HUD[id].size,
            opacity:
              typeof savedCtrl.opacity === 'number'
                ? savedCtrl.opacity
                : DEFAULT_CUSTOM_HUD[id].opacity,
          });
        }
      }
    }

    return {
      generalSensitivity: Math.round(
        clamp(
          typeof parsed.generalSensitivity === 'number'
            ? parsed.generalSensitivity
            : DEFAULT_GAME_SETTINGS.generalSensitivity,
          0,
          100,
        ),
      ),
      scopeSensitivity: Math.round(
        clamp(
          typeof parsed.scopeSensitivity === 'number'
            ? parsed.scopeSensitivity
            : DEFAULT_GAME_SETTINGS.scopeSensitivity,
          0,
          100,
        ),
      ),
      graphicsQuality: quality,
      sfxEnabled:
        typeof parsed.sfxEnabled === 'boolean'
          ? parsed.sfxEnabled
          : DEFAULT_GAME_SETTINGS.sfxEnabled,
      sfxVolume: Math.round(
        clamp(
          typeof parsed.sfxVolume === 'number'
            ? parsed.sfxVolume
            : DEFAULT_GAME_SETTINGS.sfxVolume,
          0,
          100,
        ),
      ),
      customHud,
    };
  } catch {
    return {
      ...DEFAULT_GAME_SETTINGS,
      customHud: cloneCustomHud(DEFAULT_CUSTOM_HUD),
    };
  }
}

export function saveGameSettings(settings: GameSettings): void {
  try {
    localStorage.setItem(STORAGE_KEY_SETTINGS, JSON.stringify(settings));
  } catch {
    // Ignore private-mode or quota storage errors
  }
}
