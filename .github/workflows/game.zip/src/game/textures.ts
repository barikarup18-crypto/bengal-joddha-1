import * as THREE from 'three';

export interface TextureBundle {
  gamchaMap: THREE.CanvasTexture;
  gamchaGreenMap: THREE.CanvasTexture;
  mudWallMap: THREE.CanvasTexture;
  mudWallBump: THREE.CanvasTexture;
  thatchMap: THREE.CanvasTexture;
  groundMap: THREE.CanvasTexture;
  groundBump: THREE.CanvasTexture;
  palmBarkMap: THREE.CanvasTexture;
  frondMap: THREE.CanvasTexture;
  bridgeSteelMap: THREE.CanvasTexture;
  waterBump: THREE.CanvasTexture;
  contactShadowMap: THREE.CanvasTexture;
  skyMap: THREE.CanvasTexture;
  taxiSignMap: THREE.CanvasTexture;
  licensePlateMap: THREE.CanvasTexture;
  busSideMap: THREE.CanvasTexture;
  busDestinationMap: THREE.CanvasTexture;
  skinBumpMap: THREE.CanvasTexture;
  skinAlbedoMap: THREE.CanvasTexture;
  faceAlbedoMap: THREE.CanvasTexture;
  fabricBumpMap: THREE.CanvasTexture;
  disposeAll: () => void;
}

function makeCanvas(w: number, h: number): [HTMLCanvasElement, CanvasRenderingContext2D] {
  const canvas = document.createElement('canvas');
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext('2d')!;
  return [canvas, ctx];
}

function configureTexture(
  canvas: HTMLCanvasElement,
  anisotropy: number,
  isColor: boolean,
  repeatX = 1,
  repeatY = 1,
): THREE.CanvasTexture {
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = isColor ? THREE.SRGBColorSpace : THREE.NoColorSpace;
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(repeatX, repeatY);
  tex.anisotropy = anisotropy;
  tex.needsUpdate = true;
  return tex;
}

function createGamchaCanvas(variant: 'red-white' | 'green-white' = 'red-white'): HTMLCanvasElement {
  const [canvas, ctx] = makeCanvas(256, 256);
  // Traditional Bengali checkered handloom gamcha (red-white or green-white)
  ctx.fillStyle = '#faf5eb';
  ctx.fillRect(0, 0, 256, 256);

  // Subtle cotton weave base
  ctx.fillStyle = 'rgba(210, 195, 175, 0.25)';
  for (let i = 0; i < 256; i += 4) {
    ctx.fillRect(i, 0, 1, 256);
    ctx.fillRect(0, i, 256, 1);
  }

  const primary = variant === 'red-white' ? '#c41e25' : '#1b7a3d';
  const bright = variant === 'red-white' ? '#d82b32' : '#26994e';
  const deep = variant === 'red-white' ? '#b51820' : '#145e2e';
  const accent = variant === 'red-white' ? '#2b5e2e' : '#c89b2b';

  // Warp & weft bands
  const bands = [
    { pos: 0, w: 30, color: primary },
    { pos: 40, w: 10, color: bright },
    { pos: 64, w: 34, color: deep },
    { pos: 112, w: 12, color: accent },
    { pos: 132, w: 30, color: primary },
    { pos: 174, w: 10, color: bright },
    { pos: 198, w: 34, color: deep },
  ];

  ctx.globalAlpha = 0.82;
  for (const b of bands) {
    ctx.fillStyle = b.color;
    ctx.fillRect(b.pos, 0, b.w, 256);
  }
  ctx.globalAlpha = 0.72;
  for (const b of bands) {
    ctx.fillStyle = b.color;
    ctx.fillRect(0, b.pos, 256, b.w);
  }
  ctx.globalAlpha = 1;

  // Fine woven crosshatch texture
  ctx.fillStyle = 'rgba(255, 250, 240, 0.16)';
  for (let y = 0; y < 256; y += 4) {
    for (let x = (y % 8 === 0 ? 0 : 2); x < 256; x += 4) {
      ctx.fillRect(x, y, 2, 2);
    }
  }
  return canvas;
}

function createMudWallCanvas(): { color: HTMLCanvasElement; bump: HTMLCanvasElement } {
  const [canvas, ctx] = makeCanvas(512, 512);
  const [bump, bCtx] = makeCanvas(256, 256);

  // Warm Bengal ochre / clay mud-plaster base
  const grad = ctx.createLinearGradient(0, 0, 0, 512);
  grad.addColorStop(0, '#c89e6c');
  grad.addColorStop(0.75, '#b68552');
  grad.addColorStop(1, '#855734');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, 512, 512);

  bCtx.fillStyle = '#808080';
  bCtx.fillRect(0, 0, 256, 256);

  // Hand-plastered mud blotches and straw flecks
  for (let i = 0; i < 1600; i++) {
    const x = Math.random() * 512;
    const y = Math.random() * 512;
    const r = 2 + Math.random() * 14;
    const light = Math.random() > 0.5;
    ctx.fillStyle = light ? 'rgba(232, 200, 155, 0.09)' : 'rgba(92, 56, 28, 0.1)';
    ctx.beginPath();
    ctx.arc(x, y, r, 0, Math.PI * 2);
    ctx.fill();

    bCtx.fillStyle = light ? 'rgba(220,220,220,0.14)' : 'rgba(40,40,40,0.14)';
    bCtx.beginPath();
    bCtx.arc(x * 0.5, y * 0.5, r * 0.5, 0, Math.PI * 2);
    bCtx.fill();
  }

  // Straw bits embedded in clay plaster
  ctx.strokeStyle = 'rgba(235, 205, 130, 0.35)';
  ctx.lineWidth = 1.2;
  for (let i = 0; i < 320; i++) {
    const x = Math.random() * 512;
    const y = Math.random() * 512;
    const a = Math.random() * Math.PI;
    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.lineTo(x + Math.cos(a) * 10, y + Math.sin(a) * 10);
    ctx.stroke();
  }

  // Traditional Bengali village terracotta dado + delicate white Alpona motif band along lower wall
  ctx.fillStyle = '#7e3f27';
  ctx.fillRect(0, 412, 512, 100);

  ctx.strokeStyle = 'rgba(250, 242, 224, 0.8)';
  ctx.lineWidth = 3;
  ctx.beginPath();
  ctx.moveTo(0, 412);
  ctx.lineTo(512, 412);
  ctx.stroke();

  // Alpona lotus scallops & dots
  ctx.fillStyle = 'rgba(250, 242, 224, 0.78)';
  for (let x = 16; x < 512; x += 32) {
    ctx.beginPath();
    ctx.arc(x, 404, 11, Math.PI, 0);
    ctx.stroke();
    ctx.beginPath();
    ctx.arc(x, 396, 2.5, 0, Math.PI * 2);
    ctx.fill();
  }

  return { color: canvas, bump };
}

function createThatchCanvas(): HTMLCanvasElement {
  const [canvas, ctx] = makeCanvas(256, 256);
  ctx.fillStyle = '#8b6c3e';
  ctx.fillRect(0, 0, 256, 256);

  // Layered straw bundles running downward
  for (let layer = 0; layer < 8; layer++) {
    const yBase = layer * 32;
    ctx.fillStyle = 'rgba(42, 28, 12, 0.25)';
    ctx.fillRect(0, yBase + 28, 256, 4);
    for (let i = 0; i < 260; i++) {
      const x = Math.random() * 256;
      const shade = Math.random();
      ctx.strokeStyle =
        shade > 0.65
          ? '#c4a462'
          : shade > 0.3
            ? '#9a7842'
            : '#5e4522';
      ctx.lineWidth = 1 + Math.random() * 1.5;
      ctx.beginPath();
      ctx.moveTo(x, yBase + Math.random() * 6);
      ctx.lineTo(x + (Math.random() - 0.5) * 4, yBase + 30 + Math.random() * 6);
      ctx.stroke();
    }
  }
  return canvas;
}

function createGroundCanvas(): { color: HTMLCanvasElement; bump: HTMLCanvasElement } {
  const [canvas, ctx] = makeCanvas(512, 512);
  const [bump, bCtx] = makeCanvas(256, 256);

  // Lush alluvial Bengal riverbank soil + patchy green grass + warm red laterite dust
  ctx.fillStyle = '#6f7339';
  ctx.fillRect(0, 0, 512, 512);

  bCtx.fillStyle = '#808080';
  bCtx.fillRect(0, 0, 256, 256);

  // Warm earth patches
  for (let i = 0; i < 550; i++) {
    const x = Math.random() * 512;
    const y = Math.random() * 512;
    const r = 8 + Math.random() * 28;
    const pick = Math.random();
    ctx.fillStyle =
      pick < 0.38
        ? 'rgba(138, 100, 62, 0.28)'
        : pick < 0.72
          ? 'rgba(84, 108, 46, 0.28)'
          : 'rgba(164, 124, 78, 0.22)';
    ctx.beginPath();
    ctx.arc(x, y, r, 0, Math.PI * 2);
    ctx.fill();

    bCtx.fillStyle = pick < 0.5 ? 'rgba(190,190,190,0.16)' : 'rgba(60,60,60,0.16)';
    bCtx.beginPath();
    bCtx.arc(x * 0.5, y * 0.5, r * 0.45, 0, Math.PI * 2);
    bCtx.fill();
  }

  // Fine pebbles and dry grass blades
  for (let i = 0; i < 1600; i++) {
    const x = Math.random() * 512;
    const y = Math.random() * 512;
    ctx.fillStyle = Math.random() > 0.5 ? 'rgba(55, 76, 30, 0.35)' : 'rgba(182, 146, 98, 0.32)';
    ctx.fillRect(x, y, 2, 4);
  }
  return { color: canvas, bump };
}

function createPalmBarkCanvas(): HTMLCanvasElement {
  const [canvas, ctx] = makeCanvas(128, 256);
  ctx.fillStyle = '#6d5846';
  ctx.fillRect(0, 0, 128, 256);

  // Horizontal coconut palm trunk growth rings
  for (let y = 0; y < 256; y += 16) {
    ctx.fillStyle = '#4a3b2e';
    ctx.fillRect(0, y, 128, 4);
    ctx.fillStyle = '#87725d';
    ctx.fillRect(0, y + 4, 128, 3);
  }
  for (let i = 0; i < 300; i++) {
    ctx.fillStyle = Math.random() > 0.5 ? 'rgba(40,30,20,0.22)' : 'rgba(160,145,125,0.18)';
    ctx.fillRect(Math.random() * 128, Math.random() * 256, 6, 2);
  }
  return canvas;
}

function createFrondCanvas(): HTMLCanvasElement {
  const [canvas, ctx] = makeCanvas(256, 128);
  ctx.clearRect(0, 0, 256, 128);

  // Central stem
  ctx.fillStyle = '#5a7d2c';
  ctx.fillRect(0, 60, 256, 8);

  // Pointed palm leaflets radiating along spine
  for (let x = 10; x < 246; x += 7) {
    const t = x / 256;
    const len = Math.sin(t * Math.PI) * 56 + 6;
    ctx.fillStyle = x % 14 === 0 ? '#2e6a26' : '#3d8230';

    // Upper leaflet
    ctx.beginPath();
    ctx.moveTo(x, 62);
    ctx.lineTo(x + 12, 62 - len);
    ctx.lineTo(x + 6, 62);
    ctx.closePath();
    ctx.fill();

    // Lower leaflet
    ctx.beginPath();
    ctx.moveTo(x, 66);
    ctx.lineTo(x + 12, 66 + len);
    ctx.lineTo(x + 6, 66);
    ctx.closePath();
    ctx.fill();
  }
  return canvas;
}

function createBridgeSteelCanvas(): HTMLCanvasElement {
  const [canvas, ctx] = makeCanvas(256, 256);
  // Weathered Howrah Bridge silver-grey industrial steel with rivet seams
  ctx.fillStyle = '#7b858d';
  ctx.fillRect(0, 0, 256, 256);

  for (let i = 0; i < 600; i++) {
    ctx.fillStyle = Math.random() > 0.5 ? 'rgba(210, 220, 226, 0.08)' : 'rgba(55, 62, 68, 0.1)';
    ctx.fillRect(Math.random() * 256, Math.random() * 256, 10, 10);
  }

  // Steel plate seam lines & rivets
  ctx.strokeStyle = 'rgba(42, 48, 54, 0.45)';
  ctx.lineWidth = 2;
  for (let y = 0; y < 256; y += 64) {
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.lineTo(256, y);
    ctx.stroke();
    ctx.fillStyle = 'rgba(220, 228, 234, 0.5)';
    for (let x = 12; x < 256; x += 24) {
      ctx.beginPath();
      ctx.arc(x, y + 8, 2.2, 0, Math.PI * 2);
      ctx.fill();
    }
  }
  return canvas;
}

function createWaterBumpCanvas(): HTMLCanvasElement {
  const [canvas, ctx] = makeCanvas(256, 256);
  ctx.fillStyle = '#808080';
  ctx.fillRect(0, 0, 256, 256);

  for (let y = 0; y < 256; y += 8) {
    for (let x = 0; x < 256; x += 16) {
      const grad = ctx.createRadialGradient(x + 8, y + 4, 1, x + 8, y + 4, 14);
      grad.addColorStop(0, 'rgba(230,230,230,0.4)');
      grad.addColorStop(1, 'rgba(70,70,70,0)');
      ctx.fillStyle = grad;
      ctx.fillRect(x - 6, y - 4, 28, 16);
    }
  }
  return canvas;
}

function createContactShadowCanvas(): HTMLCanvasElement {
  const [canvas, ctx] = makeCanvas(128, 128);
  const grad = ctx.createRadialGradient(64, 64, 6, 64, 64, 60);
  grad.addColorStop(0, 'rgba(18, 12, 8, 0.68)');
  grad.addColorStop(0.55, 'rgba(18, 12, 8, 0.28)');
  grad.addColorStop(1, 'rgba(18, 12, 8, 0)');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, 128, 128);
  return canvas;
}

function createSkyCanvas(): HTMLCanvasElement {
  const [canvas, ctx] = makeCanvas(512, 256);
  // Bright sunny Bengali daytime sky: clear azure zenith fading to luminous sky-blue horizon
  const grad = ctx.createLinearGradient(0, 0, 0, 256);
  grad.addColorStop(0.0, '#2c82dc');
  grad.addColorStop(0.28, '#53a8f2');
  grad.addColorStop(0.56, '#8fd0fc');
  grad.addColorStop(0.78, '#c6e8ff');
  grad.addColorStop(0.92, '#e6f5ff');
  grad.addColorStop(1.0, '#d2ecff');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, 512, 256);

  // Soft sunlit fluffy white daytime clouds over the Hooghly river
  for (let i = 0; i < 26; i++) {
    const cx = Math.random() * 512;
    const cy = 48 + Math.random() * 96;
    const rx = 28 + Math.random() * 68;
    const ry = 7 + Math.random() * 16;
    const cg = ctx.createRadialGradient(cx, cy, 2, cx, cy, rx);
    cg.addColorStop(0, 'rgba(255, 255, 255, 0.52)');
    cg.addColorStop(0.6, 'rgba(244, 250, 255, 0.24)');
    cg.addColorStop(1, 'rgba(235, 246, 255, 0)');
    ctx.save();
    ctx.translate(cx, cy);
    ctx.scale(1, ry / rx);
    ctx.fillStyle = cg;
    ctx.beginPath();
    ctx.arc(0, 0, rx, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }

  // Radiant golden daytime sun high above the Howrah bridge horizon
  const sunGrad = ctx.createRadialGradient(340, 110, 6, 340, 110, 82);
  sunGrad.addColorStop(0, 'rgba(255, 253, 236, 1.0)');
  sunGrad.addColorStop(0.24, 'rgba(255, 238, 178, 0.62)');
  sunGrad.addColorStop(0.6, 'rgba(255, 224, 152, 0.2)');
  sunGrad.addColorStop(1, 'rgba(255, 224, 152, 0)');
  ctx.fillStyle = sunGrad;
  ctx.fillRect(245, 22, 195, 175);

  return canvas;
}

function createTaxiSignCanvas(): HTMLCanvasElement {
  const [canvas, ctx] = makeCanvas(256, 96);
  ctx.fillStyle = '#f6c216';
  ctx.fillRect(0, 0, 256, 96);
  ctx.strokeStyle = '#141414';
  ctx.lineWidth = 8;
  ctx.strokeRect(6, 6, 244, 84);
  ctx.fillStyle = '#141414';
  ctx.font = 'bold 52px sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText('TAXI', 128, 52);
  return canvas;
}

function createLicensePlateCanvas(): HTMLCanvasElement {
  const [canvas, ctx] = makeCanvas(256, 64);
  ctx.fillStyle = '#f5c418';
  ctx.fillRect(0, 0, 256, 64);
  ctx.strokeStyle = '#151515';
  ctx.lineWidth = 5;
  ctx.strokeRect(4, 4, 248, 56);
  ctx.fillStyle = '#111111';
  ctx.font = 'bold 34px monospace';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText('WB 04 7182', 128, 34);
  return canvas;
}

function createBusSideCanvas(): HTMLCanvasElement {
  const [canvas, ctx] = makeCanvas(512, 160);
  // Iconic Kolkata WBTC Blue-and-White lower hull + Yellow-Red accent stripe
  ctx.fillStyle = '#f4f6f8';
  ctx.fillRect(0, 0, 512, 48);

  // Bold golden-yellow & crimson waist stripe
  ctx.fillStyle = '#f4be1c';
  ctx.fillRect(0, 48, 512, 20);
  ctx.fillStyle = '#cc2229';
  ctx.fillRect(0, 68, 512, 12);

  // Classic West Bengal government royal/sky blue lower body
  const blueGrad = ctx.createLinearGradient(0, 80, 0, 160);
  blueGrad.addColorStop(0, '#1466b8');
  blueGrad.addColorStop(1, '#0c478a');
  ctx.fillStyle = blueGrad;
  ctx.fillRect(0, 80, 512, 80);

  // Panel rivets & wheel arch subtle trim lines
  ctx.strokeStyle = 'rgba(255,255,255,0.22)';
  ctx.lineWidth = 2;
  for (let x = 64; x < 512; x += 64) {
    ctx.beginPath();
    ctx.moveTo(x, 82);
    ctx.lineTo(x, 158);
    ctx.stroke();
  }

  // WBTC Bengali + English Branding
  ctx.fillStyle = '#ffffff';
  ctx.font = 'bold 34px sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText('WBTC  •  কলকাতা', 256, 118);

  ctx.fillStyle = '#ffe17a';
  ctx.font = 'bold 16px sans-serif';
  ctx.fillText('পশ্চিমবঙ্গ পরিবহন নিগম  |  HOWRAH - VILLAGE', 256, 146);

  return canvas;
}

function createBusDestinationCanvas(): HTMLCanvasElement {
  const [canvas, ctx] = makeCanvas(256, 64);
  ctx.fillStyle = '#121820';
  ctx.fillRect(0, 0, 256, 64);
  ctx.strokeStyle = '#f4be1c';
  ctx.lineWidth = 4;
  ctx.strokeRect(3, 3, 250, 58);

  ctx.fillStyle = '#ffd54a';
  ctx.font = 'bold 26px sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText('S-12  হাওড়া ↔ গ্রাম', 128, 34);
  return canvas;
}

function createSkinBumpCanvas(): HTMLCanvasElement {
  const [canvas, ctx] = makeCanvas(256, 256);
  ctx.fillStyle = '#808080';
  ctx.fillRect(0, 0, 256, 256);

  // Fine organic skin pore & micro-relief grain
  for (let i = 0; i < 3200; i++) {
    const x = Math.random() * 256;
    const y = Math.random() * 256;
    const r = 0.6 + Math.random() * 1.4;
    const isPore = Math.random() < 0.55;
    ctx.fillStyle = isPore ? 'rgba(42, 42, 42, 0.24)' : 'rgba(218, 218, 218, 0.16)';
    ctx.beginPath();
    ctx.arc(x, y, r, 0, Math.PI * 2);
    ctx.fill();
  }

  // Subtle fine dermal tension micro-lines
  ctx.strokeStyle = 'rgba(110, 110, 110, 0.18)';
  ctx.lineWidth = 0.7;
  for (let i = 0; i < 180; i++) {
    const x = Math.random() * 256;
    const y = Math.random() * 256;
    const len = 4 + Math.random() * 10;
    const a = (Math.random() - 0.5) * 0.5;
    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.lineTo(x + Math.cos(a) * len, y + Math.sin(a) * len);
    ctx.stroke();
  }
  return canvas;
}

function createSkinAlbedoCanvas(): HTMLCanvasElement {
  const [canvas, ctx] = makeCanvas(256, 256);
  // Warm neutral ivory multiplied by each character's natural Bengali skin hex
  ctx.fillStyle = '#f8f0e8';
  ctx.fillRect(0, 0, 256, 256);

  // Subtle organic epidermal melanin & warm capillary blood-flow mottling
  for (let i = 0; i < 650; i++) {
    const x = Math.random() * 256;
    const y = Math.random() * 256;
    const r = 4 + Math.random() * 18;
    const roll = Math.random();
    const grad = ctx.createRadialGradient(x, y, 0.5, x, y, r);
    if (roll < 0.36) {
      grad.addColorStop(0, 'rgba(222, 168, 152, 0.085)');
      grad.addColorStop(1, 'rgba(222, 168, 152, 0)');
    } else if (roll < 0.72) {
      grad.addColorStop(0, 'rgba(218, 192, 158, 0.075)');
      grad.addColorStop(1, 'rgba(218, 192, 158, 0)');
    } else {
      grad.addColorStop(0, 'rgba(255, 248, 240, 0.07)');
      grad.addColorStop(1, 'rgba(255, 248, 240, 0)');
    }
    ctx.fillStyle = grad;
    ctx.beginPath();
    ctx.arc(x, y, r, 0, Math.PI * 2);
    ctx.fill();
  }

  for (let i = 0; i < 900; i++) {
    const x = Math.random() * 256;
    const y = Math.random() * 256;
    ctx.fillStyle = Math.random() > 0.5 ? 'rgba(155, 118, 92, 0.055)' : 'rgba(255, 245, 236, 0.05)';
    ctx.fillRect(x, y, 1.5, 1.5);
  }
  return canvas;
}

function createFaceAlbedoCanvas(): HTMLCanvasElement {
  // Mapped to SphereGeometry UVs where +Z (front of face) is at u = 0.25 (cx = 128 on 512px)
  const [canvas, ctx] = makeCanvas(512, 256);
  ctx.fillStyle = '#f8f0e8';
  ctx.fillRect(0, 0, 512, 256);

  for (let i = 0; i < 480; i++) {
    const x = Math.random() * 512;
    const y = Math.random() * 256;
    const r = 6 + Math.random() * 22;
    const grad = ctx.createRadialGradient(x, y, 1, x, y, r);
    grad.addColorStop(0, Math.random() > 0.5 ? 'rgba(218, 174, 154, 0.06)' : 'rgba(252, 244, 235, 0.05)');
    grad.addColorStop(1, 'rgba(218, 174, 154, 0)');
    ctx.fillStyle = grad;
    ctx.beginPath();
    ctx.arc(x, y, r, 0, Math.PI * 2);
    ctx.fill();
  }

  const cx = 128;
  const cy = 128;

  // Warm sun-kissed forehead & nose bridge glow
  const foreheadGrad = ctx.createRadialGradient(cx, cy - 36, 4, cx, cy - 32, 54);
  foreheadGrad.addColorStop(0, 'rgba(255, 244, 230, 0.18)');
  foreheadGrad.addColorStop(1, 'rgba(255, 244, 230, 0)');
  ctx.fillStyle = foreheadGrad;
  ctx.beginPath();
  ctx.arc(cx, cy - 32, 54, 0, Math.PI * 2);
  ctx.fill();

  // Natural warm blush on cheekbones + nose-tip warmth
  for (const sx of [-24, 24]) {
    const cheekGrad = ctx.createRadialGradient(cx + sx, cy + 12, 2, cx + sx, cy + 12, 24);
    cheekGrad.addColorStop(0, 'rgba(214, 134, 118, 0.16)');
    cheekGrad.addColorStop(1, 'rgba(214, 134, 118, 0)');
    ctx.fillStyle = cheekGrad;
    ctx.beginPath();
    ctx.arc(cx + sx, cy + 12, 24, 0, Math.PI * 2);
    ctx.fill();
  }
  const noseWarm = ctx.createRadialGradient(cx, cy + 14, 2, cx, cy + 14, 15);
  noseWarm.addColorStop(0, 'rgba(218, 144, 126, 0.14)');
  noseWarm.addColorStop(1, 'rgba(218, 144, 126, 0)');
  ctx.fillStyle = noseWarm;
  ctx.beginPath();
  ctx.arc(cx, cy + 14, 15, 0, Math.PI * 2);
  ctx.fill();

  // Soft anatomical orbital & under-eye shading
  for (const sx of [-19, 19]) {
    const orbitGrad = ctx.createRadialGradient(cx + sx, cy - 5, 2, cx + sx, cy - 5, 16);
    orbitGrad.addColorStop(0, 'rgba(138, 98, 82, 0.22)');
    orbitGrad.addColorStop(1, 'rgba(138, 98, 82, 0)');
    ctx.fillStyle = orbitGrad;
    ctx.beginPath();
    ctx.arc(cx + sx, cy - 5, 16, 0, Math.PI * 2);
    ctx.fill();
  }

  // Subtle lower-jaw & under-chin warmth for sculpted facial depth
  const jawGrad = ctx.createLinearGradient(0, cy + 44, 0, cy + 96);
  jawGrad.addColorStop(0, 'rgba(132, 102, 86, 0)');
  jawGrad.addColorStop(0.65, 'rgba(122, 92, 76, 0.16)');
  jawGrad.addColorStop(1, 'rgba(105, 76, 62, 0.24)');
  ctx.fillStyle = jawGrad;
  ctx.fillRect(cx - 72, cy + 44, 144, 58);

  return canvas;
}

function createFabricBumpCanvas(): HTMLCanvasElement {
  const [canvas, ctx] = makeCanvas(256, 256);
  ctx.fillStyle = '#7e7e7e';
  ctx.fillRect(0, 0, 256, 256);

  // Fine woven cotton / tactical ripstop cross-threads
  for (let y = 0; y < 256; y += 3) {
    ctx.fillStyle = y % 6 === 0 ? 'rgba(215, 215, 215, 0.22)' : 'rgba(55, 55, 55, 0.2)';
    ctx.fillRect(0, y, 256, 1.5);
  }
  for (let x = 0; x < 256; x += 3) {
    ctx.fillStyle = x % 6 === 0 ? 'rgba(220, 220, 220, 0.2)' : 'rgba(50, 50, 50, 0.18)';
    ctx.fillRect(x, 0, 1.5, 256);
  }

  // Subtle tactical ripstop reinforcement grid every 16px
  ctx.strokeStyle = 'rgba(235, 235, 235, 0.24)';
  ctx.lineWidth = 1;
  for (let i = 0; i < 256; i += 16) {
    ctx.beginPath();
    ctx.moveTo(i, 0);
    ctx.lineTo(i, 256);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(0, i);
    ctx.lineTo(256, i);
    ctx.stroke();
  }
  return canvas;
}

export function createTextureBundle(renderer: THREE.WebGLRenderer): TextureBundle {
  const maxAniso = Math.min(renderer.capabilities.getMaxAnisotropy(), 8);

  const gamchaMap = configureTexture(createGamchaCanvas('red-white'), maxAniso, true, 2, 2);
  const gamchaGreenMap = configureTexture(createGamchaCanvas('green-white'), maxAniso, true, 2, 2);
  const mud = createMudWallCanvas();
  const mudWallMap = configureTexture(mud.color, maxAniso, true, 2, 1);
  const mudWallBump = configureTexture(mud.bump, maxAniso, false, 2, 1);
  const thatchMap = configureTexture(createThatchCanvas(), maxAniso, true, 3, 2);
  const ground = createGroundCanvas();
  const groundMap = configureTexture(ground.color, maxAniso, true, 16, 16);
  const groundBump = configureTexture(ground.bump, maxAniso, false, 16, 16);
  const palmBarkMap = configureTexture(createPalmBarkCanvas(), maxAniso, true, 1, 5);
  const frondMap = configureTexture(createFrondCanvas(), maxAniso, true, 1, 1);
  frondMap.wrapS = THREE.ClampToEdgeWrapping;
  frondMap.wrapT = THREE.ClampToEdgeWrapping;
  const bridgeSteelMap = configureTexture(createBridgeSteelCanvas(), maxAniso, true, 2, 4);
  const waterBump = configureTexture(createWaterBumpCanvas(), maxAniso, false, 14, 14);
  const contactShadowMap = configureTexture(createContactShadowCanvas(), maxAniso, true, 1, 1);
  contactShadowMap.wrapS = THREE.ClampToEdgeWrapping;
  contactShadowMap.wrapT = THREE.ClampToEdgeWrapping;
  const skyMap = configureTexture(createSkyCanvas(), maxAniso, true, 1, 1);
  skyMap.wrapS = THREE.ClampToEdgeWrapping;
  skyMap.wrapT = THREE.ClampToEdgeWrapping;
  const taxiSignMap = configureTexture(createTaxiSignCanvas(), maxAniso, true, 1, 1);
  const licensePlateMap = configureTexture(createLicensePlateCanvas(), maxAniso, true, 1, 1);
  const busSideMap = configureTexture(createBusSideCanvas(), maxAniso, true, 1, 1);
  const busDestinationMap = configureTexture(createBusDestinationCanvas(), maxAniso, true, 1, 1);
  const skinBumpMap = configureTexture(createSkinBumpCanvas(), maxAniso, false, 3, 3);
  const skinAlbedoMap = configureTexture(createSkinAlbedoCanvas(), maxAniso, true, 2, 2);
  const faceAlbedoMap = configureTexture(createFaceAlbedoCanvas(), maxAniso, true, 1, 1);
  faceAlbedoMap.wrapS = THREE.RepeatWrapping;
  faceAlbedoMap.wrapT = THREE.ClampToEdgeWrapping;
  const fabricBumpMap = configureTexture(createFabricBumpCanvas(), maxAniso, false, 4, 4);

  const all = [
    gamchaMap,
    gamchaGreenMap,
    mudWallMap,
    mudWallBump,
    thatchMap,
    groundMap,
    groundBump,
    palmBarkMap,
    frondMap,
    bridgeSteelMap,
    waterBump,
    contactShadowMap,
    skyMap,
    taxiSignMap,
    licensePlateMap,
    busSideMap,
    busDestinationMap,
    skinBumpMap,
    skinAlbedoMap,
    faceAlbedoMap,
    fabricBumpMap,
  ];

  return {
    gamchaMap,
    gamchaGreenMap,
    mudWallMap,
    mudWallBump,
    thatchMap,
    groundMap,
    groundBump,
    palmBarkMap,
    frondMap,
    bridgeSteelMap,
    waterBump,
    contactShadowMap,
    skyMap,
    taxiSignMap,
    licensePlateMap,
    busSideMap,
    busDestinationMap,
    skinBumpMap,
    skinAlbedoMap,
    faceAlbedoMap,
    fabricBumpMap,
    disposeAll: () => {
      all.forEach((t) => t.dispose());
    },
  };
}
