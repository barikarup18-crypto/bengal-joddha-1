import * as THREE from 'three';
import { CircleCollider } from './types';

export interface WarriorChestRig {
  root: THREE.Group;
  lidPivot: THREE.Group;
  glowRing: THREE.Mesh;
  innerGlow: THREE.Mesh;
  brassMat: THREE.MeshStandardMaterial;
}

export interface SanjibaniPlantRig {
  root: THREE.Group;
  foliageGroup: THREE.Group;
  glowRing: THREE.Mesh;
}

export interface KalboishakhiStormRig {
  root: THREE.Group;
  wallMesh: THREE.Mesh;
  groundRing: THREE.Mesh;
  uniforms: {
    uTime: { value: number };
    uIntensity: { value: number };
  };
}

/**
 * Builds a traditional wooden-and-brass Bengali Warrior Loot Chest ('যোদ্ধা সিন্দুক')
 * with teak timber planks, hammered brass corner straps, lotus clasp, hinged lid,
 * and warm golden beacon glow. Bottom-center pivot grounded at y = 0.
 */
export function buildWarriorChest(): WarriorChestRig {
  const root = new THREE.Group();

  const woodMat = new THREE.MeshStandardMaterial({
    color: 0x5c341a,
    roughness: 0.78,
    metalness: 0.04,
  });
  const darkWoodMat = new THREE.MeshStandardMaterial({
    color: 0x3b200f,
    roughness: 0.86,
    metalness: 0.02,
  });
  const brassMat = new THREE.MeshStandardMaterial({
    color: 0xe3b146,
    roughness: 0.24,
    metalness: 0.88,
    emissive: 0x613e08,
    emissiveIntensity: 0.55,
  });
  const innerGlowMat = new THREE.MeshBasicMaterial({
    color: 0xffd35c,
    transparent: true,
    opacity: 0.88,
  });
  const ringMat = new THREE.MeshBasicMaterial({
    color: 0xffc842,
    transparent: true,
    opacity: 0.72,
    side: THREE.DoubleSide,
    depthWrite: false,
  });

  // 1. Main teak wood chest base
  const baseBody = new THREE.Mesh(new THREE.BoxGeometry(1.06, 0.52, 0.68), woodMat);
  baseBody.position.y = 0.28;
  baseBody.castShadow = true;
  baseBody.receiveShadow = true;
  root.add(baseBody);

  // Carved dark timber feet
  for (const fx of [-0.46, 0.46]) {
    for (const fz of [-0.28, 0.28]) {
      const foot = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.07, 0.14), darkWoodMat);
      foot.position.set(fx, 0.035, fz);
      root.add(foot);
    }
  }

  // 2. Hammered brass vertical corner bands & bottom trim
  for (const bx of [-0.52, 0.52]) {
    const band = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.54, 0.72), brassMat);
    band.position.set(bx, 0.28, 0);
    root.add(band);
  }
  const frontBottomTrim = new THREE.Mesh(new THREE.BoxGeometry(1.1, 0.065, 0.72), brassMat);
  frontBottomTrim.position.set(0, 0.09, 0);
  root.add(frontBottomTrim);

  // Brass side carry rings
  for (const sx of [-0.55, 0.55]) {
    const handle = new THREE.Mesh(new THREE.TorusGeometry(0.09, 0.018, 6, 14), brassMat);
    handle.rotation.y = Math.PI / 2;
    handle.position.set(sx, 0.34, 0);
    root.add(handle);
  }

  // Central ornate brass Bengal lock plate & latch
  const lockPlate = new THREE.Mesh(new THREE.CylinderGeometry(0.11, 0.11, 0.05, 8), brassMat);
  lockPlate.rotation.x = Math.PI / 2;
  lockPlate.position.set(0, 0.48, 0.35);
  root.add(lockPlate);

  // Glowing golden treasure light bed inside chest
  const innerGlow = new THREE.Mesh(new THREE.BoxGeometry(0.92, 0.08, 0.54), innerGlowMat);
  innerGlow.position.set(0, 0.51, 0);
  root.add(innerGlow);

  // 3. Hinged arched wooden lid pivoting cleanly at back edge (z = -0.34, y = 0.54)
  const lidPivot = new THREE.Group();
  lidPivot.position.set(0, 0.54, -0.34);
  root.add(lidPivot);

  const lidArch = new THREE.Mesh(
    new THREE.CylinderGeometry(0.34, 0.34, 1.06, 12, 1, false, 0, Math.PI),
    woodMat,
  );
  lidArch.rotation.z = Math.PI / 2;
  lidArch.scale.set(0.65, 1.0, 1.0);
  lidArch.position.set(0, 0.0, 0.34);
  lidArch.castShadow = true;
  lidPivot.add(lidArch);

  // Brass curved rib straps over the lid
  for (const lx of [-0.46, 0, 0.46]) {
    const strap = new THREE.Mesh(
      new THREE.CylinderGeometry(0.355, 0.355, 0.075, 12, 1, false, 0, Math.PI),
      brassMat,
    );
    strap.rotation.z = Math.PI / 2;
    strap.scale.set(0.66, 1.0, 1.0);
    strap.position.set(lx, 0.0, 0.34);
    lidPivot.add(strap);
  }

  // Ground beacon aura ring so player spots chests cleanly across the village & riverbank
  const glowRing = new THREE.Mesh(new THREE.RingGeometry(0.76, 1.02, 24), ringMat);
  glowRing.rotation.x = -Math.PI / 2;
  glowRing.position.y = 0.035;
  root.add(glowRing);

  return { root, lidPivot, glowRing, innerGlow, brassMat };
}

/**
 * Builds a glowing emerald-green Sanjibani Medicinal Herb Plant ('সঞ্জীবনী গাছ')
 * with mossy soil mound, curved stems, radiant emerald foliage leaves, and glowing dew spores.
 */
export function buildSanjibaniPlant(): SanjibaniPlantRig {
  const root = new THREE.Group();

  const soilMat = new THREE.MeshStandardMaterial({
    color: 0x3b2a1a,
    roughness: 0.94,
    metalness: 0.0,
  });
  const stemMat = new THREE.MeshStandardMaterial({
    color: 0x168a4d,
    emissive: 0x0b522c,
    emissiveIntensity: 0.65,
    roughness: 0.48,
  });
  const leafMat = new THREE.MeshStandardMaterial({
    color: 0x22e883,
    emissive: 0x12c46a,
    emissiveIntensity: 1.15,
    roughness: 0.32,
    metalness: 0.06,
    side: THREE.DoubleSide,
  });
  const sporeMat = new THREE.MeshBasicMaterial({
    color: 0xaaffd6,
  });

  // 1. Mossy earthen mound base
  const mound = new THREE.Mesh(
    new THREE.SphereGeometry(0.32, 12, 8, 0, Math.PI * 2, 0, Math.PI * 0.55),
    soilMat,
  );
  mound.scale.set(1.2, 0.48, 1.2);
  root.add(mound);

  // 2. Sculpted leaf silhouette (pointed Bengali medicinal herb leaf)
  const leafShape = new THREE.Shape();
  leafShape.moveTo(0, 0);
  leafShape.quadraticCurveTo(0.14, 0.16, 0.09, 0.36);
  leafShape.quadraticCurveTo(0.03, 0.48, 0, 0.56);
  leafShape.quadraticCurveTo(-0.03, 0.48, -0.09, 0.36);
  leafShape.quadraticCurveTo(-0.14, 0.16, 0, 0);

  const leafGeo = new THREE.ExtrudeGeometry(leafShape, {
    depth: 0.014,
    bevelEnabled: true,
    bevelThickness: 0.005,
    bevelSize: 0.005,
    bevelSegments: 2,
  });
  leafGeo.rotateX(-Math.PI * 0.32);

  const foliageGroup = new THREE.Group();
  foliageGroup.position.y = 0.08;
  root.add(foliageGroup);

  // Central stem + 7 radiating radiant leaves in two tiers
  const centerStem = new THREE.Mesh(new THREE.CylinderGeometry(0.022, 0.036, 0.42, 8), stemMat);
  centerStem.position.y = 0.21;
  foliageGroup.add(centerStem);

  for (let i = 0; i < 7; i++) {
    const angle = (i / 7) * Math.PI * 2;
    const isUpper = i % 2 === 1;
    const leaf = new THREE.Mesh(leafGeo, leafMat);
    leaf.position.set(
      Math.cos(angle) * 0.05,
      isUpper ? 0.24 : 0.11,
      Math.sin(angle) * 0.05,
    );
    leaf.rotation.y = angle;
    leaf.rotation.x = isUpper ? 0.22 : 0.48;
    leaf.scale.setScalar(isUpper ? 0.85 : 1.05);
    foliageGroup.add(leaf);
  }

  // Radiant healing dew orb at crown + floating healing spores
  const crownOrb = new THREE.Mesh(new THREE.OctahedronGeometry(0.1, 1), sporeMat);
  crownOrb.position.y = 0.52;
  foliageGroup.add(crownOrb);

  for (let s = 0; s < 3; s++) {
    const a = (s / 3) * Math.PI * 2;
    const dot = new THREE.Mesh(new THREE.SphereGeometry(0.032, 6, 6), sporeMat);
    dot.position.set(Math.cos(a) * 0.28, 0.42 + s * 0.11, Math.sin(a) * 0.28);
    foliageGroup.add(dot);
  }

  // Emerald ground aura ring
  const glowRing = new THREE.Mesh(
    new THREE.RingGeometry(0.45, 0.64, 20),
    new THREE.MeshBasicMaterial({
      color: 0x26f28a,
      transparent: true,
      opacity: 0.68,
      side: THREE.DoubleSide,
      depthWrite: false,
    }),
  );
  glowRing.rotation.x = -Math.PI / 2;
  glowRing.position.y = 0.035;
  root.add(glowRing);

  return { root, foliageGroup, glowRing };
}

/**
 * Builds Slot 3 — ত্রিশূল স্নাইপার (Trishul Sniper):
 * Long-range precision sniper rifle with extended fluted barrel, twin-baffle muzzle brake,
 * high-magnification brass-ringed telescopic optic scope, walnut stock, and folding bipod.
 */
export function buildTrishulSniper(
  gunMetalMat: THREE.MeshStandardMaterial,
  gunDarkMat: THREE.MeshStandardMaterial,
  gunWoodMat: THREE.MeshStandardMaterial,
): THREE.Group {
  const sniper = new THREE.Group();

  const brassMat = new THREE.MeshStandardMaterial({
    color: 0xdca73c,
    roughness: 0.24,
    metalness: 0.9,
  });
  const lensMat = new THREE.MeshPhysicalMaterial({
    color: 0x1e88e5,
    emissive: 0x0b3a6e,
    emissiveIntensity: 0.6,
    roughness: 0.1,
    metalness: 0.2,
    clearcoat: 1.0,
  });

  // 1. Precision thumbhole walnut stock + cheek rest
  const stockShape = new THREE.Shape();
  stockShape.moveTo(0.02, 0.04);
  stockShape.lineTo(-0.34, 0.025);
  stockShape.lineTo(-0.35, -0.105);
  stockShape.lineTo(-0.18, -0.07);
  stockShape.lineTo(0.02, -0.025);
  stockShape.closePath();

  const stockGeo = new THREE.ExtrudeGeometry(stockShape, {
    depth: 0.042,
    bevelEnabled: true,
    bevelThickness: 0.007,
    bevelSize: 0.006,
    bevelSegments: 2,
  });
  stockGeo.rotateY(Math.PI / 2);
  stockGeo.translate(-0.021, -0.015, 0);
  const stock = new THREE.Mesh(stockGeo, gunWoodMat);
  stock.castShadow = true;
  sniper.add(stock);

  const grip = new THREE.Mesh(new THREE.CapsuleGeometry(0.022, 0.09, 4, 8), gunDarkMat);
  grip.position.set(0, -0.068, 0.028);
  grip.rotation.x = -0.3;
  sniper.add(grip);

  // 2. Long steel bolt-action receiver + bolt handle knob
  const receiver = new THREE.Mesh(new THREE.BoxGeometry(0.062, 0.088, 0.42), gunMetalMat);
  receiver.position.set(0, 0.014, 0.18);
  receiver.castShadow = true;
  sniper.add(receiver);

  const boltStem = new THREE.Mesh(new THREE.CylinderGeometry(0.007, 0.007, 0.065, 8), brassMat);
  boltStem.rotation.z = Math.PI / 2;
  boltStem.position.set(0.055, 0.025, 0.09);
  sniper.add(boltStem);
  const boltKnob = new THREE.Mesh(new THREE.SphereGeometry(0.016, 8, 8), brassMat);
  boltKnob.position.set(0.085, 0.018, 0.09);
  sniper.add(boltKnob);

  // Slim 5-round sniper box magazine
  const mag = new THREE.Mesh(new THREE.BoxGeometry(0.036, 0.12, 0.095), gunDarkMat);
  mag.position.set(0, -0.07, 0.22);
  sniper.add(mag);

  // 3. High-magnification brass-trimmed telescopic scope
  const scopeTube = new THREE.Mesh(new THREE.CylinderGeometry(0.024, 0.019, 0.36, 14), gunDarkMat);
  scopeTube.rotation.x = Math.PI / 2;
  scopeTube.position.set(0, 0.094, 0.2);
  scopeTube.castShadow = true;
  sniper.add(scopeTube);

  const objectiveBell = new THREE.Mesh(new THREE.CylinderGeometry(0.032, 0.024, 0.09, 14), gunMetalMat);
  objectiveBell.rotation.x = Math.PI / 2;
  objectiveBell.position.set(0, 0.094, 0.4);
  sniper.add(objectiveBell);

  const objectiveLens = new THREE.Mesh(new THREE.CircleGeometry(0.026, 12), lensMat);
  objectiveLens.position.set(0, 0.094, 0.448);
  sniper.add(objectiveLens);

  for (const rz of [0.1, 0.3]) {
    const ring = new THREE.Mesh(new THREE.TorusGeometry(0.026, 0.006, 6, 14), brassMat);
    ring.position.set(0, 0.094, rz);
    sniper.add(ring);
    const mount = new THREE.Mesh(new THREE.BoxGeometry(0.028, 0.036, 0.028), gunMetalMat);
    mount.position.set(0, 0.068, rz);
    sniper.add(mount);
  }

  // 4. Forend handguard + extended fluted sniper barrel + Trishul twin-baffle brake
  const forend = new THREE.Mesh(new THREE.BoxGeometry(0.056, 0.062, 0.34), gunWoodMat);
  forend.position.set(0, 0.002, 0.54);
  forend.castShadow = true;
  sniper.add(forend);

  const barrel = new THREE.Mesh(new THREE.CylinderGeometry(0.015, 0.019, 0.72, 12), gunMetalMat);
  barrel.rotation.x = Math.PI / 2;
  barrel.position.set(0, 0.026, 0.88);
  barrel.castShadow = true;
  sniper.add(barrel);

  const brake = new THREE.Mesh(new THREE.BoxGeometry(0.044, 0.034, 0.11), brassMat);
  brake.position.set(0, 0.026, 1.24);
  sniper.add(brake);

  // Folded tactical bipod struts under forend
  for (const sx of [-0.034, 0.034]) {
    const leg = new THREE.Mesh(new THREE.CylinderGeometry(0.007, 0.007, 0.22, 6), gunDarkMat);
    leg.rotation.x = Math.PI / 2 - 0.18;
    leg.position.set(sx, -0.04, 0.62);
    sniper.add(leg);
  }

  return sniper;
}

/**
 * Builds Slot 4 — বাংলার ফলা (Banglar Fala):
 * Sharp curved Bengali tactical combat blade with brushed forged steel edge,
 * hammered brass guard, and cord-wrapped dark teak handle.
 */
export function buildBanglarFala(): THREE.Group {
  const knife = new THREE.Group();

  const bladeMat = new THREE.MeshStandardMaterial({
    color: 0xdce4ea,
    roughness: 0.18,
    metalness: 0.94,
  });
  const brassMat = new THREE.MeshStandardMaterial({
    color: 0xe3b146,
    roughness: 0.26,
    metalness: 0.88,
  });
  const handleMat = new THREE.MeshStandardMaterial({
    color: 0x3b2214,
    roughness: 0.78,
    metalness: 0.04,
  });
  const wrapMat = new THREE.MeshStandardMaterial({
    color: 0x991c22, // subtle Bengal crimson cord wrap
    roughness: 0.85,
  });

  // 1. Wrapped handle held cleanly in hero's right hand
  const handle = new THREE.Mesh(new THREE.CylinderGeometry(0.022, 0.024, 0.16, 10), handleMat);
  handle.rotation.x = Math.PI / 2;
  handle.position.set(0, -0.02, 0.04);
  knife.add(handle);

  for (let w = 0; w < 4; w++) {
    const ring = new THREE.Mesh(new THREE.TorusGeometry(0.024, 0.0045, 6, 12), wrapMat);
    ring.position.set(0, -0.02, -0.015 + w * 0.034);
    knife.add(ring);
  }

  // Pommel cap + brass crossguard
  const pommel = new THREE.Mesh(new THREE.SphereGeometry(0.025, 10, 8), brassMat);
  pommel.position.set(0, -0.02, -0.048);
  knife.add(pommel);

  const guard = new THREE.Mesh(new THREE.BoxGeometry(0.034, 0.095, 0.024), brassMat);
  guard.position.set(0, -0.015, 0.125);
  knife.add(guard);

  // 2. Curved Bengali tactical steel blade (ExtrudeGeometry with razor bevel)
  const bladeShape = new THREE.Shape();
  bladeShape.moveTo(0, -0.024);
  bladeShape.lineTo(0.24, -0.034);
  bladeShape.quadraticCurveTo(0.36, -0.028, 0.45, 0.022); // curved wicked tip
  bladeShape.quadraticCurveTo(0.32, 0.032, 0.16, 0.022);
  bladeShape.lineTo(0, 0.026);
  bladeShape.closePath();

  const bladeGeo = new THREE.ExtrudeGeometry(bladeShape, {
    depth: 0.007,
    bevelEnabled: true,
    bevelThickness: 0.0035,
    bevelSize: 0.0035,
    bevelSegments: 2,
  });
  bladeGeo.rotateY(-Math.PI / 2);
  bladeGeo.translate(0.0035, -0.012, 0.135);
  const blade = new THREE.Mesh(bladeGeo, bladeMat);
  blade.castShadow = true;
  knife.add(blade);

  return knife;
}

/**
 * Builds a throwable বজ্র গোলা (Bajra Gola — Bengali tactical grenade)
 * with segmented cast-iron body, brass thunder band, top striker lever, and glowing fuse spark.
 */
export function buildBajraGolaMesh(): THREE.Group {
  const group = new THREE.Group();

  const ironMat = new THREE.MeshStandardMaterial({
    color: 0x262c28,
    roughness: 0.48,
    metalness: 0.65,
  });
  const brassMat = new THREE.MeshStandardMaterial({
    color: 0xf0b835,
    roughness: 0.25,
    metalness: 0.88,
    emissive: 0x704808,
    emissiveIntensity: 0.5,
  });
  const sparkMat = new THREE.MeshBasicMaterial({
    color: 0xff5a22,
  });

  const body = new THREE.Mesh(new THREE.SphereGeometry(0.14, 12, 10), ironMat);
  body.scale.set(1.0, 1.24, 1.0);
  body.castShadow = true;
  group.add(body);

  const band = new THREE.Mesh(new THREE.TorusGeometry(0.142, 0.022, 6, 16), brassMat);
  band.rotation.x = Math.PI / 2;
  group.add(band);

  const cap = new THREE.Mesh(new THREE.CylinderGeometry(0.048, 0.058, 0.07, 10), brassMat);
  cap.position.y = 0.18;
  group.add(cap);

  const fuseSpark = new THREE.Mesh(new THREE.SphereGeometry(0.055, 8, 8), sparkMat);
  fuseSpark.position.y = 0.23;
  fuseSpark.name = 'fuseSpark';
  group.add(fuseSpark);

  return group;
}

/**
 * Builds the কালবৈশাখী বলয় (Kalboishakhi Shrinking Safe Zone) 3D storm cylinder & glowing perimeter ring.
 */
export function buildKalboishakhiStormWall(): KalboishakhiStormRig {
  const root = new THREE.Group();
  const uniforms = {
    uTime: { value: 0 },
    uIntensity: { value: 0.85 },
  };

  const wallMat = new THREE.ShaderMaterial({
    uniforms,
    transparent: true,
    depthWrite: false,
    side: THREE.DoubleSide,
    vertexShader: `
      varying vec2 vUv;
      void main() {
        vUv = uv;
        gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
      }
    `,
    fragmentShader: `
      uniform float uTime;
      uniform float uIntensity;
      varying vec2 vUv;

      void main() {
        // Swirling Kalboishakhi indigo-violet storm veil with electric lightning bands
        float swirlA = sin(vUv.x * 38.0 + uTime * 2.1 + vUv.y * 8.0);
        float swirlB = cos(vUv.x * 22.0 - uTime * 1.45 - vUv.y * 12.0);
        float cloud = 0.5 + 0.25 * swirlA + 0.25 * swirlB;

        // Vertical fade: crisp glowing rim near ground, wispy tempest fade aloft
        float groundRim = smoothstep(0.14, 0.0, vUv.y);
        float topFade = smoothstep(1.0, 0.12, vUv.y);

        // Occasional electric violet-cyan lightning streak
        float bolt = pow(max(0.0, sin(vUv.x * 75.0 + uTime * 6.5) * cos(vUv.y * 10.0 - uTime * 4.2)), 10.0);

        vec3 stormDeep = vec3(0.32, 0.48, 0.92);
        vec3 stormBright = vec3(0.55, 0.78, 1.0);
        vec3 lightningCol = vec3(0.92, 0.97, 1.0);

        vec3 col = mix(stormDeep, stormBright, cloud * 0.65 + groundRim * 0.55);
        col += lightningCol * (bolt * 0.85 + groundRim * 0.32);

        float alpha = (0.06 + cloud * 0.08 + groundRim * 0.44 + bolt * 0.34) * topFade * uIntensity;
        gl_FragColor = vec4(col, clamp(alpha, 0.0, 0.56));
      }
    `,
  });

  // Unit-radius cylinder scaled dynamically by stormRadius
  const wallGeo = new THREE.CylinderGeometry(1, 1, 38, 64, 1, true);
  wallGeo.translate(0, 19, 0);
  const wallMesh = new THREE.Mesh(wallGeo, wallMat);
  wallMesh.renderOrder = 10;
  root.add(wallMesh);

  // Crisp glowing safe-zone ground perimeter ring
  const groundRing = new THREE.Mesh(
    new THREE.RingGeometry(0.985, 1.0, 64),
    new THREE.MeshBasicMaterial({
      color: 0xa678ff,
      transparent: true,
      opacity: 0.9,
      side: THREE.DoubleSide,
      depthWrite: false,
    }),
  );
  groundRing.rotation.x = -Math.PI / 2;
  groundRing.position.y = 0.08;
  groundRing.renderOrder = 11;
  root.add(groundRing);

  return { root, wallMesh, groundRing, uniforms };
}

/**
 * Creates a crisp 3D floating damage number sprite rendered on an HTML5 CanvasTexture.
 * Headshots: Bold bright red with dark outline, golden crown/starburst accent, larger pop scale.
 * Body shots: Clean bright white/warm yellow with dark outline.
 */
export function createFloatingDamageSprite(
  label: string,
  isHeadshot: boolean,
): { sprite: THREE.Sprite; texture: THREE.CanvasTexture; material: THREE.SpriteMaterial } {
  const canvas = document.createElement('canvas');
  canvas.width = 256;
  canvas.height = 128;
  const ctx = canvas.getContext('2d')!;

  ctx.clearRect(0, 0, canvas.width, canvas.height);
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';

  if (isHeadshot) {
    // Subtle crimson radial glow behind bold red headshot number
    const grad = ctx.createRadialGradient(128, 66, 8, 128, 66, 90);
    grad.addColorStop(0, 'rgba(255, 36, 36, 0.55)');
    grad.addColorStop(1, 'rgba(255, 36, 36, 0)');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, 256, 128);

    // Small "হেডশট!" tag above the number
    ctx.font = '800 22px sans-serif';
    ctx.lineWidth = 5;
    ctx.strokeStyle = 'rgba(24, 4, 4, 0.95)';
    ctx.strokeText('হেডশট!', 128, 28);
    ctx.fillStyle = '#ffe066';
    ctx.fillText('হেডশট!', 128, 28);

    // Bold bright red damage value (e.g., -90)
    ctx.font = '900 66px sans-serif';
    ctx.lineWidth = 10;
    ctx.strokeStyle = 'rgba(28, 3, 3, 0.96)';
    ctx.strokeText(label, 128, 82);
    ctx.fillStyle = '#ff2626';
    ctx.fillText(label, 128, 82);
  } else {
    // Crisp white/warm-yellow body shot damage value (e.g., -30)
    ctx.font = '800 54px sans-serif';
    ctx.lineWidth = 8;
    ctx.strokeStyle = 'rgba(18, 12, 8, 0.92)';
    ctx.strokeText(label, 128, 68);
    ctx.fillStyle = '#fff0a6';
    ctx.fillText(label, 128, 68);
  }

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.needsUpdate = true;

  const material = new THREE.SpriteMaterial({
    map: texture,
    transparent: true,
    depthTest: false,
    depthWrite: false,
  });

  const sprite = new THREE.Sprite(material);
  sprite.renderOrder = 999;
  sprite.scale.set(isHeadshot ? 1.85 : 1.38, isHeadshot ? 0.92 : 0.69, 1);

  return { sprite, texture, material };
}

// ============================================================================
// EXPANDED WEST BENGAL MAP LANDMARKS (1000x1000 BATTLE ROYALE ARENA)
// 1. শালবন ও লাল মাটির টিলা (Red-Soil Sal Forest & Hills)
// 2. পুরনো জমিদার বাড়ি (Abandoned Zamindar Bari with Climbable Terrace)
// 3. পুরনো ট্রাম ডিপো ও বাজার (Old Tram Depot & Bazaar with Vintage Tram)
// 4. নদীর বাঁধানো ঘাট ও নৌকা (Extended Riverbank Ghat, Boats & Huts)
// ============================================================================

export interface ChestAnchor {
  x: number;
  y: number;
  z: number;
  rotY: number;
}

export interface SalForestResult {
  group: THREE.Group;
  colliders: CircleCollider[];
  sanjibaniAnchors: Array<{ x: number; z: number }>;
  chestAnchors: ChestAnchor[];
}

export interface ZamindarBariResult {
  group: THREE.Group;
  colliders: CircleCollider[];
  chestAnchors: ChestAnchor[];
  sanjibaniAnchors: Array<{ x: number; z: number }>;
  getTerraceHeight: (x: number, z: number, currentY?: number) => number;
}

export interface TramDepotResult {
  group: THREE.Group;
  colliders: CircleCollider[];
  chestAnchors: ChestAnchor[];
  sanjibaniAnchors: Array<{ x: number; z: number }>;
}

export interface ExtendedGhatResult {
  group: THREE.Group;
  colliders: CircleCollider[];
  bobbingBoats: THREE.Group[];
  chestAnchors: ChestAnchor[];
  sanjibaniAnchors: Array<{ x: number; z: number }>;
}

// Deterministic pseudo-random helper for repeatable rich natural placement
function seededRand(seed: number): () => number {
  let s = seed >>> 0;
  return () => {
    s = (s * 1664525 + 1013904223) >>> 0;
    return s / 4294967296;
  };
}

/**
 * 1. শালবন ও লাল মাটির টিলা (Red-Soil Sal Forest & Laterite Hills — West & North-West Sectors)
 * Uses high-performance InstancedMesh for 170+ straight-trunked Sal trees and 44 laterite boulders.
 */
export function buildSalForestAndHills(
  getGroundHeight: (x: number, z: number) => number,
): SalForestResult {
  const group = new THREE.Group();
  const colliders: CircleCollider[] = [];
  const sanjibaniAnchors: Array<{ x: number; z: number }> = [];
  const chestAnchors: ChestAnchor[] = [];
  const rand = seededRand(47019);

  // Gather candidate tree spots across both SW laterite hills & NW highlands
  const treeTransforms: Array<{ x: number; y: number; z: number; h: number; r: number; yaw: number }> = [];

  const forestZones = [
    // South-West Sal Forest & Red-Soil Hills (easily reachable west of Village Square)
    { minX: -245, maxX: -52, minZ: -8, maxZ: 175, count: 112 },
    // North-West Sal Forest Hills across the river (west of Old Tram Depot)
    { minX: -255, maxX: -92, minZ: -245, maxZ: -84, count: 68 },
  ];

  for (const zone of forestZones) {
    let placed = 0;
    let guard = 0;
    while (placed < zone.count && guard < zone.count * 8) {
      guard++;
      const x = zone.minX + rand() * (zone.maxX - zone.minX);
      const z = zone.minZ + rand() * (zone.maxZ - zone.minZ);
      // Keep the westbound red-earth trail into Salbon (z in [2, 12], x > -120) open for driving/running
      if (x > -125 && z > 1 && z < 13) continue;
      // Avoid crowding existing trees
      let tooClose = false;
      for (let i = 0; i < treeTransforms.length; i++) {
        const dx = treeTransforms[i].x - x;
        const dz = treeTransforms[i].z - z;
        if (dx * dx + dz * dz < 46) {
          tooClose = true;
          break;
        }
      }
      if (tooClose) continue;

      const y = getGroundHeight(x, z);
      const h = 11.5 + rand() * 5.8;
      const r = 0.42 + rand() * 0.22;
      treeTransforms.push({ x, y, z, h, r, yaw: rand() * Math.PI * 2 });
      colliders.push({ x, z, radius: r + 0.28, height: h, kind: 'tree' });
      placed++;
    }
  }

  // Instanced Sal Trunks (tall straight dark-grey-brown Shorea robusta trunks)
  const trunkGeo = new THREE.CylinderGeometry(0.28, 0.48, 1.0, 8);
  trunkGeo.translate(0, 0.5, 0);
  const trunkMat = new THREE.MeshStandardMaterial({
    color: 0x5c4637,
    roughness: 0.94,
    metalness: 0.02,
  });
  const trunks = new THREE.InstancedMesh(trunkGeo, trunkMat, treeTransforms.length);
  trunks.castShadow = true;
  trunks.receiveShadow = true;

  // Instanced Layered Sal Crowns (lower broad canopy + upper sunny crown)
  const lowerCrownGeo = new THREE.DodecahedronGeometry(2.6, 1);
  const lowerCrownMat = new THREE.MeshStandardMaterial({
    color: 0x2d6126,
    roughness: 0.86,
    metalness: 0.0,
  });
  const lowerCrowns = new THREE.InstancedMesh(lowerCrownGeo, lowerCrownMat, treeTransforms.length);
  lowerCrowns.castShadow = true;
  lowerCrowns.receiveShadow = true;

  const upperCrownGeo = new THREE.DodecahedronGeometry(1.95, 1);
  const upperCrownMat = new THREE.MeshStandardMaterial({
    color: 0x458030,
    roughness: 0.84,
    metalness: 0.0,
  });
  const upperCrowns = new THREE.InstancedMesh(upperCrownGeo, upperCrownMat, treeTransforms.length);
  upperCrowns.castShadow = true;

  const dummy = new THREE.Object3D();
  const tint = new THREE.Color();
  const salLeafPalette = [0x2a5f24, 0x356e28, 0x3f7b2c, 0x255420, 0x4b8732];

  treeTransforms.forEach((t, idx) => {
    dummy.position.set(t.x, t.y - 0.15, t.z);
    dummy.rotation.set((rand() - 0.5) * 0.06, t.yaw, (rand() - 0.5) * 0.06);
    dummy.scale.set(t.r / 0.4, t.h, t.r / 0.4);
    dummy.updateMatrix();
    trunks.setMatrixAt(idx, dummy.matrix);

    const canopyScale = 0.85 + (t.h - 11.5) * 0.065;
    dummy.position.set(t.x, t.y + t.h * 0.72, t.z);
    dummy.rotation.set(0, t.yaw, 0);
    dummy.scale.set(canopyScale * 1.15, canopyScale * 0.88, canopyScale * 1.15);
    dummy.updateMatrix();
    lowerCrowns.setMatrixAt(idx, dummy.matrix);
    tint.setHex(salLeafPalette[idx % salLeafPalette.length]);
    lowerCrowns.setColorAt(idx, tint);

    dummy.position.set(t.x + Math.cos(t.yaw) * 0.4, t.y + t.h * 0.94, t.z + Math.sin(t.yaw) * 0.4);
    dummy.scale.set(canopyScale * 0.92, canopyScale * 0.78, canopyScale * 0.92);
    dummy.updateMatrix();
    upperCrowns.setMatrixAt(idx, dummy.matrix);
    tint.setHex(salLeafPalette[(idx + 2) % salLeafPalette.length]);
    upperCrowns.setColorAt(idx, tint);
  });

  trunks.instanceMatrix.needsUpdate = true;
  lowerCrowns.instanceMatrix.needsUpdate = true;
  if (lowerCrowns.instanceColor) lowerCrowns.instanceColor.needsUpdate = true;
  upperCrowns.instanceMatrix.needsUpdate = true;
  if (upperCrowns.instanceColor) upperCrowns.instanceColor.needsUpdate = true;
  trunks.computeBoundingSphere();
  lowerCrowns.computeBoundingSphere();
  upperCrowns.computeBoundingSphere();
  group.add(trunks, lowerCrowns, upperCrowns);

  // Sniper Laterite Boulders on the red-soil hilltops & ridges for high-ground cover
  const boulderSpots: Array<[number, number, number]> = [
    // Hilltop ridge sniper cover overlooking village & bridge
    [-72, 24, 2.3],
    [-86, 36, 2.8],
    [-95, 42, 2.1],
    [-112, 28, 3.0],
    [-124, 54, 2.6],
    [-138, 66, 3.2],
    [-148, 58, 2.2],
    [-162, 84, 2.9],
    [-176, 40, 2.7],
    [-190, 96, 3.1],
    [-118, 108, 2.5],
    [-84, 92, 2.4],
    [-68, 64, 2.2],
    [-98, 14, 2.1],
    [-145, 18, 2.6],
    [-182, 12, 2.8],
    [-212, 68, 3.2],
    [-222, 128, 2.9],
    [-156, 138, 2.7],
    [-104, 146, 2.5],
    // North-West laterite boulders overlooking Tram Depot & bridge
    [-116, -104, 2.6],
    [-132, -124, 3.0],
    [-154, -142, 2.8],
    [-172, -118, 2.5],
    [-194, -162, 3.2],
    [-144, -184, 2.7],
    [-118, -168, 2.4],
    [-218, -126, 2.9],
    [-186, -208, 3.1],
    [-128, -214, 2.6],
    // Extra flanking crouch-height red rocks
    [-62, 18, 1.65],
    [-78, 48, 1.85],
    [-108, 68, 1.9],
    [-132, 88, 1.8],
    [-166, 112, 2.0],
    [-204, 32, 1.95],
    [-138, -96, 1.8],
    [-164, -164, 1.9],
  ];

  const boulderGeo = new THREE.DodecahedronGeometry(1.0, 1);
  // Slightly crag-displace vertices for authentic laterite rock silhouette
  const bPos = boulderGeo.attributes.position;
  for (let i = 0; i < bPos.count; i++) {
    const vx = bPos.getX(i);
    const vy = bPos.getY(i);
    const vz = bPos.getZ(i);
    const n = 0.86 + Math.abs(Math.sin(vx * 3.7 + vy * 2.9 + vz * 4.1)) * 0.28;
    bPos.setXYZ(i, vx * n, vy * n * 0.78, vz * n);
  }
  boulderGeo.computeVertexNormals();

  const boulderMat = new THREE.MeshStandardMaterial({
    color: 0x8d4935, // Bengal laterite red-grey rock
    roughness: 0.94,
    metalness: 0.04,
  });
  const boulders = new THREE.InstancedMesh(boulderGeo, boulderMat, boulderSpots.length);
  boulders.castShadow = true;
  boulders.receiveShadow = true;

  const rockPalette = [0x8b4834, 0x7c4639, 0x9b543b, 0x6f4338];
  boulderSpots.forEach(([bx, bz, radius], idx) => {
    const by = getGroundHeight(bx, bz);
    dummy.position.set(bx, by + radius * 0.44, bz);
    dummy.rotation.set(rand() * 0.35, rand() * Math.PI * 2, rand() * 0.35);
    dummy.scale.set(radius * 1.12, radius * 0.9, radius * 1.02);
    dummy.updateMatrix();
    boulders.setMatrixAt(idx, dummy.matrix);
    tint.setHex(rockPalette[idx % rockPalette.length]);
    boulders.setColorAt(idx, tint);

    colliders.push({
      x: bx,
      z: bz,
      radius: radius * 0.96,
      height: radius * 1.3,
      kind: 'boulder',
    });
  });

  boulders.instanceMatrix.needsUpdate = true;
  if (boulders.instanceColor) boulders.instanceColor.needsUpdate = true;
  boulders.computeBoundingSphere();
  group.add(boulders);

  // Extra Sanjibani medicinal herb plants ('সঞ্জীবনী গাছ') thriving on the red-soil hills
  const herbCoords: Array<[number, number]> = [
    [-64, 28],
    [-82, 44],
    [-106, 34],
    [-128, 62],
    [-154, 48],
    [-142, 92],
    [-96, 86],
    [-76, 114],
    [-178, 78],
    [-122, 128],
    [-114, -116],
    [-148, -134],
    [-168, -158],
    [-134, -178],
  ];
  for (const [hx, hz] of herbCoords) {
    sanjibaniAnchors.push({ x: hx, z: hz });
  }

  // Hidden Sal Forest Warrior Loot Chests near sniper boulders
  const forestChests: Array<[number, number, number]> = [
    [-91, 39, 0.8],
    [-142, 62, 2.1],
    [-168, 86, -0.6],
    [-136, -128, 1.3],
  ];
  for (const [cx, cz, rotY] of forestChests) {
    chestAnchors.push({ x: cx, y: getGroundHeight(cx, cz), z: cz, rotY });
  }

  return { group, colliders, sanjibaniAnchors, chestAnchors };
}

/**
 * 2. পুরনো জমিদার বাড়ি (Abandoned Zamindar Bari — East / North-East Sector)
 * Multi-room ruined 19th-century Bengali heritage mansion with fluted colonnade pillars,
 * open central courtyard (উঠান), climbable stone terrace stairs, walkable 2nd-floor terrace (y=4.6m),
 * and high-tier Warrior Loot Chests inside rooms and on the rooftop terrace.
 */
export function buildZamindarBari(centerX: number, centerZ: number): ZamindarBariResult {
  const group = new THREE.Group();
  group.position.set(centerX, 0, centerZ);
  const colliders: CircleCollider[] = [];
  const chestAnchors: ChestAnchor[] = [];
  const sanjibaniAnchors: Array<{ x: number; z: number }> = [];

  const terraceY = 4.6;

  // Materials: weathered Bengal ochre-lime plaster, exposed terracotta brick, mossy stone
  const ochreWallMat = new THREE.MeshStandardMaterial({
    color: 0xc58d58,
    roughness: 0.9,
    metalness: 0.02,
  });
  const brickDecayMat = new THREE.MeshStandardMaterial({
    color: 0x8f412e,
    roughness: 0.94,
    metalness: 0.02,
  });
  const creamTrimMat = new THREE.MeshStandardMaterial({
    color: 0xe3d2b4,
    roughness: 0.84,
    metalness: 0.03,
  });
  const stoneFloorMat = new THREE.MeshStandardMaterial({
    color: 0x9b9081,
    roughness: 0.92,
    metalness: 0.04,
  });
  const courtyardTileMat = new THREE.MeshStandardMaterial({
    color: 0xb7a185,
    roughness: 0.88,
    metalness: 0.02,
  });
  const mossMat = new THREE.MeshStandardMaterial({
    color: 0x3b6329,
    roughness: 0.95,
  });

  // Raised stone estate plinth (38m x 32m)
  const plinth = new THREE.Mesh(new THREE.BoxGeometry(38, 0.24, 32), stoneFloorMat);
  plinth.position.set(0, 0.1, 0);
  plinth.receiveShadow = true;
  group.add(plinth);

  // Checker-bordered inner courtyard floor (উঠান)
  const courtyard = new THREE.Mesh(new THREE.BoxGeometry(16, 0.28, 12), courtyardTileMat);
  courtyard.position.set(0, 0.11, 0);
  courtyard.receiveShadow = true;
  group.add(courtyard);

  // Ruined Heritage Tulsi Mancha / Courtyard Pedestal in the center of the courtyard
  const manchaBase = new THREE.Mesh(new THREE.BoxGeometry(2.6, 0.7, 2.6), brickDecayMat);
  manchaBase.position.set(0, 0.5, 0);
  manchaBase.castShadow = true;
  manchaBase.receiveShadow = true;
  group.add(manchaBase);

  const manchaPillar = new THREE.Mesh(new THREE.BoxGeometry(1.5, 1.05, 1.5), ochreWallMat);
  manchaPillar.position.set(0, 1.25, 0);
  manchaPillar.castShadow = true;
  group.add(manchaPillar);

  const manchaCap = new THREE.Mesh(new THREE.BoxGeometry(1.9, 0.25, 1.9), creamTrimMat);
  manchaCap.position.set(0, 1.85, 0);
  group.add(manchaCap);
  colliders.push({ x: centerX, z: centerZ, radius: 1.5, height: 2.0, kind: 'ruin' });

  // Helper to add a solid wall segment with evenly spaced circle colliders along its length
  const addWallSegment = (
    lx: number,
    lz: number,
    w: number,
    h: number,
    d: number,
    mat: THREE.Material = ochreWallMat,
    withColliders = true,
  ) => {
    const mesh = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat);
    mesh.position.set(lx, h * 0.5 + 0.12, lz);
    mesh.castShadow = true;
    mesh.receiveShadow = true;
    group.add(mesh);

    if (!withColliders) return;
    if (w >= d) {
      const steps = Math.max(1, Math.round(w / 2.2));
      for (let i = 0; i < steps; i++) {
        const px = lx - w * 0.5 + ((i + 0.5) / steps) * w;
        colliders.push({
          x: centerX + px,
          z: centerZ + lz,
          radius: Math.max(0.55, d * 0.6),
          height: h,
          kind: 'ruin',
        });
      }
    } else {
      const steps = Math.max(1, Math.round(d / 2.2));
      for (let i = 0; i < steps; i++) {
        const pz = lz - d * 0.5 + ((i + 0.5) / steps) * d;
        colliders.push({
          x: centerX + lx,
          z: centerZ + pz,
          radius: Math.max(0.55, w * 0.6),
          height: h,
          kind: 'ruin',
        });
      }
    }
  };

  // Perimeter Mansion Walls (32m wide x 26m deep, with grand wide arched gateways on West, South & North!)
  // North Wing outer wall (z = -13, wide central arch gap x in [-4, 4])
  addWallSegment(-10, -13, 12, terraceY, 0.9);
  addWallSegment(10, -13, 12, terraceY, 0.9);
  // South Wing outer wall (z = +13, grand entrance gap x in [-4.5, 4.5])
  addWallSegment(-10.25, 13, 11.5, terraceY, 0.9);
  addWallSegment(10.25, 13, 11.5, terraceY, 0.9);
  // West Wing outer wall (x = -16, village-facing grand entrance gap z in [-4, 4])
  addWallSegment(-16, -8.5, 0.9, terraceY, 9);
  addWallSegment(-16, 8.5, 0.9, terraceY, 9);
  // East Wing outer wall (x = +16, rear garden doorway gap z in [-3.5, 3.5])
  addWallSegment(16, -8.25, 0.9, terraceY, 9.5);
  addWallSegment(16, 8.25, 0.9, terraceY, 9.5);

  // Interior Room Partition Walls (creates 4 distinct corner halls/rooms with wide walkable arches)
  // North-West & North-East room dividers
  addWallSegment(-12, -6.5, 6.2, terraceY, 0.7, brickDecayMat);
  addWallSegment(12, -6.5, 6.2, terraceY, 0.7, brickDecayMat);
  // South-West & South-East room dividers
  addWallSegment(-12, 6.5, 6.2, terraceY, 0.7, brickDecayMat);
  addWallSegment(12, 6.5, 6.2, terraceY, 0.7, brickDecayMat);

  // Decorative exposed red-brick decay patches & mossy creepers along walls
  const patchCoords: Array<[number, number, number, number, number]> = [
    [-15.48, -10.2, 0.16, 2.2, 2.8],
    [15.48, 9.8, 0.16, 2.4, 2.6],
    [-9.5, 13.52, 3.2, 1.9, 0.16],
    [11.2, -13.52, 2.8, 2.1, 0.16],
  ];
  for (const [px, pz, pw, ph, pd] of patchCoords) {
    const patch = new THREE.Mesh(new THREE.BoxGeometry(pw, ph, pd), brickDecayMat);
    patch.position.set(px, 1.6, pz);
    group.add(patch);
  }

  // Iconic Neoclassical Bengali Colonnade Pillars framing the inner courtyard (উঠান) & grand West portico
  const pillarGeo = new THREE.CylinderGeometry(0.42, 0.48, terraceY - 0.3, 12);
  const capitalGeo = new THREE.BoxGeometry(1.18, 0.32, 1.18);
  const baseGeo = new THREE.BoxGeometry(1.15, 0.36, 1.15);

  const pillarPositions: Array<[number, number]> = [
    // Courtyard inner colonnade
    [-8, -6.5],
    [-2.8, -6.5],
    [2.8, -6.5],
    [8, -6.5],
    [-8, 6.5],
    [-2.8, 6.5],
    [2.8, 6.5],
    [8, 6.5],
    [-8, 0],
    [8, 0],
    // Grand West Heritage Portico (facing village approach)
    [-18.6, -5.2],
    [-18.6, -2.0],
    [-18.6, 2.0],
    [-18.6, 5.2],
  ];

  for (const [px, pz] of pillarPositions) {
    const shaft = new THREE.Mesh(pillarGeo, creamTrimMat);
    shaft.position.set(px, terraceY * 0.5, pz);
    shaft.castShadow = true;
    shaft.receiveShadow = true;
    group.add(shaft);

    const base = new THREE.Mesh(baseGeo, stoneFloorMat);
    base.position.set(px, 0.28, pz);
    group.add(base);

    const cap = new THREE.Mesh(capitalGeo, creamTrimMat);
    cap.position.set(px, terraceY - 0.12, pz);
    group.add(cap);

    colliders.push({ x: centerX + px, z: centerZ + pz, radius: 0.58, height: terraceY, kind: 'ruin' });
  }

  // Grand West Portico Triangular Heritage Pediment Arch
  const porticoRoof = new THREE.Mesh(new THREE.BoxGeometry(3.4, 0.5, 12.2), ochreWallMat);
  porticoRoof.position.set(-17.4, terraceY + 0.15, 0);
  porticoRoof.castShadow = true;
  group.add(porticoRoof);

  const pediment = new THREE.Mesh(new THREE.ConeGeometry(4.6, 2.2, 4), brickDecayMat);
  pediment.rotation.y = Math.PI / 4;
  pediment.scale.set(0.42, 1.0, 1.65);
  pediment.position.set(-17.8, terraceY + 1.45, 0);
  group.add(pediment);

  // Walkable 2nd-Floor Rooftop Terrace Slabs (surrounding the open central courtyard!)
  // North Terrace Wing: x in [-16.2, 16.2], z in [-13.2, -6.2]
  const northTerrace = new THREE.Mesh(new THREE.BoxGeometry(32.4, 0.42, 7.2), stoneFloorMat);
  northTerrace.position.set(0, terraceY - 0.18, -9.7);
  northTerrace.castShadow = true;
  northTerrace.receiveShadow = true;
  group.add(northTerrace);

  // South Terrace Wing: x in [-16.2, 16.2], z in [6.2, 13.2]
  const southTerrace = new THREE.Mesh(new THREE.BoxGeometry(32.4, 0.42, 7.2), stoneFloorMat);
  southTerrace.position.set(0, terraceY - 0.18, 9.7);
  southTerrace.castShadow = true;
  southTerrace.receiveShadow = true;
  group.add(southTerrace);

  // West Terrace Wing: x in [-16.2, -7.8], z in [-6.4, 6.4]
  const westTerrace = new THREE.Mesh(new THREE.BoxGeometry(8.6, 0.42, 13.0), stoneFloorMat);
  westTerrace.position.set(-12.0, terraceY - 0.18, 0);
  westTerrace.castShadow = true;
  westTerrace.receiveShadow = true;
  group.add(westTerrace);

  // East Terrace Wing: x in [7.8, 16.2], z in [-6.4, 6.4]
  const eastTerrace = new THREE.Mesh(new THREE.BoxGeometry(8.6, 0.42, 13.0), stoneFloorMat);
  eastTerrace.position.set(12.0, terraceY - 0.18, 0);
  eastTerrace.castShadow = true;
  eastTerrace.receiveShadow = true;
  group.add(eastTerrace);

  // Crumbling Heritage Terrace Parapet Railings (low waist-high sniper cover on 2nd floor!)
  const addParapet = (lx: number, lz: number, w: number, h: number, d: number) => {
    const p = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), ochreWallMat);
    p.position.set(lx, terraceY + h * 0.5, lz);
    p.castShadow = true;
    p.receiveShadow = true;
    group.add(p);
  };
  addParapet(-8, -13.0, 14, 1.05, 0.42);
  addParapet(9.5, -13.0, 11, 0.85, 0.42);
  addParapet(-9, 13.0, 12, 1.05, 0.42);
  addParapet(8.5, 13.0, 13, 0.92, 0.42);
  addParapet(-16.0, -5.5, 0.42, 1.05, 14);
  addParapet(-16.0, 7.5, 0.42, 0.8, 10);
  addParapet(16.0, 0, 0.42, 1.0, 24);

  // Ruined corner roof domes / ornate Zamindar rooftop turrets
  for (const [tx, tz] of [
    [-14.8, -11.8],
    [14.8, -11.8],
    [-14.8, 11.8],
    [14.8, 11.8],
  ]) {
    const turret = new THREE.Mesh(new THREE.CylinderGeometry(1.15, 1.35, 1.8, 10), brickDecayMat);
    turret.position.set(tx, terraceY + 0.9, tz);
    turret.castShadow = true;
    group.add(turret);

    const dome = new THREE.Mesh(
      new THREE.SphereGeometry(1.2, 12, 8, 0, Math.PI * 2, 0, Math.PI * 0.55),
      ochreWallMat,
    );
    dome.position.set(tx, terraceY + 1.75, tz);
    group.add(dome);
  }

  // Moss clumps draping over the weathered stone eaves
  for (let m = 0; m < 10; m++) {
    const ang = (m / 10) * Math.PI * 2;
    const moss = new THREE.Mesh(new THREE.DodecahedronGeometry(0.65, 0), mossMat);
    moss.position.set(Math.cos(ang) * 15.6, terraceY + 0.2, Math.sin(ang) * 12.6);
    moss.scale.set(1.3, 0.55, 1.1);
    group.add(moss);
  }

  // CLIMBABLE TERRACE STAIRCASES (Two grand stone flights inside the courtyard!)
  // Staircase A (South-East Courtyard): x in [4.2, 7.6], ramps from z = +4.8 (y = 0) up to z = -6.2 (y = terraceY)
  // Staircase B (North-West Courtyard): x in [-7.6, -4.2], ramps from z = -4.8 (y = 0) up to z = +6.2 (y = terraceY)
  const buildStaircase = (xCenter: number, zBottom: number, zTop: number) => {
    const steps = 18;
    const width = 3.2;
    const stepDepth = Math.abs(zTop - zBottom) / steps;
    const stepRise = terraceY / steps;
    const dir = zTop > zBottom ? 1 : -1;

    for (let s = 0; s < steps; s++) {
      const h = (s + 1) * stepRise;
      const sz = zBottom + dir * (s + 0.5) * stepDepth;
      const tread = new THREE.Mesh(new THREE.BoxGeometry(width, h, stepDepth + 0.08), stoneFloorMat);
      tread.position.set(xCenter, h * 0.5, sz);
      tread.castShadow = true;
      tread.receiveShadow = true;
      group.add(tread);
    }

    // Low decorative brick stair stringer / balustrade on the courtyard-facing inner edge
    const innerEdgeX = xCenter > 0 ? xCenter - width * 0.5 - 0.14 : xCenter + width * 0.5 + 0.14;
    const rampLen = Math.hypot(Math.abs(zTop - zBottom), terraceY);
    const rail = new THREE.Mesh(new THREE.BoxGeometry(0.26, 0.72, rampLen), brickDecayMat);
    rail.position.set(innerEdgeX, terraceY * 0.5 + 0.36, (zBottom + zTop) * 0.5);
    rail.rotation.x = dir * -Math.atan2(terraceY, Math.abs(zTop - zBottom));
    rail.castShadow = true;
    group.add(rail);
  };

  buildStaircase(5.9, 4.8, -6.2); // Climb North to North Terrace
  buildStaircase(-5.9, -4.8, 6.2); // Climb South to South Terrace

  // Exact analytical elevation function for climbing the Zamindar Bari stairs & walking the 2nd-floor terrace!
  const getTerraceHeight = (wx: number, wz: number, currentY?: number): number => {
    const lx = wx - centerX;
    const lz = wz - centerZ;
    // Quick bounding-box reject
    if (lx < -17.5 || lx > 17.5 || lz < -14.2 || lz > 14.2) return 0;

    // Staircase A (East Courtyard): x in [4.1, 7.7], z from +4.9 (y=0) up to -6.3 (y=terraceY)
    if (lx >= 4.1 && lx <= 7.7 && lz <= 4.9 && lz >= -6.3) {
      const t = THREE.MathUtils.clamp((4.9 - lz) / (4.9 - -6.3), 0, 1);
      return Math.max(0.18, t * terraceY);
    }

    // Staircase B (West Courtyard): x in [-7.7, -4.1], z from -4.9 (y=0) up to +6.3 (y=terraceY)
    if (lx >= -7.7 && lx <= -4.1 && lz >= -4.9 && lz <= 6.3) {
      const t = THREE.MathUtils.clamp((lz - -4.9) / (6.3 - -4.9), 0, 1);
      return Math.max(0.18, t * terraceY);
    }

    // Walkable 2nd-floor terrace ring (only when already elevated from stairs; downstairs rooms stay at y=0.18!)
    const onNorthRoof = lx >= -16.1 && lx <= 16.1 && lz >= -13.1 && lz <= -6.1;
    const onSouthRoof = lx >= -16.1 && lx <= 16.1 && lz >= 6.1 && lz <= 13.1;
    const onWestRoof = lx >= -16.1 && lx <= -7.7 && lz >= -6.3 && lz <= 6.3;
    const onEastRoof = lx >= 7.7 && lx <= 16.1 && lz >= -6.3 && lz <= 6.3;
    if (onNorthRoof || onSouthRoof || onWestRoof || onEastRoof) {
      if (currentY !== undefined && currentY >= 2.2) {
        return terraceY;
      }
      return 0.18;
    }

    return 0.18; // Ground-floor courtyard plinth
  };

  // High-tier Warrior Loot Chests inside the ground-floor rooms AND atop the 2nd-floor terrace!
  const rawChests: Array<[number, number, number, number]> = [
    // Rooftop terrace high-tier loot chests (y = terraceY)
    [-12.2, terraceY, -9.8, 0.3],
    [12.2, terraceY, -9.8, -0.4],
    [0.0, terraceY, 9.8, Math.PI],
    [-12.0, terraceY, 0.0, Math.PI * 0.5],
    // Ground-floor courtyard & hall chests (y = 0.18)
    [-12.2, 0.18, -9.6, 0.4],
    [12.2, 0.18, 9.6, -2.5],
    [0.0, 0.18, -9.8, 0.0],
  ];
  for (const [lx, ly, lz, rotY] of rawChests) {
    chestAnchors.push({ x: centerX + lx, y: ly, z: centerZ + lz, rotY });
  }

  // Medicinal herbs growing in the ruined garden outside the Zamindar Bari
  sanjibaniAnchors.push(
    { x: centerX - 21, z: centerZ - 9 },
    { x: centerX - 21, z: centerZ + 10 },
    { x: centerX + 21, z: centerZ - 7 },
    { x: centerX + 4, z: centerZ + 17 },
  );

  return { group, colliders, chestAnchors, sanjibaniAnchors, getTerraceHeight };
}

/**
 * Builds a classic composite vintage Kolkata Tram Car (heritage blue-and-cream CTC tram)
 * with rounded cabs, slatted windows, wheel bogies, headlights, and rooftop diamond pantograph.
 */
function buildVintageKolkataTram(): THREE.Group {
  const tram = new THREE.Group();

  const creamPaint = new THREE.MeshStandardMaterial({
    color: 0xf4ecd8,
    roughness: 0.46,
    metalness: 0.12,
  });
  const heritageBlue = new THREE.MeshStandardMaterial({
    color: 0x1e5c94,
    roughness: 0.42,
    metalness: 0.18,
  });
  const redStripe = new THREE.MeshStandardMaterial({
    color: 0xb92c27,
    roughness: 0.5,
  });
  const roofMat = new THREE.MeshStandardMaterial({
    color: 0x626a72,
    roughness: 0.72,
    metalness: 0.35,
  });
  const darkIron = new THREE.MeshStandardMaterial({
    color: 0x24282e,
    roughness: 0.55,
    metalness: 0.75,
  });
  const windowGlass = new THREE.MeshStandardMaterial({
    color: 0x203547,
    roughness: 0.16,
    metalness: 0.65,
  });
  const lampMat = new THREE.MeshStandardMaterial({
    color: 0xfff0b2,
    emissive: 0xffc64d,
    emissiveIntensity: 1.4,
  });

  const len = 13.8;
  const w = 2.45;

  // Undercarriage frame & twin bogie trucks with 4 steel wheelsets
  const chassis = new THREE.Mesh(new THREE.BoxGeometry(len - 0.8, 0.48, w - 0.25), darkIron);
  chassis.position.set(0, 0.52, 0);
  chassis.castShadow = true;
  tram.add(chassis);

  const wheelGeo = new THREE.CylinderGeometry(0.36, 0.36, 0.18, 14);
  wheelGeo.rotateX(Math.PI / 2);
  for (const bx of [-4.6, -2.9, 2.9, 4.6]) {
    for (const bz of [-0.88, 0.88]) {
      const wheel = new THREE.Mesh(wheelGeo, darkIron);
      wheel.position.set(bx, 0.36, bz);
      tram.add(wheel);
    }
  }

  // Lower heritage blue body skirt
  const lowerBody = new THREE.Mesh(new THREE.BoxGeometry(len, 1.12, w), heritageBlue);
  lowerBody.position.set(0, 1.24, 0);
  lowerBody.castShadow = true;
  lowerBody.receiveShadow = true;
  tram.add(lowerBody);

  // Crimson waist trim band
  const belt = new THREE.Mesh(new THREE.BoxGeometry(len + 0.06, 0.14, w + 0.06), redStripe);
  belt.position.set(0, 1.84, 0);
  tram.add(belt);

  // Upper cream window bay & dark glass strip
  const upperBody = new THREE.Mesh(new THREE.BoxGeometry(len - 0.1, 1.08, w - 0.04), creamPaint);
  upperBody.position.set(0, 2.42, 0);
  upperBody.castShadow = true;
  tram.add(upperBody);

  const sideGlass = new THREE.Mesh(new THREE.BoxGeometry(len - 1.2, 0.72, w + 0.02), windowGlass);
  sideGlass.position.set(0, 2.44, 0);
  tram.add(sideGlass);

  // Wooden window mullions along both sides
  for (let i = -5; i <= 5; i++) {
    const mullion = new THREE.Mesh(new THREE.BoxGeometry(0.11, 0.78, w + 0.08), creamPaint);
    mullion.position.set(i * 1.12, 2.44, 0);
    tram.add(mullion);
  }

  // Arched Clerestory Roof
  const mainRoof = new THREE.Mesh(new THREE.BoxGeometry(len + 0.25, 0.26, w + 0.18), roofMat);
  mainRoof.position.set(0, 3.08, 0);
  mainRoof.castShadow = true;
  tram.add(mainRoof);

  const clerestory = new THREE.Mesh(new THREE.BoxGeometry(len - 2.2, 0.22, w * 0.56), creamPaint);
  clerestory.position.set(0, 3.28, 0);
  tram.add(clerestory);

  // Front & Rear Cabs (brass cowcatchers, round headlights, route boards)
  for (const sx of [-1, 1]) {
    const cabGlass = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.72, w - 0.46), windowGlass);
    cabGlass.position.set(sx * (len * 0.5 - 0.04), 2.44, 0);
    tram.add(cabGlass);

    const lamp = new THREE.Mesh(new THREE.CylinderGeometry(0.18, 0.18, 0.12, 12), lampMat);
    lamp.rotation.z = Math.PI / 2;
    lamp.position.set(sx * (len * 0.5 + 0.04), 1.48, 0);
    tram.add(lamp);

    const bumper = new THREE.Mesh(new THREE.BoxGeometry(0.32, 0.22, w * 0.88), darkIron);
    bumper.position.set(sx * (len * 0.5 + 0.14), 0.74, 0);
    tram.add(bumper);

    // Classic Kolkata route number sign ("36")
    const destBox = new THREE.Mesh(new THREE.BoxGeometry(0.2, 0.28, 1.05), darkIron);
    destBox.position.set(sx * (len * 0.5 - 0.02), 3.12, 0);
    tram.add(destBox);
  }

  // Steel Diamond Overhead Pantograph on roof
  const pantoBase = new THREE.Mesh(new THREE.BoxGeometry(1.1, 0.14, 1.1), darkIron);
  pantoBase.position.set(0, 3.45, 0);
  tram.add(pantoBase);

  const armGeo = new THREE.BoxGeometry(0.06, 1.45, 0.06);
  for (const [ax, rotZ] of [
    [-0.36, -0.52],
    [0.36, 0.52],
  ]) {
    const lowerArm = new THREE.Mesh(armGeo, darkIron);
    lowerArm.position.set(ax, 4.05, 0);
    lowerArm.rotation.z = rotZ;
    tram.add(lowerArm);
  }
  const collectorBar = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.08, 1.75), darkIron);
  collectorBar.position.set(0, 4.65, 0);
  tram.add(collectorBar);

  return tram;
}

/**
 * 3. পুরনো ট্রাম ডিপো ও বাজার (Old Tram Depot & Kolkata Bazaar — North Bank across Howrah Bridge)
 * Features granite street plaza, parallel steel tram rails, corrugated-iron Tram Depot shed,
 * static vintage Kolkata Tram Car, colorful striped-awning bazaar stalls, and parked yellow taxis.
 */
export function buildOldTramDepotAndBazaar(
  centerX: number,
  centerZ: number,
  buildTaxiFn: () => THREE.Group,
): TramDepotResult {
  const group = new THREE.Group();
  group.position.set(centerX, 0, centerZ);
  const colliders: CircleCollider[] = [];
  const chestAnchors: ChestAnchor[] = [];
  const sanjibaniAnchors: Array<{ x: number; z: number }> = [];

  const asphaltMat = new THREE.MeshStandardMaterial({
    color: 0x4b4e54,
    roughness: 0.9,
    metalness: 0.05,
    polygonOffset: true,
    polygonOffsetFactor: -1,
    polygonOffsetUnits: -1,
  });
  const cobblestoneMat = new THREE.MeshStandardMaterial({
    color: 0x6f6860,
    roughness: 0.92,
    polygonOffset: true,
    polygonOffsetFactor: -1,
    polygonOffsetUnits: -1,
  });
  const railSteelMat = new THREE.MeshStandardMaterial({
    color: 0xaab4be,
    roughness: 0.35,
    metalness: 0.85,
  });
  const brickWallMat = new THREE.MeshStandardMaterial({
    color: 0x9b4531,
    roughness: 0.88,
  });
  const tinRoofMat = new THREE.MeshStandardMaterial({
    color: 0x6b7882,
    roughness: 0.58,
    metalness: 0.52,
  });
  const woodMat = new THREE.MeshStandardMaterial({
    color: 0x6d472b,
    roughness: 0.9,
  });

  // Main North-Bank Kolkata Street Plaza (150m wide x 96m deep)
  const streetPlaza = new THREE.Mesh(new THREE.PlaneGeometry(156, 98), asphaltMat);
  streetPlaza.rotation.x = -Math.PI / 2;
  streetPlaza.position.set(0, 0.04, 0);
  streetPlaza.receiveShadow = true;
  group.add(streetPlaza);

  // Raised sidewalk promenade along the Bazaar & Tramway
  const tramBed = new THREE.Mesh(new THREE.PlaneGeometry(148, 9.6), cobblestoneMat);
  tramBed.rotation.x = -Math.PI / 2;
  tramBed.position.set(0, 0.06, 14);
  tramBed.receiveShadow = true;
  group.add(tramBed);

  // Parallel Steel Tram Tracks (Double-track Kolkata tramway along local z = +12 and z = +16.5)
  const railGeo = new THREE.BoxGeometry(146, 0.07, 0.12);
  for (const rz of [11.1, 12.6, 15.6, 17.1]) {
    const rail = new THREE.Mesh(railGeo, railSteelMat);
    rail.position.set(0, 0.07, rz);
    group.add(rail);
  }
  // Curved spur rails entering the Tram Depot Shed on the west side (local x = -36, z = -12)
  const depotRailGeo = new THREE.BoxGeometry(0.12, 0.07, 36);
  for (const rx of [-37.75, -36.25, -32.75, -31.25]) {
    const rail = new THREE.Mesh(depotRailGeo, railSteelMat);
    rail.position.set(rx, 0.07, -6);
    group.add(rail);
  }

  // Overhead Tram Catenary Poles lining the street
  const poleMat = new THREE.MeshStandardMaterial({
    color: 0x3b444c,
    roughness: 0.55,
    metalness: 0.65,
  });
  for (let px = -56; px <= 56; px += 28) {
    const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.14, 0.18, 6.2, 8), poleMat);
    pole.position.set(px, 3.1, 8.8);
    pole.castShadow = true;
    group.add(pole);

    const arm = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.12, 7.6), poleMat);
    arm.position.set(px, 5.9, 12.6);
    group.add(arm);

    colliders.push({ x: centerX + px, z: centerZ + 8.8, radius: 0.35, height: 6.2, kind: 'prop' });
  }

  // Static Vintage Kolkata Tram Car #1 parked on the main tramway tracks (central CQB cover!)
  const tram1 = buildVintageKolkataTram();
  tram1.position.set(6, 0.08, 11.85);
  group.add(tram1);
  // 5 solid circle colliders covering the 13.8m x 2.45m tram hull cleanly
  for (const ox of [-5.4, -2.7, 0, 2.7, 5.4]) {
    colliders.push({
      x: centerX + 6 + ox,
      z: centerZ + 11.85,
      radius: 1.4,
      height: 3.4,
      kind: 'tram',
    });
  }

  // Static Vintage Tram Car #2 parked inside the Tram Depot Shed bay (North-South orientation)
  const tram2 = buildVintageKolkataTram();
  tram2.position.set(-37, 0.08, -14);
  tram2.rotation.y = Math.PI / 2;
  group.add(tram2);
  for (const oz of [-5.4, -2.7, 0, 2.7, 5.4]) {
    colliders.push({
      x: centerX - 37,
      z: centerZ - 14 + oz,
      radius: 1.4,
      height: 3.4,
      kind: 'tram',
    });
  }

  // Heritage Brick & Corrugated-Tin Tram Depot Shed (open front bay at local x = -34.5, z = -16)
  const depotGroup = new THREE.Group();
  depotGroup.position.set(-34.5, 0, -16);
  const depotBackWall = new THREE.Mesh(new THREE.BoxGeometry(18, 6.2, 0.8), brickWallMat);
  depotBackWall.position.set(0, 3.1, -11);
  depotBackWall.castShadow = true;
  depotBackWall.receiveShadow = true;
  depotGroup.add(depotBackWall);

  for (const sx of [-9, 9]) {
    const sideWall = new THREE.Mesh(new THREE.BoxGeometry(0.8, 6.2, 22), brickWallMat);
    sideWall.position.set(sx, 3.1, 0);
    sideWall.castShadow = true;
    sideWall.receiveShadow = true;
    depotGroup.add(sideWall);
    for (let pz = -10; pz <= 10; pz += 3.3) {
      colliders.push({
        x: centerX - 34.5 + sx,
        z: centerZ - 16 + pz,
        radius: 0.75,
        height: 6.2,
        kind: 'ruin',
      });
    }
  }
  for (let px = -8; px <= 8; px += 3.2) {
    colliders.push({
      x: centerX - 34.5 + px,
      z: centerZ - 27,
      radius: 0.75,
      height: 6.2,
      kind: 'ruin',
    });
  }

  // Arched corrugated-iron depot roof spanning over the two tram bays
  const depotRoof = new THREE.Mesh(
    new THREE.CylinderGeometry(9.6, 9.6, 23, 14, 1, true, 0, Math.PI),
    tinRoofMat,
  );
  depotRoof.rotation.z = Math.PI / 2;
  depotRoof.rotation.y = Math.PI / 2;
  depotRoof.scale.set(1, 1, 0.42);
  depotRoof.position.set(0, 6.0, 0);
  depotRoof.castShadow = true;
  depotGroup.add(depotRoof);
  group.add(depotGroup);

  // Classic Kolkata Bazaar Market Stalls with vibrant striped cloth awnings (8 stalls forming CQB alleys)
  const awningColors = [0xd1382d, 0xe89c24, 0x1d7d74, 0xc24a2b, 0x2c649c, 0xd86e27];
  const stallDefs: Array<{ x: number; z: number; rotY: number; colorIdx: number }> = [
    { x: -12, z: -4, rotY: 0, colorIdx: 0 },
    { x: -2, z: -4, rotY: 0.06, colorIdx: 1 },
    { x: 10, z: -4, rotY: -0.05, colorIdx: 2 },
    { x: 22, z: -4, rotY: 0.04, colorIdx: 3 },
    { x: 34, z: -4, rotY: -0.08, colorIdx: 4 },
    { x: 12, z: -18, rotY: Math.PI, colorIdx: 5 },
    { x: 24, z: -18, rotY: Math.PI + 0.05, colorIdx: 0 },
    { x: 36, z: -18, rotY: Math.PI - 0.06, colorIdx: 1 },
  ];

  const cratePalette = [0xb67b3e, 0xc95232, 0x4f8a36, 0xe0b23c];
  for (const st of stallDefs) {
    const stall = new THREE.Group();
    stall.position.set(st.x, 0, st.z);
    stall.rotation.y = st.rotY;

    // Wooden merchant counter
    const counter = new THREE.Mesh(new THREE.BoxGeometry(5.2, 1.05, 1.65), woodMat);
    counter.position.set(0, 0.525, 0);
    counter.castShadow = true;
    counter.receiveShadow = true;
    stall.add(counter);

    // 4 bamboo/wood corner posts
    for (const [px, pz] of [
      [-2.4, -0.75],
      [2.4, -0.75],
      [-2.4, 0.75],
      [2.4, 0.75],
    ]) {
      const post = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.09, 2.85, 6), woodMat);
      post.position.set(px, 1.425, pz);
      stall.add(post);
    }

    // Sloped colorful cloth awning canopy
    const awningMat = new THREE.MeshStandardMaterial({
      color: awningColors[st.colorIdx % awningColors.length],
      roughness: 0.85,
      side: THREE.DoubleSide,
    });
    const awning = new THREE.Mesh(new THREE.BoxGeometry(5.6, 0.14, 2.55), awningMat);
    awning.position.set(0, 2.9, 0.15);
    awning.rotation.x = 0.18;
    awning.castShadow = true;
    stall.add(awning);

    // Colorful produce baskets & spice sacks atop counter
    for (let k = -1; k <= 1; k++) {
      const basketMat = new THREE.MeshStandardMaterial({
        color: cratePalette[(st.colorIdx + k + 4) % cratePalette.length],
        roughness: 0.88,
      });
      const basket = new THREE.Mesh(new THREE.CylinderGeometry(0.42, 0.34, 0.42, 8), basketMat);
      basket.position.set(k * 1.4, 1.24, 0);
      stall.add(basket);
    }

    group.add(stall);
    // Two circle colliders spanning the 5.2m stall counter for crisp CQB cover
    const cosR = Math.cos(st.rotY);
    const sinR = Math.sin(st.rotY);
    for (const ox of [-1.4, 1.4]) {
      colliders.push({
        x: centerX + st.x + ox * cosR,
        z: centerZ + st.z - ox * sinR,
        radius: 1.22,
        height: 1.35,
        kind: 'stall',
      });
    }
  }

  // 3 Iconic Parked Yellow Ambassador Taxis angled along the Bazaar & Tramway for tactical CQB cover
  const taxiDefs: Array<{ x: number; z: number; rotY: number }> = [
    { x: -16, z: 24, rotY: 0.25 },
    { x: 26, z: 23, rotY: -0.45 },
    { x: 46, z: 4, rotY: 1.35 },
  ];
  for (const td of taxiDefs) {
    const taxi = buildTaxiFn();
    taxi.position.set(td.x, 0, td.z);
    taxi.rotation.y = td.rotY;
    group.add(taxi);

    const cosY = Math.cos(td.rotY);
    const sinY = Math.sin(td.rotY);
    for (const ox of [-1.15, 1.15]) {
      colliders.push({
        x: centerX + td.x + ox * cosY,
        z: centerZ + td.z - ox * sinY,
        radius: 1.38,
        height: 1.85,
        kind: 'taxi',
      });
    }
  }

  // Heritage Kolkata CQB Loot Chests inside Tram Depot, beside Vintage Tram, and in Bazaar alleys
  const depotChests: Array<[number, number, number]> = [
    [-31.5, -18, 0.2], // Inside Tram Depot Shed
    [-26, -8, 1.4], // Depot entrance
    [6, 15.0, Math.PI], // Beside vintage Kolkata Tram Car
    [4, -10.5, 0.0], // Bazaar central alley
    [29, -11.0, -0.5], // East Bazaar courtyard
    [40, 20, -1.2], // Near parked yellow taxi
  ];
  for (const [cx, cz, rotY] of depotChests) {
    chestAnchors.push({ x: centerX + cx, y: 0.06, z: centerZ + cz, rotY });
  }

  // Sanjibani healing herbs in planter pockets along the North-Bank promenade
  sanjibaniAnchors.push(
    { x: centerX - 48, z: centerZ + 22 },
    { x: centerX + 52, z: centerZ + 18 },
    { x: centerX + 18, z: centerZ - 26 },
    { x: centerX - 18, z: centerZ - 24 },
  );

  return { group, colliders, chestAnchors, sanjibaniAnchors };
}

/**
 * 4. নদীর বাঁধানো ঘাট ও নৌকা (Extended Riverbank Ghat, Moored Boats & Riverside Huts)
 * Adds wide East & West stone steps (ঘাট), heritage brick Chhatri pavilions,
 * 6 moored bobbing wooden country boats (নৌকা), and 4 riverside thatched huts with loot.
 */
export function buildExtendedRiverGhat(buildBoatFn: () => THREE.Group): ExtendedGhatResult {
  const group = new THREE.Group();
  const colliders: CircleCollider[] = [];
  const bobbingBoats: THREE.Group[] = [];
  const chestAnchors: ChestAnchor[] = [];
  const sanjibaniAnchors: Array<{ x: number; z: number }> = [];

  const stoneMat = new THREE.MeshStandardMaterial({
    color: 0xa19484,
    roughness: 0.88,
    metalness: 0.04,
  });
  const brickMat = new THREE.MeshStandardMaterial({
    color: 0xa04b35,
    roughness: 0.85,
  });
  const creamMat = new THREE.MeshStandardMaterial({
    color: 0xe6d6bc,
    roughness: 0.84,
  });
  const woodJettyMat = new THREE.MeshStandardMaterial({
    color: 0x5c3c24,
    roughness: 0.92,
  });
  const thatchMat = new THREE.MeshStandardMaterial({
    color: 0xb69358,
    roughness: 0.96,
  });
  const mudWallMat = new THREE.MeshStandardMaterial({
    color: 0xc9a980,
    roughness: 0.94,
  });

  // Extended Monumental West Ghat (x = -56) and East Ghat (x = +58) wide stone flights
  const ghatWings = [
    { x: -56, width: 34 },
    { x: 58, width: 34 },
  ];

  for (const gw of ghatWings) {
    // Promenade stone apron at top of steps
    const apron = new THREE.Mesh(new THREE.BoxGeometry(gw.width + 6, 0.28, 7.2), stoneMat);
    apron.position.set(gw.x, 0.04, -14.8);
    apron.receiveShadow = true;
    group.add(apron);

    // 5 wide descending stone river steps leading into the Hooghly water
    for (let s = 0; s < 5; s++) {
      const step = new THREE.Mesh(new THREE.BoxGeometry(gw.width, 0.34, 1.15), stoneMat);
      step.position.set(gw.x, -0.14 - s * 0.27, -18.8 - s * 0.95);
      step.receiveShadow = true;
      group.add(step);
    }

    // Heritage Terracotta Brick Ghat Chhatri Pavilion flanking the steps
    const pavX = gw.x + (gw.x < 0 ? -15 : 15);
    const pavZ = -14.8;
    const pavBase = new THREE.Mesh(new THREE.BoxGeometry(5.2, 0.36, 5.2), stoneMat);
    pavBase.position.set(pavX, 0.18, pavZ);
    pavBase.receiveShadow = true;
    group.add(pavBase);

    for (const [px, pz] of [
      [-1.9, -1.9],
      [1.9, -1.9],
      [-1.9, 1.9],
      [1.9, 1.9],
    ]) {
      const col = new THREE.Mesh(new THREE.CylinderGeometry(0.24, 0.28, 3.3, 10), creamMat);
      col.position.set(pavX + px, 1.85, pavZ + pz);
      col.castShadow = true;
      group.add(col);
      colliders.push({ x: pavX + px, z: pavZ + pz, radius: 0.38, height: 3.4, kind: 'ruin' });
    }

    const cornice = new THREE.Mesh(new THREE.BoxGeometry(5.5, 0.34, 5.5), brickMat);
    cornice.position.set(pavX, 3.62, pavZ);
    cornice.castShadow = true;
    group.add(cornice);

    const dome = new THREE.Mesh(
      new THREE.SphereGeometry(2.2, 14, 10, 0, Math.PI * 2, 0, Math.PI * 0.52),
      brickMat,
    );
    dome.position.set(pavX, 3.76, pavZ);
    dome.castShadow = true;
    group.add(dome);

    // Wooden mooring bollards along the ghat edge
    for (const bx of [-10, 0, 10]) {
      const post = new THREE.Mesh(new THREE.CylinderGeometry(0.14, 0.16, 1.1, 8), woodJettyMat);
      post.position.set(gw.x + bx, 0.35, -18.2);
      group.add(post);
    }

    // Loot chest tucked safely beneath each Ghat Chhatri Pavilion!
    chestAnchors.push({ x: pavX, y: 0.36, z: pavZ, rotY: gw.x < 0 ? 0.4 : -0.4 });
  }

  // 4 Small Riverside Fisherman Thatched Huts along the water's edge
  const hutDefs: Array<{ x: number; z: number; rotY: number }> = [
    { x: -42, z: -11.5, rotY: 0.18 },
    { x: -84, z: -12.5, rotY: -0.25 },
    { x: 46, z: -11.5, rotY: -0.2 },
    { x: 86, z: -12.8, rotY: 0.22 },
  ];

  for (const hd of hutDefs) {
    const hut = new THREE.Group();
    hut.position.set(hd.x, 0, hd.z);
    hut.rotation.y = hd.rotY;

    const plinth = new THREE.Mesh(new THREE.BoxGeometry(4.8, 0.34, 3.8), stoneMat);
    plinth.position.set(0, 0.17, 0);
    plinth.receiveShadow = true;
    hut.add(plinth);

    const walls = new THREE.Mesh(new THREE.BoxGeometry(4.2, 2.35, 3.2), mudWallMat);
    walls.position.set(0, 1.5, 0);
    walls.castShadow = true;
    walls.receiveShadow = true;
    hut.add(walls);

    const roof = new THREE.Mesh(new THREE.ConeGeometry(3.55, 1.65, 4), thatchMat);
    roof.rotation.y = Math.PI / 4;
    roof.scale.set(1.18, 1.0, 0.94);
    roof.position.set(0, 3.45, 0);
    roof.castShadow = true;
    hut.add(roof);

    // Small bamboo porch posts facing the river
    for (const px of [-1.7, 1.7]) {
      const p = new THREE.Mesh(new THREE.CylinderGeometry(0.07, 0.08, 2.3, 6), woodJettyMat);
      p.position.set(px, 1.45, -1.85);
      hut.add(p);
    }

    group.add(hut);
    colliders.push({ x: hd.x, z: hd.z, radius: 2.65, height: 3.8, kind: 'house' });

    // Place a loot chest beside alternate huts and Sanjibani herbs beside all
    if (Math.abs(hd.x) > 60) {
      chestAnchors.push({ x: hd.x + (hd.x < 0 ? 3.8 : -3.8), y: 0, z: hd.z + 0.8, rotY: hd.rotY });
    }
    sanjibaniAnchors.push({ x: hd.x + (hd.x < 0 ? -3.6 : 3.6), z: hd.z + 2.4 });
  }

  // 6 Moored Wooden Bengali Country Boats (নৌকা) gently bobbing along the Hooghly Riverfront!
  const boatDefs: Array<{ x: number; z: number; rotY: number }> = [
    { x: -64, z: -26.5, rotY: 0.15 },
    { x: -48, z: -27.2, rotY: -0.22 },
    { x: -34, z: -26.0, rotY: 0.32 },
    { x: 38, z: -26.8, rotY: -0.18 },
    { x: 56, z: -27.4, rotY: 0.26 },
    { x: 74, z: -26.2, rotY: -0.34 },
  ];

  for (const bd of boatDefs) {
    const boat = buildBoatFn();
    boat.position.set(bd.x, -1.18, bd.z);
    boat.rotation.y = bd.rotY;
    group.add(boat);
    bobbingBoats.push(boat);
  }

  return { group, colliders, bobbingBoats, chestAnchors, sanjibaniAnchors };
}

// ============================================================================
// REALISTIC HOLLOW WBTC BUS INTERIOR CABIN (Seats, Grab Bars, Driver Cabin,
// Warm Cabin Lighting, Animated Side Door & Seated Passenger / Camera Mounts)
// ============================================================================

export interface WbtcBusInteriorRig {
  group: THREE.Group;
  doorLeafRear: THREE.Group;
  doorLeafFront: THREE.Group;
  hangingStraps: THREE.Object3D[];
  cabinLight: THREE.PointLight;
  introDriverGroup: THREE.Group;
  interiorCamPos: THREE.Object3D;
  interiorCamLook: THREE.Object3D;
  heroSeatedAnchor: THREE.Object3D;
  heroDoorwayAnchor: THREE.Object3D;
  heroDriverSeatAnchor: THREE.Object3D;
  enemySeatedAnchors: THREE.Object3D[];
  setDoorOpenAmount: (amount: number) => void;
}

/**
 * Builds the detailed hollow interior of the West Bengal WBTC passenger bus:
 * - Ribbed central aisle floor, warm cream-blue inner side paneling, & inner roof liner
 * - 5 rows of cushioned maroon-vinyl passenger seats with tubular chrome frames & backrests
 * - Overhead chrome grab bars, vertical stanchions, and 10 swaying rubber hanging hand-straps
 * - Detailed right-hand-drive Kolkata bus driver cabin (dashboard console, speedometer glow,
 *   angled steering column, gear stick, metal safety partition, sun visor, rearview mirror,
 *   and an intro bus driver figure that hides when the player takes the wheel)
 * - Warm interior dome light strips + real warm THREE.PointLight illuminating seated warriors
 * - Animated pneumatic bi-fold side passenger door in the right-side boarding doorway
 */
export function buildWbtcBusInterior(): WbtcBusInteriorRig {
  const group = new THREE.Group();

  // Interior PBR materials
  const aisleRubberMat = new THREE.MeshStandardMaterial({
    color: 0x2c2b2e,
    roughness: 0.94,
    metalness: 0.04,
  });
  const hazardYellowMat = new THREE.MeshStandardMaterial({
    color: 0xf4c328,
    roughness: 0.45,
    metalness: 0.1,
  });
  const innerWallCream = new THREE.MeshStandardMaterial({
    color: 0xe6decb,
    roughness: 0.82,
    metalness: 0.04,
  });
  const innerTrimBlue = new THREE.MeshStandardMaterial({
    color: 0x1b5c9e,
    roughness: 0.55,
    metalness: 0.15,
  });
  const ceilingLinerMat = new THREE.MeshStandardMaterial({
    color: 0xefe7d5,
    roughness: 0.88,
  });
  const seatVinylMat = new THREE.MeshStandardMaterial({
    color: 0x822b23, // classic Kolkata WBTC maroon rexine cushions
    roughness: 0.62,
    metalness: 0.06,
  });
  const seatBackMat = new THREE.MeshStandardMaterial({
    color: 0x5c231c,
    roughness: 0.72,
  });
  const chromeRailMat = new THREE.MeshStandardMaterial({
    color: 0xe5edf2,
    roughness: 0.22,
    metalness: 0.88,
  });
  const darkIronMat = new THREE.MeshStandardMaterial({
    color: 0x24282f,
    roughness: 0.52,
    metalness: 0.65,
  });
  const strapMat = new THREE.MeshStandardMaterial({
    color: 0xd99b26,
    roughness: 0.75,
  });
  const warmLightLensMat = new THREE.MeshStandardMaterial({
    color: 0xfff4d4,
    emissive: 0xffc66e,
    emissiveIntensity: 2.2,
    roughness: 0.2,
  });
  const dashMat = new THREE.MeshStandardMaterial({
    color: 0x1f242b,
    roughness: 0.72,
    metalness: 0.2,
  });
  const dialGlowMat = new THREE.MeshStandardMaterial({
    color: 0x9effc8,
    emissive: 0x38d989,
    emissiveIntensity: 1.5,
    roughness: 0.3,
  });
  const doorGlassMat = new THREE.MeshPhysicalMaterial({
    color: 0xaad4eb,
    transparent: true,
    opacity: 0.18,
    roughness: 0.1,
    metalness: 0.08,
    depthWrite: false,
    side: THREE.DoubleSide,
  });

  // 1. Central anti-slip ribbed aisle runner + yellow doorway safety tread strip
  const aisleMat = new THREE.Mesh(new THREE.BoxGeometry(0.84, 0.025, 7.4), aisleRubberMat);
  aisleMat.position.set(0, 0.81, -0.15);
  aisleMat.receiveShadow = true;
  group.add(aisleMat);

  const doorSafetyEdge = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.03, 1.38), hazardYellowMat);
  doorSafetyEdge.position.set(-1.08, 0.815, 2.12);
  group.add(doorSafetyEdge);

  // Inner cabin ceiling liner & warm cream lower side wainscoting below windows
  const ceilingLiner = new THREE.Mesh(new THREE.BoxGeometry(2.36, 0.06, 7.96), ceilingLinerMat);
  ceilingLiner.position.set(0, 2.89, 0);
  group.add(ceilingLiner);

  // Inner left panel (+X) & rear right panel (-X) below window sill (y = 0.80 .. 1.66)
  const leftInnerPanel = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.88, 7.9), innerWallCream);
  leftInnerPanel.position.set(1.14, 1.24, 0);
  group.add(leftInnerPanel);

  const rightInnerPanelRear = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.88, 5.25), innerWallCream);
  rightInnerPanelRear.position.set(-1.14, 1.24, -1.35);
  group.add(rightInnerPanelRear);

  // Inner rear bench bulkhead panel & rear clear window frame
  const rearInnerWall = new THREE.Mesh(new THREE.BoxGeometry(2.34, 0.9, 0.06), innerWallCream);
  rearInnerWall.position.set(0, 1.25, -3.95);
  group.add(rearInnerWall);

  // Inner window sill rails (warm wood/blue trim under all clear side windows)
  const leftSill = new THREE.Mesh(new THREE.BoxGeometry(0.11, 0.07, 7.9), innerTrimBlue);
  leftSill.position.set(1.13, 1.69, 0);
  group.add(leftSill);

  const rightSillRear = new THREE.Mesh(new THREE.BoxGeometry(0.11, 0.07, 5.25), innerTrimBlue);
  rightSillRear.position.set(-1.13, 1.69, -1.35);
  group.add(rightSillRear);

  // 2. Rows of Cushioned Indian WBTC Passenger Seats (2+2 side benches with chrome tubular backs)
  const rowZs = [0.85, -0.28, -1.4, -2.52, -3.52];
  const cushionGeo = new THREE.BoxGeometry(0.76, 0.14, 0.48);
  const backrestGeo = new THREE.BoxGeometry(0.76, 0.62, 0.11);
  const headrestGeo = new THREE.BoxGeometry(0.76, 0.07, 0.12);
  const legGeo = new THREE.CylinderGeometry(0.025, 0.025, 0.36, 6);

  for (let r = 0; r < rowZs.length; r++) {
    const rz = rowZs[r];
    for (const sx of [-0.74, 0.74]) {
      const seatGroup = new THREE.Group();
      seatGroup.position.set(sx, 0.8, rz);

      // Padded maroon seat cushion
      const cushion = new THREE.Mesh(cushionGeo, seatVinylMat);
      cushion.position.set(0, 0.38, 0.02);
      cushion.castShadow = true;
      cushion.receiveShadow = true;
      seatGroup.add(cushion);

      // Slanted high backrest with chrome top grab-bar handle
      const back = new THREE.Mesh(backrestGeo, seatBackMat);
      back.position.set(0, 0.72, -0.2);
      back.rotation.x = -0.14;
      back.castShadow = true;
      seatGroup.add(back);

      const topBar = new THREE.Mesh(headrestGeo, chromeRailMat);
      topBar.position.set(0, 1.05, -0.24);
      seatGroup.add(topBar);

      // Tubular steel support legs
      for (const lx of [-0.3, 0.3]) {
        const leg = new THREE.Mesh(legGeo, darkIronMat);
        leg.position.set(lx, 0.18, 0.14);
        seatGroup.add(leg);
      }

      group.add(seatGroup);
    }
  }

  // Full rear 4-seater bench tucked against the back bulkhead
  const rearCenterCushion = new THREE.Mesh(new THREE.BoxGeometry(0.76, 0.14, 0.48), seatVinylMat);
  rearCenterCushion.position.set(0, 1.18, -3.5);
  group.add(rearCenterCushion);

  // 3. Overhead Chrome Grab Bars, Vertical Stanchion Poles & 10 Swaying Hand-Straps
  const railGeo = new THREE.CylinderGeometry(0.024, 0.024, 6.7, 8);
  railGeo.rotateX(Math.PI / 2);
  const bracketGeo = new THREE.CylinderGeometry(0.018, 0.018, 0.24, 6);
  const stanchionGeo = new THREE.CylinderGeometry(0.028, 0.028, 2.08, 8);

  const hangingStraps: THREE.Object3D[] = [];
  const strapLinkGeo = new THREE.BoxGeometry(0.032, 0.18, 0.018);
  const strapLoopGeo = new THREE.TorusGeometry(0.068, 0.017, 6, 12);

  for (const rx of [-0.52, 0.52]) {
    const grabRail = new THREE.Mesh(railGeo, chromeRailMat);
    grabRail.position.set(rx, 2.66, -0.25);
    group.add(grabRail);

    // Ceiling mounting brackets
    for (const bz of [-3.2, -1.2, 0.8, 2.6]) {
      const brk = new THREE.Mesh(bracketGeo, chromeRailMat);
      brk.position.set(rx, 2.77, bz);
      group.add(brk);
    }

    // 5 swaying yellow-gold hand-strap loops per side
    for (const sz of [-2.6, -1.5, -0.4, 0.7, 1.8]) {
      const strapPivot = new THREE.Group();
      strapPivot.position.set(rx, 2.65, sz);

      const stem = new THREE.Mesh(strapLinkGeo, darkIronMat);
      stem.position.set(0, -0.1, 0);
      strapPivot.add(stem);

      const handle = new THREE.Mesh(strapLoopGeo, strapMat);
      handle.position.set(0, -0.24, 0);
      strapPivot.add(handle);

      group.add(strapPivot);
      hangingStraps.push(strapPivot);
    }
  }

  // Vertical grab stanchions framing the passenger boarding doorway & driver partition
  for (const [px, pz] of [
    [-0.52, 1.44],
    [-0.52, 2.76],
    [0.52, 1.44],
    [0.52, -1.4],
  ]) {
    const pole = new THREE.Mesh(stanchionGeo, chromeRailMat);
    pole.position.set(px, 1.84, pz);
    group.add(pole);
  }

  // 4. Detailed Indian Right-Hand-Drive Driver Cabin (Dashboard, Gauges, Wheel, Partition & Intro Driver)
  const dashboard = new THREE.Mesh(new THREE.BoxGeometry(2.32, 0.52, 0.62), dashMat);
  dashboard.position.set(0, 1.44, 3.68);
  group.add(dashboard);

  // Speedometer & instrument cluster with soft emerald backlight
  const gaugeCluster = new THREE.Mesh(new THREE.BoxGeometry(0.56, 0.18, 0.08), dialGlowMat);
  gaugeCluster.position.set(-0.62, 1.66, 3.45);
  gaugeCluster.rotation.x = -0.35;
  group.add(gaugeCluster);

  // Angled steering column & thick-rimmed WBTC bus steering wheel
  const steeringCol = new THREE.Mesh(new THREE.CylinderGeometry(0.045, 0.055, 0.78, 8), darkIronMat);
  steeringCol.position.set(-0.62, 1.24, 3.46);
  steeringCol.rotation.x = -0.35;
  group.add(steeringCol);

  const steeringWheel = new THREE.Mesh(new THREE.TorusGeometry(0.24, 0.032, 8, 18), darkIronMat);
  steeringWheel.position.set(-0.62, 1.6, 3.36);
  steeringWheel.rotation.x = Math.PI * 0.34;
  group.add(steeringWheel);

  const wheelSpoke = new THREE.Mesh(new THREE.BoxGeometry(0.44, 0.03, 0.03), chromeRailMat);
  wheelSpoke.position.set(-0.62, 1.6, 3.36);
  wheelSpoke.rotation.x = Math.PI * 0.34;
  group.add(wheelSpoke);

  // Tall classic Indian bus floor gearshift lever
  const gearStick = new THREE.Mesh(new THREE.CylinderGeometry(0.018, 0.022, 0.68, 6), chromeRailMat);
  gearStick.position.set(-0.22, 1.16, 3.16);
  gearStick.rotation.z = -0.14;
  group.add(gearStick);

  const gearKnob = new THREE.Mesh(new THREE.SphereGeometry(0.048, 8, 8), seatVinylMat);
  gearKnob.position.set(-0.17, 1.5, 3.16);
  group.add(gearKnob);

  // Driver seat cushion & backrest (right-hand side x = -0.62)
  const driverSeatBase = new THREE.Mesh(new THREE.BoxGeometry(0.56, 0.44, 0.54), seatVinylMat);
  driverSeatBase.position.set(-0.62, 1.06, 2.86);
  group.add(driverSeatBase);

  const driverSeatBack = new THREE.Mesh(new THREE.BoxGeometry(0.56, 0.68, 0.12), seatBackMat);
  driverSeatBack.position.set(-0.62, 1.52, 2.6);
  group.add(driverSeatBack);

  // Half-height tubular protective partition behind driver cabin + rearview mirror + sun visor
  const driverPartition = new THREE.Mesh(new THREE.BoxGeometry(0.95, 0.92, 0.06), innerTrimBlue);
  driverPartition.position.set(-0.68, 1.28, 2.48);
  group.add(driverPartition);

  const partitionRail = new THREE.Mesh(new THREE.BoxGeometry(0.96, 0.045, 0.045), chromeRailMat);
  partitionRail.position.set(-0.68, 1.88, 2.48);
  group.add(partitionRail);

  const rearViewMirror = new THREE.Mesh(new THREE.BoxGeometry(0.46, 0.11, 0.05), darkIronMat);
  rearViewMirror.position.set(-0.15, 2.72, 3.85);
  group.add(rearViewMirror);

  const sunVisor = new THREE.Mesh(new THREE.BoxGeometry(0.82, 0.14, 0.04), darkIronMat);
  sunVisor.position.set(-0.62, 2.78, 3.92);
  sunVisor.rotation.x = 0.25;
  group.add(sunVisor);

  // Realistic Seated Bengali WBTC Bus Driver at the wheel during intro ride (hidden when player drives!)
  const introDriverGroup = new THREE.Group();
  introDriverGroup.position.set(-0.62, 1.24, 2.86);
  const driverShirtMat = new THREE.MeshStandardMaterial({ color: 0xd0c4a6, roughness: 0.86 }); // khaki WBTC uniform
  const driverSkinMat = new THREE.MeshPhysicalMaterial({
    color: 0xc28a64,
    roughness: 0.52,
    sheen: 0.3,
    sheenColor: new THREE.Color(0xeaa884),
  });
  const driverHairMat = new THREE.MeshStandardMaterial({ color: 0x1a1513, roughness: 0.65 });
  const driverGamchaMat = new THREE.MeshStandardMaterial({ color: 0xc42026, roughness: 0.88 });

  // Sculpted contoured khaki torso (LatheGeometry instead of box)
  const dTorsoGeo = new THREE.LatheGeometry(
    [
      new THREE.Vector2(0.001, 0.0),
      new THREE.Vector2(0.155, 0.04),
      new THREE.Vector2(0.165, 0.2),
      new THREE.Vector2(0.205, 0.42),
      new THREE.Vector2(0.195, 0.5),
      new THREE.Vector2(0.088, 0.57),
      new THREE.Vector2(0.001, 0.58),
    ],
    18,
  );
  dTorsoGeo.scale(1.08, 1.0, 0.72);
  const driverTorso = new THREE.Mesh(dTorsoGeo, driverShirtMat);
  driverTorso.position.set(0, 0.06, 0);
  introDriverGroup.add(driverTorso);

  // Shirt collar + red gamcha draped over right shoulder
  const driverCollar = new THREE.Mesh(new THREE.TorusGeometry(0.092, 0.018, 6, 16), driverShirtMat);
  driverCollar.rotation.x = Math.PI / 2;
  driverCollar.position.set(0, 0.62, 0.0);
  introDriverGroup.add(driverCollar);

  const driverGamcha = new THREE.Mesh(new THREE.CapsuleGeometry(0.026, 0.24, 4, 8), driverGamchaMat);
  driverGamcha.position.set(-0.125, 0.52, 0.08);
  driverGamcha.rotation.set(0.32, 0, -0.22);
  introDriverGroup.add(driverGamcha);

  // Anatomical neck & sculpted human head
  const driverNeck = new THREE.Mesh(new THREE.CylinderGeometry(0.052, 0.062, 0.11, 12), driverSkinMat);
  driverNeck.position.set(0, 0.65, 0.01);
  introDriverGroup.add(driverNeck);

  const driverHeadGeo = new THREE.SphereGeometry(0.112, 18, 14);
  driverHeadGeo.scale(0.9, 1.12, 1.02);
  const driverHead = new THREE.Mesh(driverHeadGeo, driverSkinMat);
  driverHead.position.set(0, 0.78, 0.025);
  introDriverGroup.add(driverHead);

  // Nose, eyebrows, classic Bengali moustache, and ears
  const driverNose = new THREE.Mesh(new THREE.CapsuleGeometry(0.009, 0.026, 4, 6), driverSkinMat);
  driverNose.position.set(0, 0.768, 0.132);
  driverNose.rotation.x = -0.2;
  introDriverGroup.add(driverNose);

  const driverStache = new THREE.Mesh(new THREE.CapsuleGeometry(0.008, 0.044, 4, 6), driverHairMat);
  driverStache.rotation.z = Math.PI / 2;
  driverStache.position.set(0, 0.735, 0.126);
  introDriverGroup.add(driverStache);

  for (const sx of [-1, 1]) {
    const ear = new THREE.Mesh(new THREE.SphereGeometry(0.017, 8, 8), driverSkinMat);
    ear.scale.set(0.55, 1.1, 0.85);
    ear.position.set(sx * 0.098, 0.775, 0.015);
    introDriverGroup.add(ear);
  }

  // Hair & peaked navy WBTC driver cap
  const driverHair = new THREE.Mesh(
    new THREE.SphereGeometry(0.11, 16, 12, 0, Math.PI * 2, 0, Math.PI * 0.56),
    driverHairMat,
  );
  driverHair.scale.set(0.92, 1.1, 1.04);
  driverHair.position.set(0, 0.79, 0.015);
  introDriverGroup.add(driverHair);

  const driverCapCrown = new THREE.Mesh(new THREE.CylinderGeometry(0.118, 0.106, 0.062, 16), innerTrimBlue);
  driverCapCrown.position.set(0, 0.885, 0.02);
  introDriverGroup.add(driverCapCrown);

  const driverCapVisor = new THREE.Mesh(
    new THREE.CylinderGeometry(0.115, 0.115, 0.012, 14, 1, false, -Math.PI * 0.38, Math.PI * 0.76),
    darkIronMat,
  );
  driverCapVisor.position.set(0, 0.855, 0.068);
  driverCapVisor.rotation.x = 0.16;
  introDriverGroup.add(driverCapVisor);

  // Articulated two-segment arms (upper sleeve + forearm + hand) gripping the steering wheel
  for (const side of [-1, 1]) {
    const upperArm = new THREE.Mesh(new THREE.CapsuleGeometry(0.048, 0.2, 5, 10), driverShirtMat);
    upperArm.position.set(side * 0.215, 0.45, 0.12);
    upperArm.rotation.x = 0.92;
    upperArm.rotation.z = side * 0.14;
    introDriverGroup.add(upperArm);

    const forearm = new THREE.Mesh(new THREE.CapsuleGeometry(0.036, 0.21, 5, 10), driverSkinMat);
    forearm.position.set(side * 0.17, 0.41, 0.32);
    forearm.rotation.x = 1.48;
    forearm.rotation.z = -side * 0.22;
    introDriverGroup.add(forearm);

    const hand = new THREE.Mesh(new THREE.SphereGeometry(0.038, 10, 8), driverSkinMat);
    hand.position.set(side * 0.145, 0.42, 0.44);
    introDriverGroup.add(hand);
  }
  group.add(introDriverGroup);

  // 5. Warm Interior Ceiling Strip Lights + Real Warm PointLight Illuminating Cabin & Warriors
  for (const lz of [-2.4, 0.1, 2.4]) {
    const fixture = new THREE.Mesh(new THREE.BoxGeometry(0.24, 0.06, 0.86), warmLightLensMat);
    fixture.position.set(0, 2.84, lz);
    group.add(fixture);
  }
  const cabinLight = new THREE.PointLight(0xffcf82, 2.4, 8.8, 1.4);
  cabinLight.position.set(0, 2.66, 0.4);
  group.add(cabinLight);

  // 6. Animated Bi-Fold Side Passenger Door at the right-side boarding doorway (-X, z = 1.42..2.82)
  const buildDoorLeaf = (widthZ: number, hingeZ: number, offsetZ: number): THREE.Group => {
    const pivot = new THREE.Group();
    pivot.position.set(-1.22, 0.62, hingeZ);

    // Lower painted WBTC blue metal door leaf
    const lowerPanel = new THREE.Mesh(new THREE.BoxGeometry(0.08, 1.08, widthZ - 0.03), innerTrimBlue);
    lowerPanel.position.set(0, 0.56, offsetZ);
    lowerPanel.castShadow = true;
    pivot.add(lowerPanel);

    // Upper window frame + clear glass pane
    const upperFrameTop = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.12, widthZ - 0.03), innerWallCream);
    upperFrameTop.position.set(0, 2.18, offsetZ);
    pivot.add(upperFrameTop);

    const upperGlass = new THREE.Mesh(new THREE.PlaneGeometry(widthZ - 0.1, 1.02), doorGlassMat);
    upperGlass.rotation.y = -Math.PI / 2;
    upperGlass.position.set(0, 1.62, offsetZ);
    pivot.add(upperGlass);

    // Yellow vertical handrail inside door leaf
    const handle = new THREE.Mesh(new THREE.CylinderGeometry(0.018, 0.018, 0.65, 6), hazardYellowMat);
    handle.position.set(0.06, 1.25, offsetZ);
    pivot.add(handle);

    group.add(pivot);
    return pivot;
  };

  // Two hinged door leaves meeting cleanly in the middle of the 1.4m doorway (z = 2.12)
  const doorLeafRear = buildDoorLeaf(0.7, 1.42, 0.35);
  const doorLeafFront = buildDoorLeaf(0.7, 2.82, -0.35);

  const setDoorOpenAmount = (amount: number) => {
    const t = THREE.MathUtils.clamp(amount, 0, 1);
    // Swing cleanly outward/forward like authentic Kolkata WBTC pneumatic bi-fold doors
    doorLeafRear.rotation.y = -t * 1.48;
    doorLeafFront.rotation.y = t * 1.48;
  };

  // 7. Interior Cabin Camera Anchors & Seated Warrior Anchors
  // Interior camera placed in the rear-center aisle looking forward down the bus cabin through clear windows
  const interiorCamPos = new THREE.Object3D();
  interiorCamPos.position.set(-0.06, 2.24, -2.65);
  group.add(interiorCamPos);

  const interiorCamLook = new THREE.Object3D();
  interiorCamLook.position.set(0.05, 1.88, 5.2);
  group.add(interiorCamLook);

  // Hero seated prominently in the front-left window seat (clearly visible in interior view!)
  const heroSeatedAnchor = new THREE.Object3D();
  heroSeatedAnchor.position.set(0.68, 0.72, 0.85);
  group.add(heroSeatedAnchor);

  // Doorway launch point when the hero stands up & hops straight out the open side door onto the road
  const heroDoorwayAnchor = new THREE.Object3D();
  heroDoorwayAnchor.position.set(-1.12, 0.72, 2.12);
  group.add(heroDoorwayAnchor);

  // Driver seat anchor when player drives the bus later during gameplay
  const heroDriverSeatAnchor = new THREE.Object3D();
  heroDriverSeatAnchor.position.set(-0.62, 0.74, 2.86);
  group.add(heroDriverSeatAnchor);

  // 6 Rival Warriors seated INSIDE the bus rows across from & beside the player!
  const enemySeatCoords: [number, number, number][] = [
    [-0.7, 0.72, 0.85],   // Row 1 right (directly across the aisle from the Bengali hero!)
    [0.7, 0.72, -0.28],   // Row 2 left
    [-0.7, 0.72, -0.28],  // Row 2 right
    [0.7, 0.72, -1.4],    // Row 3 left
    [-0.7, 0.72, -1.4],   // Row 3 right
    [0.7, 0.72, -2.52],   // Row 4 left
  ];
  const enemySeatedAnchors = enemySeatCoords.map(([x, y, z]) => {
    const seat = new THREE.Object3D();
    seat.position.set(x, y, z);
    group.add(seat);
    return seat;
  });

  return {
    group,
    doorLeafRear,
    doorLeafFront,
    hangingStraps,
    cabinLight,
    introDriverGroup,
    interiorCamPos,
    interiorCamLook,
    heroSeatedAnchor,
    heroDoorwayAnchor,
    heroDriverSeatAnchor,
    enemySeatedAnchors,
    setDoorOpenAmount,
  };
}


