import * as THREE from 'three';
import {
  buildExtendedRiverGhat,
  buildOldTramDepotAndBazaar,
  buildSalForestAndHills,
  buildZamindarBari,
  ChestAnchor,
} from './battleRoyaleAssets';
import { TextureBundle } from './textures';
import { BoxCollider, CircleCollider } from './types';

export interface SwayingPalm {
  crown: THREE.Group;
  phase: number;
  baseRotX: number;
  baseRotZ: number;
}

export interface WorldBuildResult {
  worldGroup: THREE.Group;
  boxColliders: BoxCollider[];
  circleColliders: CircleCollider[];
  swayingPalms: SwayingPalm[];
  boatGroup: THREE.Group;
  bobbingBoats: THREE.Group[];
  waterUniforms: { uTime: { value: number } };
  waterBumpTexture: THREE.CanvasTexture;
  enemySpawnPoints: THREE.Vector3[];
  pickupAnchors: THREE.Vector3[];
  landmarkChestAnchors: ChestAnchor[];
  landmarkSanjibaniAnchors: Array<{ x: number; z: number }>;
  playableBounds: { minX: number; maxX: number; minZ: number; maxZ: number };
  getGroundHeight: (x: number, z: number, currentY?: number) => number;
  isWaterBlocked: (x: number, z: number) => boolean;
  getLocationName: (x: number, z: number, currentY?: number) => string;
}

function addContactShadow(
  parent: THREE.Object3D,
  shadowMap: THREE.CanvasTexture,
  width: number,
  depth: number,
  opacity = 0.48,
): void {
  const geo = new THREE.PlaneGeometry(width, depth);
  geo.rotateX(-Math.PI / 2);
  const mat = new THREE.MeshBasicMaterial({
    map: shadowMap,
    transparent: true,
    opacity,
    depthWrite: false,
    polygonOffset: true,
    polygonOffsetFactor: -1,
    polygonOffsetUnits: -1,
  });
  const mesh = new THREE.Mesh(geo, mat);
  mesh.position.y = 0.025;
  parent.add(mesh);
}

/**
 * Builds an iconic Howrah-style steel cantilever truss bridge spanning the Hooghly River.
 */
function buildHowrahBridge(textures: TextureBundle): THREE.Group {
  const bridge = new THREE.Group();
  bridge.position.set(0, 0, -40);

  const steelMat = new THREE.MeshStandardMaterial({
    map: textures.bridgeSteelMap,
    color: 0x9aa5ad,
    roughness: 0.42,
    metalness: 0.78,
  });
  const darkSteelMat = new THREE.MeshStandardMaterial({
    color: 0x4b545c,
    roughness: 0.55,
    metalness: 0.72,
  });
  const deckMat = new THREE.MeshStandardMaterial({
    color: 0x3b3d40,
    roughness: 0.88,
    metalness: 0.05,
  });
  const stoneMat = new THREE.MeshStandardMaterial({
    color: 0x8f8274,
    roughness: 0.92,
    metalness: 0.02,
  });
  const lampGlowMat = new THREE.MeshStandardMaterial({
    color: 0xffdf99,
    emissive: 0xffae42,
    emissiveIntensity: 2.2,
    roughness: 0.25,
  });

  const deckY = 6.2;
  const totalLen = 136;
  const halfWidth = 4.6;

  // Roadway deck
  const deck = new THREE.Mesh(new THREE.BoxGeometry(totalLen, 0.75, halfWidth * 2), deckMat);
  deck.position.set(0, deckY, 0);
  deck.receiveShadow = true;
  bridge.add(deck);

  // Side curb girders
  for (const zSide of [-halfWidth, halfWidth]) {
    const girder = new THREE.Mesh(new THREE.BoxGeometry(totalLen, 1.05, 0.55), darkSteelMat);
    girder.position.set(0, deckY + 0.2, zSide);
    bridge.add(girder);
  }

  // Twin iconic Howrah Bridge main towers at x = -28 and x = +28
  const towerPositions = [-28, 28];
  const towerHeight = 25;

  for (const tx of towerPositions) {
    // Stone river masonry piers
    const pier = new THREE.Mesh(new THREE.BoxGeometry(6.2, 8.2, halfWidth * 2 + 3.2), stoneMat);
    pier.position.set(tx, 2.2, 0);
    bridge.add(pier);

    // Tapered twin steel tower legs on front & back of roadway
    for (const zSide of [-halfWidth, halfWidth]) {
      const leg = new THREE.Mesh(new THREE.BoxGeometry(1.7, towerHeight, 1.5), steelMat);
      leg.position.set(tx, deckY + towerHeight * 0.5 - 1.5, zSide);
      bridge.add(leg);

      // Decorative riveted crown finial atop tower
      const cap = new THREE.Mesh(new THREE.BoxGeometry(2.3, 1.1, 2.1), darkSteelMat);
      cap.position.set(tx, deckY + towerHeight - 1.2, zSide);
      bridge.add(cap);
    }

    // Overhead portal cross-beams & X-bracing linking front/back legs
    const beamHeights = [deckY + 8.5, deckY + 15.5, deckY + 21.8];
    for (const by of beamHeights) {
      const cross = new THREE.Mesh(new THREE.BoxGeometry(1.3, 1.25, halfWidth * 2 + 1.2), steelMat);
      cross.position.set(tx, by, 0);
      bridge.add(cross);
    }

    // Diagonal portal X-braces inside tower head
    const diagLen = Math.hypot(halfWidth * 2, 6.2);
    for (const dir of [-1, 1]) {
      const brace = new THREE.Mesh(new THREE.BoxGeometry(0.42, 0.42, diagLen), darkSteelMat);
      brace.position.set(tx, deckY + 18.6, 0);
      brace.rotation.x = dir * Math.atan2(6.2, halfWidth * 2);
      bridge.add(brace);
    }
  }

  // Classic cantilever curved upper truss chords (both front & back sides)
  // Profile height as a function of x: peaks over towers (±28), curves down to central suspended span and outer anchor spans
  const upperChordY = (x: number): number => {
    const ax = Math.abs(x);
    if (ax <= 28) {
      // Between towers: graceful catenary-like dip to central span
      const t = ax / 28; // 0 at center, 1 at tower
      return deckY + 7.2 + Math.pow(t, 2.15) * 16.0;
    } else {
      // Anchor arms sloping down toward riverbanks
      const t = Math.min(1, (ax - 28) / 36);
      return deckY + 23.2 - Math.pow(t, 0.88) * 18.5;
    }
  };

  const segments = 24;
  const xMin = -62;
  const xMax = 62;
  const dx = (xMax - xMin) / segments;
  const vA = new THREE.Vector3();
  const vB = new THREE.Vector3();
  const vMid = new THREE.Vector3();
  const upAxis = new THREE.Vector3(0, 1, 0);
  const quat = new THREE.Quaternion();

  const addStrut = (
    ax: number,
    ay: number,
    az: number,
    bx: number,
    by: number,
    bz: number,
    thickness: number,
    mat: THREE.Material,
  ) => {
    vA.set(ax, ay, az);
    vB.set(bx, by, bz);
    const len = vA.distanceTo(vB);
    if (len < 0.05) return;
    vMid.addVectors(vA, vB).multiplyScalar(0.5);
    const dir = vB.clone().sub(vA).normalize();
    quat.setFromUnitVectors(upAxis, dir);
    const mesh = new THREE.Mesh(new THREE.BoxGeometry(thickness, len, thickness), mat);
    mesh.position.copy(vMid);
    mesh.quaternion.copy(quat);
    bridge.add(mesh);
  };

  for (const zSide of [-halfWidth, halfWidth]) {
    for (let i = 0; i < segments; i++) {
      const x0 = xMin + i * dx;
      const x1 = x0 + dx;
      const y0 = upperChordY(x0);
      const y1 = upperChordY(x1);

      // Upper chord member
      addStrut(x0, y0, zSide, x1, y1, zSide, 0.58, steelMat);
      // Vertical hanger post
      addStrut(x0, deckY, zSide, x0, y0, zSide, 0.34, darkSteelMat);
      // Alternating Warren/Pratt diagonal truss member
      if (i % 2 === 0) {
        addStrut(x0, deckY, zSide, x1, y1, zSide, 0.3, steelMat);
      } else {
        addStrut(x0, y0, zSide, x1, deckY, zSide, 0.3, steelMat);
      }
    }
    // Closing vertical strut
    addStrut(xMax, deckY, zSide, xMax, upperChordY(xMax), zSide, 0.34, darkSteelMat);
  }

  // Overhead wind-bracing cross struts between front and back upper chords
  for (let i = 3; i < segments - 2; i += 2) {
    const x = xMin + i * dx;
    const y = upperChordY(x);
    if (y > deckY + 8.0) {
      addStrut(x, y, -halfWidth, x, y, halfWidth, 0.34, darkSteelMat);
    }
  }

  // Warm glowing sodium bridge lamps along the deck
  for (let x = -52; x <= 52; x += 13) {
    const post = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.1, 3.2, 6), darkSteelMat);
    post.position.set(x, deckY + 1.8, halfWidth - 0.3);
    bridge.add(post);

    const bulb = new THREE.Mesh(new THREE.SphereGeometry(0.28, 8, 8), lampGlowMat);
    bulb.position.set(x, deckY + 3.45, halfWidth - 0.3);
    bridge.add(bulb);
  }

  return bridge;
}

/**
 * Builds an iconic Kolkata Yellow Hindustan Ambassador Taxi (12-part composite THREE.Group).
 */
function buildYellowTaxi(textures: TextureBundle): THREE.Group {
  const taxi = new THREE.Group();

  const yellowPaint = new THREE.MeshPhysicalMaterial({
    color: 0xf4bd14,
    roughness: 0.24,
    metalness: 0.18,
    clearcoat: 1.0,
    clearcoatRoughness: 0.12,
  });
  const blackTrim = new THREE.MeshStandardMaterial({
    color: 0x1b1c1f,
    roughness: 0.55,
    metalness: 0.2,
  });
  const chromeMat = new THREE.MeshStandardMaterial({
    color: 0xe6ebef,
    roughness: 0.16,
    metalness: 0.92,
  });
  const glassMat = new THREE.MeshPhysicalMaterial({
    color: 0x1d2b35,
    roughness: 0.12,
    metalness: 0.15,
    clearcoat: 1.0,
  });
  const rubberMat = new THREE.MeshStandardMaterial({
    color: 0x171717,
    roughness: 0.92,
    metalness: 0.02,
  });
  const headlightMat = new THREE.MeshStandardMaterial({
    color: 0xfff3c4,
    emissive: 0xffd275,
    emissiveIntensity: 1.4,
    roughness: 0.2,
  });
  const taillightMat = new THREE.MeshStandardMaterial({
    color: 0xd92626,
    emissive: 0xb51818,
    emissiveIntensity: 0.9,
    roughness: 0.25,
  });

  // 1. Classic rounded lower body hull using beveled ExtrudeGeometry (side profile)
  const hullShape = new THREE.Shape();
  hullShape.moveTo(-2.15, 0.36);
  hullShape.lineTo(2.15, 0.36);
  hullShape.quadraticCurveTo(2.3, 0.5, 2.22, 0.96);
  hullShape.lineTo(1.25, 1.08);
  hullShape.lineTo(-1.35, 1.08);
  hullShape.lineTo(-2.18, 0.94);
  hullShape.quadraticCurveTo(-2.3, 0.62, -2.15, 0.36);

  const hullGeo = new THREE.ExtrudeGeometry(hullShape, {
    depth: 1.66,
    bevelEnabled: true,
    bevelThickness: 0.12,
    bevelSize: 0.08,
    bevelSegments: 3,
  });
  hullGeo.translate(0, 0, -0.83);
  const hull = new THREE.Mesh(hullGeo, yellowPaint);
  hull.castShadow = true;
  hull.receiveShadow = true;
  taxi.add(hull);

  // 2. Classic black Kolkata taxi lower side band / rocker stripe
  const stripe = new THREE.Mesh(new THREE.BoxGeometry(4.36, 0.26, 1.9), blackTrim);
  stripe.position.set(0, 0.48, 0);
  taxi.add(stripe);

  // 3. Domed Ambassador greenhouse cabin
  const cabinShape = new THREE.Shape();
  cabinShape.moveTo(-1.26, 1.04);
  cabinShape.lineTo(1.12, 1.04);
  cabinShape.quadraticCurveTo(0.84, 1.64, 0.48, 1.7);
  cabinShape.lineTo(-0.76, 1.7);
  cabinShape.quadraticCurveTo(-1.12, 1.6, -1.26, 1.04);
  const cabinGeo = new THREE.ExtrudeGeometry(cabinShape, {
    depth: 1.44,
    bevelEnabled: true,
    bevelThickness: 0.1,
    bevelSize: 0.08,
    bevelSegments: 3,
  });
  cabinGeo.translate(0, 0, -0.72);
  const cabin = new THREE.Mesh(cabinGeo, yellowPaint);
  cabin.castShadow = true;
  taxi.add(cabin);

  // 4. Windshield, rear glass & side windows
  const sideGlass = new THREE.Mesh(new THREE.BoxGeometry(1.75, 0.44, 1.66), glassMat);
  sideGlass.position.set(-0.1, 1.35, 0);
  taxi.add(sideGlass);

  const frontBackGlass = new THREE.Mesh(new THREE.BoxGeometry(2.08, 0.42, 1.32), glassMat);
  frontBackGlass.position.set(-0.08, 1.34, 0);
  taxi.add(frontBackGlass);

  // 5. Roof "TAXI" illuminated sign box
  const signMat = new THREE.MeshStandardMaterial({
    map: textures.taxiSignMap,
    emissive: 0xffe07d,
    emissiveMap: textures.taxiSignMap,
    emissiveIntensity: 0.35,
    roughness: 0.35,
  });
  const taxiSign = new THREE.Mesh(new THREE.BoxGeometry(0.28, 0.24, 0.66), [
    signMat,
    signMat,
    blackTrim,
    blackTrim,
    blackTrim,
    blackTrim,
  ]);
  taxiSign.position.set(0.05, 1.88, 0);
  taxiSign.castShadow = true;
  taxi.add(taxiSign);

  // 6. Chrome roof luggage carrier bars
  const rackBase = new THREE.Mesh(new THREE.BoxGeometry(0.75, 0.05, 1.15), chromeMat);
  rackBase.position.set(-0.56, 1.82, 0);
  taxi.add(rackBase);

  // 7. Chrome front & rear bumpers + radiator grille
  for (const bx of [2.3, -2.3]) {
    const bumper = new THREE.Mesh(new THREE.BoxGeometry(0.18, 0.18, 1.92), chromeMat);
    bumper.position.set(bx, 0.42, 0);
    taxi.add(bumper);
  }
  const grille = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.36, 0.92), chromeMat);
  grille.position.set(2.26, 0.72, 0);
  taxi.add(grille);

  // 8. Round twin Ambassador headlights with chrome bezels
  for (const hz of [-0.64, 0.64]) {
    const bezel = new THREE.Mesh(new THREE.CylinderGeometry(0.18, 0.18, 0.12, 14), chromeMat);
    bezel.rotation.z = Math.PI / 2;
    bezel.position.set(2.22, 0.84, hz);
    taxi.add(bezel);

    const lamp = new THREE.Mesh(new THREE.SphereGeometry(0.14, 10, 10), headlightMat);
    lamp.position.set(2.26, 0.84, hz);
    taxi.add(lamp);

    // Rear tail lamps
    const tail = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.22, 0.18), taillightMat);
    tail.position.set(-2.26, 0.78, hz);
    taxi.add(tail);
  }

  // 9. West Bengal license plates (front & back)
  const plateMat = new THREE.MeshStandardMaterial({
    map: textures.licensePlateMap,
    roughness: 0.45,
  });
  for (const px of [2.36, -2.36]) {
    const plate = new THREE.Mesh(new THREE.PlaneGeometry(0.56, 0.16), plateMat);
    plate.position.set(px, 0.56, 0);
    plate.rotation.y = px > 0 ? Math.PI / 2 : -Math.PI / 2;
    taxi.add(plate);
  }

  // 10. Four rubber wheels with chrome Ambassador hubcaps
  const wheelCoords: [number, number][] = [
    [1.36, 0.88],
    [1.36, -0.88],
    [-1.36, 0.88],
    [-1.36, -0.88],
  ];
  const tireGeo = new THREE.CylinderGeometry(0.38, 0.38, 0.26, 18);
  tireGeo.rotateX(Math.PI / 2);
  const hubGeo = new THREE.CylinderGeometry(0.2, 0.2, 0.29, 14);
  hubGeo.rotateX(Math.PI / 2);

  for (const [wx, wz] of wheelCoords) {
    const tire = new THREE.Mesh(tireGeo, rubberMat);
    tire.position.set(wx, 0.38, wz);
    tire.castShadow = true;
    taxi.add(tire);

    const hub = new THREE.Mesh(hubGeo, chromeMat);
    hub.position.set(wx, 0.38, wz);
    taxi.add(hub);
  }

  addContactShadow(taxi, textures.contactShadowMap, 5.4, 2.7, 0.58);
  return taxi;
}

/**
 * Builds a traditional West Bengal Village Mud House (Matir Ghor) with Alpona dado,
 * veranda (daowa), bamboo pillars, pitched thatched chala roof, and clay kolshi pots.
 */
function buildMudHouse(
  textures: TextureBundle,
  width = 6.2,
  depth = 5.0,
  wallHeight = 3.0,
): THREE.Group {
  const house = new THREE.Group();

  const wallMat = new THREE.MeshStandardMaterial({
    map: textures.mudWallMap,
    bumpMap: textures.mudWallBump,
    bumpScale: 0.08,
    roughness: 0.92,
    metalness: 0.0,
  });
  const plinthMat = new THREE.MeshStandardMaterial({
    color: 0x875132,
    roughness: 0.94,
    metalness: 0.0,
  });
  const thatchMat = new THREE.MeshStandardMaterial({
    map: textures.thatchMap,
    color: 0xd1b37c,
    roughness: 0.96,
    metalness: 0.0,
  });
  const woodMat = new THREE.MeshStandardMaterial({
    color: 0x4d311e,
    roughness: 0.82,
    metalness: 0.05,
  });
  const bambooMat = new THREE.MeshStandardMaterial({
    color: 0x9b7c46,
    roughness: 0.72,
    metalness: 0.04,
  });
  const clayPotMat = new THREE.MeshStandardMaterial({
    color: 0xb64a2c,
    roughness: 0.7,
    metalness: 0.04,
  });
  const lanternGlowMat = new THREE.MeshStandardMaterial({
    color: 0xffd27a,
    emissive: 0xff9b2f,
    emissiveIntensity: 1.8,
    roughness: 0.3,
  });

  // 1. Raised earthen veranda plinth (daowa)
  const plinthH = 0.42;
  const plinth = new THREE.Mesh(
    new THREE.BoxGeometry(width + 1.1, plinthH, depth + 1.5),
    plinthMat,
  );
  plinth.position.set(0, plinthH * 0.5, 0.3);
  plinth.receiveShadow = true;
  plinth.castShadow = true;
  house.add(plinth);

  // 2. Main mud-plaster walls with Alpona motif band
  const body = new THREE.Mesh(new THREE.BoxGeometry(width, wallHeight, depth), wallMat);
  body.position.set(0, plinthH + wallHeight * 0.5, -0.15);
  body.castShadow = true;
  body.receiveShadow = true;
  house.add(body);

  // 3. Pitched Bengali Chala thatched roof (two beveled eaves + ridge beam)
  const roofH = 2.15;
  const roofShape = new THREE.Shape();
  const halfSpan = depth * 0.5 + 1.35;
  roofShape.moveTo(-halfSpan, 0);
  roofShape.lineTo(0, roofH);
  roofShape.lineTo(halfSpan, 0);
  roofShape.lineTo(halfSpan - 0.28, -0.22);
  roofShape.lineTo(0, roofH - 0.34);
  roofShape.lineTo(-halfSpan + 0.28, -0.22);
  roofShape.closePath();

  const roofGeo = new THREE.ExtrudeGeometry(roofShape, {
    depth: width + 1.5,
    bevelEnabled: true,
    bevelThickness: 0.14,
    bevelSize: 0.1,
    bevelSegments: 2,
  });
  roofGeo.rotateY(Math.PI / 2);
  roofGeo.translate(-(width + 1.5) * 0.5, plinthH + wallHeight - 0.16, 0.05);
  const roof = new THREE.Mesh(roofGeo, thatchMat);
  roof.castShadow = true;
  roof.receiveShadow = true;
  house.add(roof);

  // Triangular gable mud infill under roof
  const gableShape = new THREE.Shape();
  gableShape.moveTo(-depth * 0.5, 0);
  gableShape.lineTo(0, roofH - 0.28);
  gableShape.lineTo(depth * 0.5, 0);
  gableShape.closePath();
  const gableGeo = new THREE.ExtrudeGeometry(gableShape, {
    depth: width - 0.08,
    bevelEnabled: false,
  });
  gableGeo.rotateY(Math.PI / 2);
  gableGeo.translate(-(width - 0.08) * 0.5, plinthH + wallHeight - 0.05, -0.15);
  const gable = new THREE.Mesh(gableGeo, wallMat);
  house.add(gable);

  // Bamboo ridge pole
  const ridge = new THREE.Mesh(
    new THREE.CylinderGeometry(0.12, 0.12, width + 1.9, 8),
    bambooMat,
  );
  ridge.rotation.z = Math.PI / 2;
  ridge.position.set(0, plinthH + wallHeight + roofH - 0.08, 0.05);
  house.add(ridge);

  // 4. Front veranda bamboo support posts
  const postXs = [-width * 0.48, -width * 0.16, width * 0.16, width * 0.48];
  for (const px of postXs) {
    const post = new THREE.Mesh(
      new THREE.CylinderGeometry(0.08, 0.095, wallHeight, 8),
      bambooMat,
    );
    post.position.set(px, plinthH + wallHeight * 0.5, depth * 0.5 + 0.85);
    post.castShadow = true;
    house.add(post);
  }

  // 5. Wooden front door & frame
  const doorFrame = new THREE.Mesh(new THREE.BoxGeometry(1.36, 2.25, 0.18), woodMat);
  doorFrame.position.set(0, plinthH + 1.12, depth * 0.5 - 0.12);
  house.add(doorFrame);

  const doorPanel = new THREE.Mesh(
    new THREE.BoxGeometry(1.12, 2.08, 0.22),
    new THREE.MeshStandardMaterial({ color: 0x3a2315, roughness: 0.85 }),
  );
  doorPanel.position.set(0, plinthH + 1.06, depth * 0.5 - 0.11);
  house.add(doorPanel);

  // 6. Shuttered side & front windows
  const winPositions = [-width * 0.3, width * 0.3];
  for (const wx of winPositions) {
    const win = new THREE.Mesh(new THREE.BoxGeometry(0.95, 0.95, 0.18), woodMat);
    win.position.set(wx, plinthH + 1.65, depth * 0.5 - 0.12);
    house.add(win);

    const inner = new THREE.Mesh(
      new THREE.BoxGeometry(0.74, 0.74, 0.21),
      new THREE.MeshStandardMaterial({ color: 0x20150e, roughness: 0.9 }),
    );
    inner.position.set(wx, plinthH + 1.65, depth * 0.5 - 0.11);
    house.add(inner);
  }

  // 7. Terracotta water pots (Kolshi) using LatheGeometry on veranda
  const potProfile = [
    new THREE.Vector2(0.0, 0.0),
    new THREE.Vector2(0.18, 0.0),
    new THREE.Vector2(0.28, 0.18),
    new THREE.Vector2(0.26, 0.36),
    new THREE.Vector2(0.13, 0.48),
    new THREE.Vector2(0.16, 0.56),
  ];
  const potGeo = new THREE.LatheGeometry(potProfile, 14);
  const pot1 = new THREE.Mesh(potGeo, clayPotMat);
  pot1.position.set(-width * 0.36, plinthH, depth * 0.5 + 0.38);
  pot1.castShadow = true;
  house.add(pot1);

  const pot2 = new THREE.Mesh(potGeo, clayPotMat);
  pot2.scale.setScalar(0.8);
  pot2.position.set(-width * 0.26, plinthH, depth * 0.5 + 0.5);
  house.add(pot2);

  // 8. Hanging warm village oil lantern by the veranda
  const lantern = new THREE.Mesh(new THREE.CylinderGeometry(0.11, 0.13, 0.26, 8), lanternGlowMat);
  lantern.position.set(width * 0.16, plinthH + wallHeight - 0.48, depth * 0.5 + 0.85);
  house.add(lantern);

  addContactShadow(house, textures.contactShadowMap, width + 2.4, depth + 2.6, 0.45);
  return house;
}

/**
 * Builds a realistic curved Coconut Palm Tree (Narkel Gach) using TubeGeometry + arched fronds + coconuts.
 */
function buildCoconutTree(
  textures: TextureBundle,
  height = 9.5,
  leanX = 1.1,
  leanZ = 0.6,
): { group: THREE.Group; crown: THREE.Group } {
  const tree = new THREE.Group();

  const trunkMat = new THREE.MeshStandardMaterial({
    map: textures.palmBarkMap,
    roughness: 0.9,
    metalness: 0.0,
  });
  const frondMat = new THREE.MeshStandardMaterial({
    map: textures.frondMap,
    alphaTest: 0.35,
    side: THREE.DoubleSide,
    roughness: 0.68,
    metalness: 0.02,
  });
  const coconutMat = new THREE.MeshStandardMaterial({
    color: 0x4b7826,
    roughness: 0.42,
    metalness: 0.05,
  });

  // 1. Curved organic trunk via TubeGeometry along CatmullRomCurve3
  const curve = new THREE.CatmullRomCurve3([
    new THREE.Vector3(0, 0, 0),
    new THREE.Vector3(leanX * 0.25, height * 0.35, leanZ * 0.25),
    new THREE.Vector3(leanX * 0.72, height * 0.72, leanZ * 0.72),
    new THREE.Vector3(leanX, height, leanZ),
  ]);
  const trunkGeo = new THREE.TubeGeometry(curve, 12, 0.24, 8, false);
  // Gently taper trunk from base to top
  const posAttr = trunkGeo.attributes.position;
  for (let i = 0; i < posAttr.count; i++) {
    const y = posAttr.getY(i);
    const t = THREE.MathUtils.clamp(y / height, 0, 1);
    const center = curve.getPoint(t);
    const taper = THREE.MathUtils.lerp(1.22, 0.56, t);
    posAttr.setXYZ(
      i,
      center.x + (posAttr.getX(i) - center.x) * taper,
      y,
      center.z + (posAttr.getZ(i) - center.z) * taper,
    );
  }
  trunkGeo.computeVertexNormals();
  const trunk = new THREE.Mesh(trunkGeo, trunkMat);
  trunk.castShadow = true;
  trunk.receiveShadow = true;
  tree.add(trunk);

  // 2. Swaying crown group at the top of the trunk
  const crown = new THREE.Group();
  crown.position.set(leanX, height, leanZ);
  tree.add(crown);

  // Cluster of green Bengali coconuts (Daab) under crown
  const nutGeo = new THREE.SphereGeometry(0.19, 8, 8);
  nutGeo.scale(1, 1.18, 1);
  for (let i = 0; i < 6; i++) {
    const a = (i / 6) * Math.PI * 2;
    const nut = new THREE.Mesh(nutGeo, coconutMat);
    nut.position.set(Math.cos(a) * 0.28, -0.26 - (i % 2) * 0.14, Math.sin(a) * 0.28);
    crown.add(nut);
  }

  // 3. Curved palm frond geometry (bent PlaneGeometry)
  const frondGeo = new THREE.PlaneGeometry(3.6, 1.35, 8, 2);
  frondGeo.translate(1.8, 0, 0);
  const fp = frondGeo.attributes.position;
  for (let i = 0; i < fp.count; i++) {
    const fx = fp.getX(i);
    const fz = fp.getY(i); // before rotating flat
    const normX = fx / 3.6;
    const droopY = Math.sin(normX * Math.PI) * 0.55 - normX * normX * 1.15;
    const vFold = Math.abs(fz) * 0.18;
    fp.setXYZ(i, fx, droopY - vFold, fz);
  }
  frondGeo.computeVertexNormals();

  const frondCount = 10;
  for (let i = 0; i < frondCount; i++) {
    const angle = (i / frondCount) * Math.PI * 2 + (i % 2) * 0.18;
    const pitch = i % 2 === 0 ? 0.22 : -0.14;
    const frond = new THREE.Mesh(frondGeo, frondMat);
    frond.rotation.y = angle;
    frond.rotation.z = pitch;
    frond.castShadow = true;
    crown.add(frond);
  }

  addContactShadow(tree, textures.contactShadowMap, 3.0, 3.0, 0.38);
  return { group: tree, crown };
}

/**
 * Builds a traditional wooden Bengali river country boat (Nouka) floating near the Hooghly ghat.
 */
function buildRiverBoat(): THREE.Group {
  const boat = new THREE.Group();

  const woodDark = new THREE.MeshStandardMaterial({
    color: 0x3b2416,
    roughness: 0.85,
    metalness: 0.05,
  });
  const woodTrim = new THREE.MeshStandardMaterial({
    color: 0x8f3422,
    roughness: 0.72,
    metalness: 0.05,
  });
  const bambooCanopy = new THREE.MeshStandardMaterial({
    color: 0xb7965b,
    roughness: 0.92,
    side: THREE.DoubleSide,
  });

  // Curved hull
  const hull = new THREE.Mesh(new THREE.CylinderGeometry(0.95, 0.55, 5.4, 10, 1, false, 0, Math.PI), woodDark);
  hull.rotation.z = Math.PI / 2;
  hull.rotation.x = Math.PI;
  hull.scale.set(1, 1, 0.82);
  hull.position.y = 0.25;
  boat.add(hull);

  // Raised pointed bow & stern prows
  for (const sx of [-2.95, 2.95]) {
    const prow = new THREE.Mesh(new THREE.ConeGeometry(0.42, 1.3, 6), woodTrim);
    prow.position.set(sx, 0.56, 0);
    prow.rotation.z = sx > 0 ? -Math.PI * 0.36 : Math.PI * 0.36;
    boat.add(prow);
  }

  // Arched bamboo chhoi (canopy) in middle of boat
  const canopy = new THREE.Mesh(
    new THREE.CylinderGeometry(0.92, 0.92, 2.2, 12, 1, true, -Math.PI * 0.45, Math.PI * 0.9),
    bambooCanopy,
  );
  canopy.rotation.z = Math.PI / 2;
  canopy.position.set(-0.2, 0.62, 0);
  boat.add(canopy);

  return boat;
}

/**
 * Analytical Red-Soil Laterite Hills elevation for শালবন ও লাল মাটির টিলা (West & NW sectors)
 * and gentle rolling outer Bengal countryside beyond the village/landmarks.
 * Guaranteed flat (0) across Village Square, Riverbank Ghat, Zamindar Bari, and Old Tram Depot.
 */
function sampleLateriteHillHeight(x: number, z: number): number {
  // Keep river channel, village square, ghat, Zamindar Bari estate, and Tram Depot completely level
  if (z > -76 && z < -6) return 0;
  if (x > -46 && x < 54 && z >= -18 && z < 46) return 0; // Village Square
  if (x > 64 && x < 134 && z > -14 && z < 56) return 0; // Zamindar Bari estate
  if (x > -88 && x < 88 && z < -70 && z > -196) return 0; // Old Tram Depot & Bazaar
  // Keep westbound & eastbound main heritage trails smooth
  if (x > -128 && x < 76 && z > 1 && z < 13) return 0;

  // Rarh Bengal laterite hill mounds (Gaussian ridges in West / NW Sal Forest + scenic far flanks)
  const hills: Array<[number, number, number, number]> = [
    // South-West Sal Forest & Red-Soil Hills (শালবন)
    [-92, 42, 6.4, 34],
    [-142, 66, 8.2, 42],
    [-190, 96, 7.6, 46],
    [-122, 118, 6.2, 38],
    [-176, 36, 5.8, 36],
    [-76, 84, 4.6, 28],
    [-226, 54, 7.4, 48],
    // North-West Sal Forest Hills across the river
    [-136, -124, 7.2, 40],
    [-188, -162, 8.4, 46],
    [-142, -196, 6.5, 38],
    [-234, -126, 7.8, 48],
    // Gentle distant Bengal horizon mounds (South, East, North-East)
    [186, 86, 5.8, 52],
    [224, -152, 6.4, 54],
    [-20, 210, 5.2, 56],
    [136, 194, 5.6, 52],
    [-290, 220, 8.5, 68],
    [280, 210, 8.0, 68],
    [-290, -280, 9.0, 72],
    [260, -290, 8.4, 70],
  ];

  let h = 0;
  for (let i = 0; i < hills.length; i++) {
    const [hx, hz, amp, sigma] = hills[i];
    const dx = x - hx;
    const dz = z - hz;
    const d2 = dx * dx + dz * dz;
    const cutoff = sigma * 3.1;
    if (d2 < cutoff * cutoff) {
      h += amp * Math.exp(-d2 / (2 * sigma * sigma));
    }
  }

  // Smooth river-edge feather so terrain meets the riverbank cleanly at y = 0
  let edgeMask = 1;
  if (z >= -6 && z < 6) {
    edgeMask = Math.min(edgeMask, (z - -6) / 12);
  } else if (z <= -76 && z > -90) {
    edgeMask = Math.min(edgeMask, (-76 - z) / 14);
  }
  return h * Math.max(0, Math.min(1, edgeMask));
}

/**
 * Computes red-soil laterite blend weight [0..1] for vertex coloring the Sal Forest hills.
 */
function sampleLateriteSoilWeight(x: number, z: number, height: number): number {
  const inSwSalbon = x < -46 && x > -295 && z > -10 && z < 210;
  const inNwSalbon = x < -84 && x > -305 && z < -76 && z > -280;
  if (!inSwSalbon && !inNwSalbon) {
    return THREE.MathUtils.clamp((height - 3.2) * 0.12, 0, 0.45);
  }
  const edgeFade = inSwSalbon
    ? THREE.MathUtils.clamp((-46 - x) / 28, 0, 1)
    : THREE.MathUtils.clamp((-84 - x) / 28, 0, 1);
  return THREE.MathUtils.clamp(edgeFade * (0.62 + height * 0.08), 0, 1);
}

/**
 * Builds a subdivided 1000m+ Bengal ground mesh with baked laterite hills & red-soil vertex colors.
 */
function buildTerrainPlane(
  width: number,
  depth: number,
  segX: number,
  segZ: number,
  centerZ: number,
  textures: TextureBundle,
): THREE.Mesh {
  const geo = new THREE.PlaneGeometry(width, depth, segX, segZ);
  geo.rotateX(-Math.PI / 2);

  const pos = geo.attributes.position;
  const colors = new Float32Array(pos.count * 3);
  const grassTint = new THREE.Color(0xedf4e1); // crisp sunny daylight tint over groundMap
  const lateriteTint = new THREE.Color(0xc85c36); // rich Rarh Bengal reddish laterite soil
  const deepLaterite = new THREE.Color(0x9e3e22);
  const tmpColor = new THREE.Color();

  for (let i = 0; i < pos.count; i++) {
    const wx = pos.getX(i);
    const wz = pos.getZ(i) + centerZ;
    const h = sampleLateriteHillHeight(wx, wz);
    pos.setY(i, h);

    const redW = sampleLateriteSoilWeight(wx, wz, h);
    tmpColor.copy(grassTint).lerp(lateriteTint, redW);
    if (h > 4.5 && redW > 0.35) {
      tmpColor.lerp(deepLaterite, Math.min(0.45, (h - 4.5) * 0.1));
    }
    colors[i * 3] = tmpColor.r;
    colors[i * 3 + 1] = tmpColor.g;
    colors[i * 3 + 2] = tmpColor.b;
  }

  geo.setAttribute('color', new THREE.BufferAttribute(colors, 3));
  geo.computeVertexNormals();

  // Scale UVs cleanly so the tiled ground texture stays crisp across 1180m terrain
  const uv = geo.attributes.uv;
  const repeatX = width / 26;
  const repeatZ = depth / 26;
  for (let i = 0; i < uv.count; i++) {
    uv.setXY(i, uv.getX(i) * repeatX, uv.getY(i) * repeatZ);
  }

  const mat = new THREE.MeshStandardMaterial({
    map: textures.groundMap,
    bumpMap: textures.groundBump,
    bumpScale: 0.12,
    roughness: 0.94,
    metalness: 0.0,
    vertexColors: true,
  });

  const mesh = new THREE.Mesh(geo, mat);
  mesh.position.set(0, 0, centerZ);
  mesh.receiveShadow = true;
  return mesh;
}

/**
 * Builds the two walkable & drivable Howrah Bridge Crossing Approaches connecting the South
 * Village/Ghat bank (z = -11.5, y = 0) up to the Howrah Bridge Deck (z = -35.4..-44.6, y = 6.58)
 * and down onto the North Bank (z = -72.0, y = 0) straight into Old Tram Depot & Bazaar.
 */
function buildBridgeCrossingRamps(): THREE.Group {
  const group = new THREE.Group();
  const deckY = 6.58;
  const rampWidth = 8.0;

  const asphaltMat = new THREE.MeshStandardMaterial({
    color: 0x3f4348,
    roughness: 0.88,
    metalness: 0.06,
  });
  const railMat = new THREE.MeshStandardMaterial({
    color: 0x8e9aa3,
    roughness: 0.48,
    metalness: 0.72,
  });
  const pierMat = new THREE.MeshStandardMaterial({
    color: 0x8e8173,
    roughness: 0.92,
  });
  const stripeMat = new THREE.MeshStandardMaterial({
    color: 0xf4d268,
    roughness: 0.7,
  });

  const laneCenters = [-17.5, 17.5]; // Each 8m wide: [-21.5, -13.5] and [13.5, 21.5]

  const addSlopedSpan = (cx: number, z0: number, y0: number, z1: number, y1: number) => {
    const dz = z1 - z0;
    const dy = y1 - y0;
    const len = Math.hypot(dz, dy);
    const pitch = Math.atan2(dy, dz); // Note: Three.js BoxGeometry rotated around X

    const span = new THREE.Group();
    span.position.set(cx, (y0 + y1) * 0.5, (z0 + z1) * 0.5);
    span.rotation.x = -pitch;

    const slab = new THREE.Mesh(new THREE.BoxGeometry(rampWidth, 0.55, len + 0.4), asphaltMat);
    slab.position.y = -0.275;
    slab.castShadow = true;
    slab.receiveShadow = true;
    span.add(slab);

    // Center dashed yellow road stripe
    const stripe = new THREE.Mesh(new THREE.BoxGeometry(0.18, 0.03, len - 1.2), stripeMat);
    stripe.position.y = 0.02;
    span.add(stripe);

    // Twin steel safety guardrails
    for (const sx of [-rampWidth * 0.5 + 0.2, rampWidth * 0.5 - 0.2]) {
      const curb = new THREE.Mesh(new THREE.BoxGeometry(0.32, 0.95, len + 0.2), railMat);
      curb.position.set(sx, 0.45, 0);
      curb.castShadow = true;
      span.add(curb);
    }

    group.add(span);

    // Masonry support piers underneath the elevated approach span
    for (const t of [0.38, 0.74]) {
      const pz = THREE.MathUtils.lerp(z0, z1, t);
      const py = THREE.MathUtils.lerp(y0, y1, t);
      if (py > 1.2) {
        const pier = new THREE.Mesh(new THREE.BoxGeometry(rampWidth - 1.2, py + 1.8, 1.3), pierMat);
        pier.position.set(cx, (py - 1.8) * 0.5, pz);
        pier.castShadow = true;
        group.add(pier);
      }
    }
  };

  for (const cx of laneCenters) {
    // South approach ramp: Village Ghat (z = -11.5, y = 0) up to Bridge Deck (z = -35.4, y = 6.58)
    addSlopedSpan(cx, -11.5, 0.0, -35.4, deckY);
    // North descent ramp: Bridge Deck (z = -44.6, y = 6.58) down to Tram Depot Bank (z = -72.0, y = 0)
    addSlopedSpan(cx, -44.6, deckY, -72.0, 0.0);
  }

  return group;
}

/**
 * Analytical elevation for the Howrah Bridge deck and its North/South crossing ramps.
 * Returns null if (x, z) is not on a crossing ramp or bridge deck.
 */
function sampleBridgeCrossingHeight(x: number, z: number): number | null {
  const deckY = 6.58;
  const onWestLane = x >= -21.5 && x <= -13.5;
  const onEastLane = x >= 13.5 && x <= 21.5;

  // Main Howrah Bridge East-West deck (walkable across the iconic steel span!)
  if (x >= -66 && x <= 66 && z <= -35.2 && z >= -44.8) {
    return deckY;
  }

  if (onWestLane || onEastLane) {
    // South ramp: z from -11.5 (y=0) to -35.4 (y=6.58)
    if (z <= -11.5 && z >= -35.4) {
      const t = THREE.MathUtils.clamp((-11.5 - z) / (-11.5 - -35.4), 0, 1);
      return t * deckY;
    }
    // North ramp: z from -44.6 (y=6.58) down to -72.0 (y=0)
    if (z <= -44.6 && z >= -72.0) {
      const t = THREE.MathUtils.clamp((-44.6 - z) / (-44.6 - -72.0), 0, 1);
      return (1 - t) * deckY;
    }
  }

  return null;
}

/**
 * Builds the expanded 1000x1000 West Bengal Hooghly Riverbank Battle Royale World
 * featuring the Village, Howrah Bridge, Red-Soil Sal Forest & Hills, Abandoned Zamindar Bari,
 * Old Tram Depot & Bazaar, and Extended Riverbank Ghat with Wooden Boats.
 */
export function buildWestBengalWorld(textures: TextureBundle): WorldBuildResult {
  const worldGroup = new THREE.Group();
  const boxColliders: BoxCollider[] = [];
  const circleColliders: CircleCollider[] = [];
  const swayingPalms: SwayingPalm[] = [];
  const bobbingBoats: THREE.Group[] = [];
  const landmarkChestAnchors: ChestAnchor[] = [];
  const landmarkSanjibaniAnchors: Array<{ x: number; z: number }> = [];

  // 1. Bright sunny daytime sky dome (radius 1350 encompasses 1000x1000 map & 550u Safe Zone cleanly)
  const skyGeo = new THREE.SphereGeometry(1350, 32, 20);
  const skyMat = new THREE.MeshBasicMaterial({
    map: textures.skyMap,
    side: THREE.BackSide,
    fog: false,
    depthWrite: false,
  });
  const skyDome = new THREE.Mesh(skyGeo, skyMat);
  worldGroup.add(skyDome);

  // 2. Expanded 1000x1000 Subdivided Terrain (South Bank + North Bank with baked Red-Soil Laterite Hills)
  const southTerrain = buildTerrainPlane(1180, 560, 116, 60, 260, textures);
  worldGroup.add(southTerrain);

  const northTerrain = buildTerrainPlane(1180, 520, 116, 56, -330, textures);
  worldGroup.add(northTerrain);

  // Distant Kolkata skyline silhouettes pushed far behind the North-Bank Tram Depot (z = -248..-286)
  const skylineMat = new THREE.MeshStandardMaterial({
    color: 0x6f7582,
    roughness: 0.88,
    metalness: 0.05,
  });
  for (let i = -14; i <= 14; i++) {
    const h = 8 + ((Math.abs(i * 7 + 3) % 6) * 3.8);
    const w = 9 + ((Math.abs(i * 3) % 4) * 3.2);
    const bldg = new THREE.Mesh(new THREE.BoxGeometry(w, h, 10), skylineMat);
    bldg.position.set(i * 22, h * 0.5, -262 - (Math.abs(i) % 4) * 14);
    worldGroup.add(bldg);
  }

  // Dusty red-earth village lanes & connecting heritage roads to Sal Forest (West) and Zamindar Bari (East)
  const roadMat = new THREE.MeshStandardMaterial({
    color: 0xa5744a,
    roughness: 0.96,
    metalness: 0.0,
    polygonOffset: true,
    polygonOffsetFactor: -1,
    polygonOffsetUnits: -1,
  });
  const mainLane = new THREE.Mesh(new THREE.PlaneGeometry(7.2, 54), roadMat);
  mainLane.rotation.x = -Math.PI / 2;
  mainLane.position.set(0, 0.03, 12);
  mainLane.receiveShadow = true;
  worldGroup.add(mainLane);

  // Extended East-West Heritage Road connecting Sal Forest (x = -124) <-> Village <-> Zamindar Bari (x = 78)
  const crossLane = new THREE.Mesh(new THREE.PlaneGeometry(202, 6.4), roadMat);
  crossLane.rotation.x = -Math.PI / 2;
  crossLane.position.set(-23, 0.035, 7);
  crossLane.receiveShadow = true;
  worldGroup.add(crossLane);

  // Branch drive leading into the Zamindar Bari grand West Portico (x = 76, z = 7 -> 22)
  const zamindarDrive = new THREE.Mesh(new THREE.PlaneGeometry(6.4, 24), roadMat);
  zamindarDrive.rotation.x = -Math.PI / 2;
  zamindarDrive.position.set(74, 0.038, 15);
  zamindarDrive.receiveShadow = true;
  worldGroup.add(zamindarDrive);

  // 3. Hooghly River Ghat Embankments (South + North Bank) + Central Stone Steps
  const ghatStoneMat = new THREE.MeshStandardMaterial({
    color: 0x9b8d7e,
    roughness: 0.88,
    metalness: 0.04,
  });
  const embankment = new THREE.Mesh(new THREE.BoxGeometry(1180, 2.2, 4.2), ghatStoneMat);
  embankment.position.set(0, -0.95, -18.2);
  embankment.receiveShadow = true;
  worldGroup.add(embankment);

  const northEmbankment = new THREE.Mesh(new THREE.BoxGeometry(1180, 2.2, 4.2), ghatStoneMat);
  northEmbankment.position.set(0, -0.95, -71.5);
  northEmbankment.receiveShadow = true;
  worldGroup.add(northEmbankment);

  // Central Ghat descending steps
  for (let s = 0; s < 5; s++) {
    const step = new THREE.Mesh(new THREE.BoxGeometry(20, 0.36, 1.1), ghatStoneMat);
    step.position.set(0, -0.18 - s * 0.28, -19.2 - s * 0.95);
    step.receiveShadow = true;
    worldGroup.add(step);
  }

  // Low heritage Bengal red-brick parapet walls flanking center ghat (leaving bridge ramp portals open!)
  const parapetMat = new THREE.MeshStandardMaterial({
    color: 0x9a4b35,
    roughness: 0.85,
  });
  for (const side of [-1, 1]) {
    const wall = new THREE.Mesh(new THREE.BoxGeometry(16, 0.9, 0.6), parapetMat);
    wall.position.set(side * 30.5, 0.45, -17.6);
    wall.castShadow = true;
    wall.receiveShadow = true;
    worldGroup.add(wall);
  }

  // 4. Shimmering Hooghly River water spanning full 1180m East-West map width
  const waterUniforms = { uTime: { value: 0 } };
  const waterMat = new THREE.MeshStandardMaterial({
    color: 0x266578,
    roughness: 0.18,
    metalness: 0.4,
    bumpMap: textures.waterBump,
    bumpScale: 0.16,
  });
  waterMat.onBeforeCompile = (shader) => {
    shader.uniforms.uTime = waterUniforms.uTime;
    shader.vertexShader =
      `uniform float uTime;\n` +
      shader.vertexShader.replace(
        '#include <begin_vertex>',
        `#include <begin_vertex>
         float waveA = sin(position.x * 0.14 + uTime * 1.45) * 0.11;
         float waveB = cos(position.y * 0.22 - uTime * 1.15) * 0.08;
         transformed.z += waveA + waveB;`,
      );
  };
  const riverMesh = new THREE.Mesh(new THREE.PlaneGeometry(1180, 56, 72, 16), waterMat);
  riverMesh.rotation.x = -Math.PI / 2;
  riverMesh.position.set(0, -1.25, -45);
  riverMesh.receiveShadow = true;
  worldGroup.add(riverMesh);

  // Original floating wooden country boat (Nouka) near the central ghat
  const boatGroup = buildRiverBoat();
  boatGroup.position.set(-8.5, -1.18, -26.2);
  boatGroup.rotation.y = 0.22;
  worldGroup.add(boatGroup);
  bobbingBoats.push(boatGroup);

  // 5. Iconic Howrah-style Cantilever Bridge + Walkable/Drivable North-South Crossing Ramps
  const bridge = buildHowrahBridge(textures);
  worldGroup.add(bridge);

  const crossingRamps = buildBridgeCrossingRamps();
  worldGroup.add(crossingRamps);

  // 6. Iconic Kolkata Yellow Ambassador Taxi parked near the village ghat road
  const taxi = buildYellowTaxi(textures);
  taxi.position.set(7.2, 0, -4.5);
  taxi.rotation.y = -0.35;
  worldGroup.add(taxi);
  circleColliders.push(
    { x: 6.1, z: -4.9, radius: 1.4, height: 1.85, kind: 'taxi' },
    { x: 8.3, z: -4.1, radius: 1.4, height: 1.85, kind: 'taxi' },
  );

  // 7. Village Mud Houses (Matir Ghor) arranged around the village square
  const houseSpecs = [
    { x: -16.5, z: -5.0, rotY: 0.35, w: 6.2, d: 4.8 },
    { x: -18.5, z: 14.5, rotY: 1.25, w: 6.6, d: 5.0 },
    { x: 18.0, z: 13.5, rotY: -1.35, w: 6.4, d: 5.0 },
    { x: -7.5, z: 26.5, rotY: 0.15, w: 6.2, d: 4.8 },
    { x: 11.5, z: 26.0, rotY: -0.25, w: 6.4, d: 5.0 },
    { x: 24.5, z: -5.5, rotY: -0.7, w: 6.0, d: 4.8 },
  ];

  for (const hs of houseSpecs) {
    const house = buildMudHouse(textures, hs.w, hs.d, 3.0);
    house.position.set(hs.x, 0, hs.z);
    house.rotation.y = hs.rotY;
    worldGroup.add(house);

    const approxR = Math.max(hs.w, hs.d) * 0.56;
    circleColliders.push({
      x: hs.x,
      z: hs.z,
      radius: approxR,
      height: 4.5,
      kind: 'house',
    });
  }

  // 8. Coconut Palm Trees (Narkel Gach) inside the village + scenic flanking groves
  const innerPalms: [number, number, number, number, number][] = [
    [-11.0, -13.5, 10.2, 1.2, -0.8],
    [11.4, -13.0, 9.6, -1.0, -0.9],
    [-25.5, -12.0, 10.8, 1.4, -0.4],
    [25.5, -12.5, 9.8, -1.2, 0.5],
    [-11.0, 4.5, 9.2, 0.9, 0.7],
    [13.0, 4.8, 10.4, -1.1, 0.6],
    [-26.0, 5.5, 10.6, 1.3, 0.4],
    [26.5, 5.0, 9.5, -0.9, -0.5],
    [-15.0, 23.0, 9.8, 0.7, 1.1],
    [2.5, 22.5, 10.5, -0.8, 0.9],
    [21.5, 23.5, 9.6, -1.0, 0.8],
    [-26.5, 22.0, 11.0, 1.1, -0.7],
  ];

  innerPalms.forEach(([x, z, h, lx, lz], idx) => {
    const { group, crown } = buildCoconutTree(textures, h, lx, lz);
    group.position.set(x, 0, z);
    worldGroup.add(group);
    swayingPalms.push({
      crown,
      phase: idx * 1.17,
      baseRotX: 0,
      baseRotZ: 0,
    });
    circleColliders.push({ x, z, radius: 0.62, height: h, kind: 'tree' });
  });

  // Outer Bengal village palms (keeping East/West heritage road corridors open!)
  for (let i = 0; i < 24; i++) {
    const angle = (i / 24) * Math.PI * 1.35 - Math.PI * 0.175;
    const radius = 38 + (i % 3) * 5;
    const x = Math.cos(angle) * radius;
    const z = Math.sin(angle) * radius + 10;
    if (z < -15) continue;
    if (z > 1 && z < 13) continue; // Keep westbound & eastbound landmark roads open
    const h = 9.0 + (i % 4) * 1.4;
    const { group, crown } = buildCoconutTree(
      textures,
      h,
      Math.cos(i) * 1.2,
      Math.sin(i) * 1.0,
    );
    group.position.set(x, sampleLateriteHillHeight(x, z), z);
    worldGroup.add(group);
    swayingPalms.push({ crown, phase: i * 0.73, baseRotX: 0, baseRotZ: 0 });
  }

  // 9. Instanced tropical bushes & hibiscus shrubs around village houses
  const bushCount = 68;
  const bushGeo = new THREE.DodecahedronGeometry(0.95, 1);
  const bushMat = new THREE.MeshStandardMaterial({
    color: 0x3b6e28,
    roughness: 0.88,
    metalness: 0.0,
  });
  const bushes = new THREE.InstancedMesh(bushGeo, bushMat, bushCount);
  const dummy = new THREE.Object3D();
  const color = new THREE.Color();
  const bushPalette = [0x336522, 0x457b2d, 0x2a561e, 0x558432];

  let bIdx = 0;
  for (let i = 0; i < bushCount; i++) {
    const isOuter = i >= 22;
    let bx: number;
    let bz: number;
    if (isOuter) {
      const a = ((i - 22) / (bushCount - 22)) * Math.PI * 1.32 - Math.PI * 0.16;
      const r = 34.5 + (i % 4) * 2.4;
      bx = Math.cos(a) * r;
      bz = Math.sin(a) * r + 10;
      if (bz < -15.5) bz = 36 + (i % 5) * 2;
      if (bz > 1.5 && bz < 12.5) bz += 10; // Clear roads
    } else {
      const hs = houseSpecs[i % houseSpecs.length];
      const ang = (i * 2.1) % (Math.PI * 2);
      bx = hs.x + Math.cos(ang) * 4.4;
      bz = hs.z + Math.sin(ang) * 4.2;
    }
    const s = 0.65 + (i % 5) * 0.22;
    const by = sampleLateriteHillHeight(bx, bz);
    dummy.position.set(bx, by + s * 0.55, bz);
    dummy.rotation.set(0, i * 0.9, 0);
    dummy.scale.set(s * 1.25, s * 0.78, s * 1.15);
    dummy.updateMatrix();
    bushes.setMatrixAt(bIdx, dummy.matrix);
    color.setHex(bushPalette[i % bushPalette.length]);
    bushes.setColorAt(bIdx, color);
    bIdx++;
  }
  bushes.instanceMatrix.needsUpdate = true;
  if (bushes.instanceColor) bushes.instanceColor.needsUpdate = true;
  bushes.computeBoundingSphere();
  worldGroup.add(bushes);

  // 10. Low tactical village crate cover clusters in the open square
  const crateMat = new THREE.MeshStandardMaterial({
    color: 0x8b623c,
    roughness: 0.88,
  });
  const coverPositions: [number, number, number][] = [
    [-6.5, 4.5, 0.2],
    [5.8, 14.5, -0.4],
    [-4.5, -10.5, 0.1],
  ];
  for (const [cx, cz, rot] of coverPositions) {
    const cluster = new THREE.Group();
    cluster.position.set(cx, 0, cz);
    cluster.rotation.y = rot;

    const c1 = new THREE.Mesh(new THREE.BoxGeometry(1.6, 0.95, 1.0), crateMat);
    c1.position.set(0, 0.475, 0);
    c1.castShadow = true;
    c1.receiveShadow = true;
    cluster.add(c1);

    const c2 = new THREE.Mesh(new THREE.BoxGeometry(0.95, 0.78, 0.95), crateMat);
    c2.position.set(1.15, 0.39, 0.15);
    c2.rotation.y = 0.25;
    c2.castShadow = true;
    cluster.add(c2);

    addContactShadow(cluster, textures.contactShadowMap, 3.2, 2.0, 0.42);
    worldGroup.add(cluster);
    circleColliders.push({ x: cx + 0.35, z: cz, radius: 1.35, height: 1.0, kind: 'prop' });
  }

  // ============================================================================
  // 11. FOUR EXPANDED WEST BENGAL LANDMARKS ACROSS THE 1000x1000 ARENA
  // ============================================================================

  // Landmark 1: শালবন ও লাল মাটির টিলা (Red-Soil Sal Forest & Hills — West / NW Sector)
  const salForest = buildSalForestAndHills(sampleLateriteHillHeight);
  worldGroup.add(salForest.group);
  circleColliders.push(...salForest.colliders);
  landmarkSanjibaniAnchors.push(...salForest.sanjibaniAnchors);
  landmarkChestAnchors.push(...salForest.chestAnchors);

  // Landmark 2: পুরনো জমিদার বাড়ি (Abandoned Zamindar Bari — East / NE Sector)
  const zamindarCenterX = 98;
  const zamindarCenterZ = 22;
  const zamindarBari = buildZamindarBari(zamindarCenterX, zamindarCenterZ);
  worldGroup.add(zamindarBari.group);
  circleColliders.push(...zamindarBari.colliders);
  landmarkChestAnchors.push(...zamindarBari.chestAnchors);
  landmarkSanjibaniAnchors.push(...zamindarBari.sanjibaniAnchors);

  // Landmark 3: পুরনো ট্রাম ডিপো ও বাজার (Old Tram Depot & Bazaar — North Bank across Bridge)
  const tramDepotCenterX = 0;
  const tramDepotCenterZ = -124;
  const tramDepot = buildOldTramDepotAndBazaar(tramDepotCenterX, tramDepotCenterZ, () =>
    buildYellowTaxi(textures),
  );
  worldGroup.add(tramDepot.group);
  circleColliders.push(...tramDepot.colliders);
  landmarkChestAnchors.push(...tramDepot.chestAnchors);
  landmarkSanjibaniAnchors.push(...tramDepot.sanjibaniAnchors);

  // Landmark 4: নদীর বাঁধানো ঘাট ও নৌকা (Extended Riverbank Ghat, Moored Boats & Huts)
  const extendedGhat = buildExtendedRiverGhat(buildRiverBoat);
  worldGroup.add(extendedGhat.group);
  circleColliders.push(...extendedGhat.colliders);
  bobbingBoats.push(...extendedGhat.bobbingBoats);
  landmarkChestAnchors.push(...extendedGhat.chestAnchors);
  landmarkSanjibaniAnchors.push(...extendedGhat.sanjibaniAnchors);

  // 12. Lightweight Distant Bengal Horizon Tree Belt (r = 250..470) so the 1000x1000 perimeter feels lush
  const outerTreeCount = 180;
  const oTrunkGeo = new THREE.CylinderGeometry(0.4, 0.62, 12.5, 6);
  oTrunkGeo.translate(0, 6.25, 0);
  const oCrownGeo = new THREE.DodecahedronGeometry(3.8, 1);
  const oTrunkMat = new THREE.MeshStandardMaterial({ color: 0x5d4736, roughness: 0.94 });
  const oCrownMat = new THREE.MeshStandardMaterial({ color: 0x356c2a, roughness: 0.88 });
  const outerTrunks = new THREE.InstancedMesh(oTrunkGeo, oTrunkMat, outerTreeCount);
  const outerCrowns = new THREE.InstancedMesh(oCrownGeo, oCrownMat, outerTreeCount);
  let otPlaced = 0;
  for (let i = 0; i < outerTreeCount * 2 && otPlaced < outerTreeCount; i++) {
    const a = (i / (outerTreeCount * 1.4)) * Math.PI * 2 + (i % 7) * 0.13;
    const rad = 255 + ((i * 53) % 210);
    const tx = Math.cos(a) * rad;
    const tz = Math.sin(a) * rad;
    if (tz > -78 && tz < -14) continue; // Keep Hooghly river clear
    const ty = sampleLateriteHillHeight(tx, tz);
    const sc = 0.85 + ((i * 17) % 10) * 0.06;
    dummy.position.set(tx, ty - 0.2, tz);
    dummy.rotation.set(0, a, 0);
    dummy.scale.set(sc, sc, sc);
    dummy.updateMatrix();
    outerTrunks.setMatrixAt(otPlaced, dummy.matrix);

    dummy.position.set(tx, ty + 11.2 * sc, tz);
    dummy.scale.set(sc * 1.15, sc * 0.9, sc * 1.15);
    dummy.updateMatrix();
    outerCrowns.setMatrixAt(otPlaced, dummy.matrix);
    otPlaced++;
  }
  outerTrunks.count = otPlaced;
  outerCrowns.count = otPlaced;
  outerTrunks.instanceMatrix.needsUpdate = true;
  outerCrowns.instanceMatrix.needsUpdate = true;
  outerTrunks.computeBoundingSphere();
  outerCrowns.computeBoundingSphere();
  worldGroup.add(outerTrunks, outerCrowns);

  // Unified Analytical Ground Elevation (Bridge Deck/Ramps + Zamindar Bari Stairs/Terrace + Laterite Hills)
  const getGroundHeight = (x: number, z: number, currentY?: number): number => {
    const bridgeY = sampleBridgeCrossingHeight(x, z);
    if (bridgeY !== null) return bridgeY;

    const zamindarY = zamindarBari.getTerraceHeight(x, z, currentY);
    if (zamindarY > 0) return zamindarY;

    return sampleLateriteHillHeight(x, z);
  };

  // Water collision test: blocks wading into deep Hooghly River except along bridge deck & crossing ramps
  const isWaterBlocked = (x: number, z: number): boolean => {
    if (z <= -70.5 || z >= -20.5) return false;
    return sampleBridgeCrossingHeight(x, z) === null;
  };

  // Dynamic Bengali Area Name for Top HUD Location Badge
  const getLocationName = (x: number, z: number, currentY?: number): string => {
    const onBridge = sampleBridgeCrossingHeight(x, z) !== null;
    if (onBridge && (z < -17 || (currentY !== undefined && currentY > 1.2))) {
      return 'হাওড়া সেতু';
    }
    if (z < -70) {
      if (x < -86) return 'শালবন';
      return 'ট্রাম ডিপো';
    }
    if (z >= -23 && z <= -9.5 && Math.abs(x) <= 118) {
      return 'নদীর ঘাট';
    }
    if (x > 64 && x < 144 && z > -14 && z < 64) {
      return 'জমিদার বাড়ি';
    }
    if (x < -46) {
      return 'শালবন';
    }
    return 'বাংলার গ্রাম';
  };

  // Enemy spawn points distributed across Village Square AND the 4 Bengali landmarks
  const enemySpawnPoints = [
    // Village Square (keeps immediate early action lively)
    new THREE.Vector3(-26, 0, -10),
    new THREE.Vector3(26, 0, -10),
    new THREE.Vector3(-27, 0, 8),
    new THREE.Vector3(27, 0, 8),
    new THREE.Vector3(-22, 0, 29),
    new THREE.Vector3(0, 0, 32),
    new THREE.Vector3(22, 0, 29),
    // Riverbank Ghat flanks
    new THREE.Vector3(-56, 0, -13),
    new THREE.Vector3(58, 0, -13),
    // Sal Forest & Red-Soil Hills
    new THREE.Vector3(-76, sampleLateriteHillHeight(-76, 30), 30),
    new THREE.Vector3(-116, sampleLateriteHillHeight(-116, 48), 48),
    new THREE.Vector3(-148, sampleLateriteHillHeight(-148, 72), 72),
    // Abandoned Zamindar Bari courtyard & garden
    new THREE.Vector3(74, 0, 22),
    new THREE.Vector3(98, 0.18, 12),
    new THREE.Vector3(118, 0, 22),
    // Old Tram Depot & Bazaar across Howrah Bridge
    new THREE.Vector3(-18, 0, -96),
    new THREE.Vector3(20, 0, -102),
    new THREE.Vector3(0, 0, -134),
  ];

  const pickupAnchors = [
    new THREE.Vector3(3.2, 0, -6.5),
    new THREE.Vector3(-9.0, 0, 9.5),
    new THREE.Vector3(10.0, 0, 9.0),
    new THREE.Vector3(0.0, 0, 17.5),
    new THREE.Vector3(-10.5, 0, -10.5),
    new THREE.Vector3(-78, sampleLateriteHillHeight(-78, 34), 34),
    new THREE.Vector3(98, 0.18, 28),
    new THREE.Vector3(8, 0, -112),
  ];

  return {
    worldGroup,
    boxColliders,
    circleColliders,
    swayingPalms,
    boatGroup,
    bobbingBoats,
    waterUniforms,
    waterBumpTexture: textures.waterBump,
    enemySpawnPoints,
    pickupAnchors,
    landmarkChestAnchors,
    landmarkSanjibaniAnchors,
    playableBounds: { minX: -485, maxX: 485, minZ: -485, maxZ: 485 },
    getGroundHeight,
    isWaterBlocked,
    getLocationName,
  };
}
