import * as THREE from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { GameAudio } from './audio';
import {
  buildBajraGolaMesh,
  buildKalboishakhiStormWall,
  buildWarriorChest,
  createFloatingDamageSprite,
  KalboishakhiStormRig,
  WarriorChestRig,
} from './battleRoyaleAssets';
import {
  buildWbtcBus,
  BusRouteData,
  createBusIntroRoute,
  WbtcBusRig,
} from './bus';
import {
  buildBengaliHero,
  buildEnemyBot,
  buildPickupMesh,
  EnemyRig,
  HeroRig,
} from './characters';
import { GraphicsQuality } from './settings';
import { createTextureBundle, TextureBundle } from './textures';
import {
  BusMode,
  CircleCollider,
  EnemyArchetype,
  GamchaStyle,
  GamePhase,
  HudSnapshot,
  PickupKind,
  VirtualInputState,
  WEAPON_CATALOG,
  WEAPON_SLOT_ORDER,
  WeaponSlotSnapshot,
  WeaponType,
} from './types';
import { buildWestBengalWorld, WorldBuildResult } from './worldBuilder';

interface ActiveEnemy {
  id: number;
  archetype: EnemyArchetype;
  rig: EnemyRig;
  hp: number;
  maxHp: number;
  speed: number;
  radius: number;
  fireRange: number;
  fireCooldown: number;
  telegraphTimer: number;
  strafeDir: number;
  strafeTimer: number;
  walkPhase: number;
  hitFlashTimer: number;
  dying: boolean;
  deathTimer: number;
  knockback: THREE.Vector3;
  // Bus riding, smooth jump landing & 2-second post-landing safe phase
  busSeatIndex: number; // -1 when on foot or jumping
  busDropT: number;
  jumpingFromBus: boolean;
  jumpProgress: number;
  jumpDuration: number;
  jumpStart: THREE.Vector3;
  jumpEnd: THREE.Vector3;
  jumpPeakY: number;
  postLandingSafeTimer: number; // 2.0s after touching y=0 before enemy can aim or shoot
  // Natural human animation states (damped yaw, cloth lag, recoil, blinking, landing cushion)
  prevYaw: number;
  yawRate: number;
  recoil: number;
  blinkTimer: number;
  blinkPhase: number;
  moveBlend: number;
  landingCrouch: number;
  deathSide: number;
  // Tactical cover AI, smooth velocity, combat posture & hit-flinch feedback
  velX: number;
  velZ: number;
  tacticState: 'advance' | 'seek_cover' | 'hold_cover' | 'flank';
  tacticTimer: number;
  coverX: number;
  coverZ: number;
  hasCoverSpot: boolean;
  coverPeekTimer: number;
  coverPeeking: boolean;
  coverCrouch: number;
  aimBlend: number;
  flinchTimer: number;
  flinchHead: boolean;
  flinchSide: number;
  burstRemaining: number;
  burstDelay: number;
}

interface Bullet {
  active: boolean;
  fromPlayer: boolean;
  mesh: THREE.Mesh;
  pos: THREE.Vector3;
  vel: THREE.Vector3;
  life: number;
  damage: number;
  sourceX: number;
  sourceZ: number;
}

interface ImpactFlash {
  active: boolean;
  mesh: THREE.Mesh;
  material: THREE.MeshBasicMaterial;
  life: number;
  maxLife: number;
  maxScale: number;
}

interface Particle {
  active: boolean;
  mesh: THREE.Mesh;
  pos: THREE.Vector3;
  vel: THREE.Vector3;
  life: number;
  maxLife: number;
  scale: number;
}

interface PickupItem {
  id: number;
  kind: PickupKind;
  mesh: THREE.Group;
  pos: THREE.Vector3;
  life: number;
}

interface LootChestItem {
  id: number;
  rig: WarriorChestRig;
  pos: THREE.Vector3;
  opened: boolean;
  openProgress: number;
  life: number;
}

interface ThrownGrenade {
  id: number;
  mesh: THREE.Group;
  pos: THREE.Vector3;
  vel: THREE.Vector3;
  fuseTimer: number;
}

interface FloatingDamageText {
  sprite: THREE.Sprite;
  texture: THREE.CanvasTexture;
  material: THREE.SpriteMaterial;
  pos: THREE.Vector3;
  velY: number;
  life: number;
  maxLife: number;
  baseScaleX: number;
  baseScaleY: number;
}

interface ExplosionShockwave {
  mesh: THREE.Mesh;
  life: number;
  maxLife: number;
}

// Pre-allocated zero-GC scratch helpers
const _v1 = new THREE.Vector3();
const _v2 = new THREE.Vector3();
const _v3 = new THREE.Vector3();
const _v4 = new THREE.Vector3();
const _v5 = new THREE.Vector3();
const _v6 = new THREE.Vector3();
const _camTarget = new THREE.Vector3();
const _camDesired = new THREE.Vector3();
const _lookAtPt = new THREE.Vector3();

const STORAGE_KEY_HIGHSCORE = 'banglar_joddha_high_score_v1';

const BENGALI_DIGITS = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];
export function toBengaliNumber(n: number): string {
  return String(Math.max(0, Math.floor(n)))
    .split('')
    .map((ch) => {
      const code = ch.charCodeAt(0) - 48;
      return code >= 0 && code <= 9 ? BENGALI_DIGITS[code] : ch;
    })
    .join('');
}

export class GameEngine {
  private container: HTMLElement;
  private onHudUpdate: (snapshot: HudSnapshot) => void;
  private isSoftwareGl: boolean;
  private renderer: THREE.WebGLRenderer;
  private scene: THREE.Scene;
  private camera: THREE.PerspectiveCamera;
  private sunLight: THREE.DirectionalLight;
  private textures: TextureBundle;
  private world: WorldBuildResult;
  private bus: WbtcBusRig;
  private busRoute: BusRouteData;
  private hero: HeroRig;
  private audio: GameAudio;

  // Game state
  private phase: GamePhase = 'title';
  private busMode: BusMode = 'none';
  private busAutoDriving = false;
  private busRouteT = 0;
  private busPos = new THREE.Vector3(-13, 0, 8.2);
  private busYaw = -Math.PI / 2;
  private busSpeed = 0;
  private busSteerAngle = 0;
  private busZoneLabel: string | null = null;
  private nearBus = false;
  // Realistic WBTC Bus Interior Camera & Direct Ground Exit (Braking + Bi-Fold Door Open, No Parachute)
  private busInteriorCam = true;
  private busExitSlowing = false;
  private busExitSlowTimer = 0;
  private readonly busExitSlowDuration = 0.54;
  private busDoorOpenAmount = 0;
  private busDoorAutoHoldTimer = 0;
  private busInteriorLookYaw = 0;
  private heroDoorwayWorld = new THREE.Vector3();
  // Short grounded hop arc when stepping/jumping directly onto bridge or road from open bus door
  private heroJumpingFromBus = false;
  private heroJumpProgress = 0;
  private heroJumpDuration = 0.26;
  private heroJumpStart = new THREE.Vector3();
  private heroJumpEnd = new THREE.Vector3();
  private heroJumpPeakY = 1.2;

  private gamchaStyle: GamchaStyle = 'red-white';
  private weaponType: WeaponType = 'agni47';
  private weaponSlots: Record<WeaponType, WeaponSlotSnapshot> = {
    agni47: {
      ammo: WEAPON_CATALOG.agni47.magSize,
      maxAmmo: WEAPON_CATALOG.agni47.magSize,
      reserve: WEAPON_CATALOG.agni47.startReserve,
    },
    kalbhairav: {
      ammo: WEAPON_CATALOG.kalbhairav.magSize,
      maxAmmo: WEAPON_CATALOG.kalbhairav.magSize,
      reserve: WEAPON_CATALOG.kalbhairav.startReserve,
    },
    trishul: {
      ammo: WEAPON_CATALOG.trishul.magSize,
      maxAmmo: WEAPON_CATALOG.trishul.magSize,
      reserve: WEAPON_CATALOG.trishul.startReserve,
    },
    fala: { ammo: 0, maxAmmo: 0, reserve: 0 },
  };
  private scopeActive = false;
  private currentFov = 68;
  private meleeSlashTimer = 0;

  private heroPos = new THREE.Vector3(0, 0, 7.2);
  private prevHeroPos = new THREE.Vector3(0, 0, 7.2);
  private prevHeroYaw = 0.28;
  private heroYaw = 0.28; // heroic 3/4 stance facing lobby camera
  private lobbyHeroYaw = 0.28;
  private lobbyHeroTargetYaw = 0.28;
  private lobbyShowcasePulse = 0;
  private heroWalkPhase = 0;
  private heroWalkWeight = 0;
  private heroSprintWeight = 0;
  private heroAimWeight = 0;
  private heroAimPitch = 0;
  private heroTurnLean = 0;
  private heroStrafeBlend = 0;
  private heroForwardBlend = 0;
  private heroVelX = 0;
  private heroVelZ = 0;
  private heroSpeedMult = 1.0;
  private heroFireHoldTimer = 0;
  private heroLandingCrouch = 0;
  private heroBlinkTimer = 2.6;
  private heroBlinkPhase = 0;
  private heroRecoil = 0;
  private muzzleFlashTimer = 0;
  private health = 100;
  private readonly maxHealth = 100;
  private armor = 0;
  private readonly maxArmor = 50;
  private isReloading = false;
  private reloadTimer = 0;
  private reloadDuration = 1.15;
  private fireCooldown = 0;
  private sprintStamina = 1.0;

  // Sanjibani Healing Plants & Bajra Gola Grenades
  private sanjibaniCount = 1;
  private sanjibaniCollected = 0;
  private readonly maxSanjibani = 5;
  private isHealing = false;
  private healTimer = 0;
  private readonly healDuration = 3.0;
  private grenadeCount = 1;
  private readonly maxGrenades = 3;

  // Warrior Loot Chests proximity
  private nearChest = false;
  private nearestChest: LootChestItem | null = null;

  // Headshot & Body Shot counters
  private headshots = 0;
  private bodyshots = 0;
  private hitMarkerHeadshot = false;

  // Kalboishakhi Shrinking Safe Zone (starts full-map at 550u, contracts in 4 stages every 90s)
  private stormRig!: KalboishakhiStormRig;
  private stormCenter = new THREE.Vector2(0, 6);
  private readonly initialStormRadius = 550;
  private readonly stormPhaseInterval = 90;
  private stormPhase = 1;
  private stormRadius = 550;
  private stormStartRadius = 550;
  private stormTargetRadius = 550;
  private stormCountdown = 90;
  private stormShrinking = false;
  private stormShrinkElapsed = 0;
  private readonly stormShrinkDuration = 22;
  private readonly outsideStormDuration = 60;
  private outsideStorm = false;
  private outsideStormElapsed = 0;
  private stormDrainTimer = 0;
  private stormTeleportFlash = 0;

  private score = 0;
  private highScore = 0;
  private kills = 0;
  private wave = 1;
  private waveEnemiesToSpawn: EnemyArchetype[] = [];
  private waveSpawnTimer = 0;
  private waveBreakTimer = 0;
  private waveBanner: string | null = null;
  private waveBannerTimer = 0;
  private pickupToast: string | null = null;
  private pickupToastTimer = 0;

  // Juice, Lobby & Camera Transition
  private camYaw = Math.PI; // looking north (-Z) toward the river & bridge
  private camPitch = 0.2;
  private camShake = 0;
  private camRecoilPitch = 0;
  private camRecoilYaw = 0;
  private camSprintBlend = 0;
  private reticleSpread = 0;
  private hitstopTimer = 0;
  private damageFlash = 0;
  private damageAngle: number | null = null;
  private damageSourcePos = new THREE.Vector3();
  private hasDamageSource = false;
  private hitMarker = 0;
  private hitMarkerKill = false;
  private titleTime = 0;
  private worldTime = 0;
  private introTransitionProgress = 1; // < 1 while sweeping from lobby into gameplay
  private readonly introTransitionDuration = 0.92;
  private introStartCamPos = new THREE.Vector3();
  private introStartLookAt = new THREE.Vector3();
  private lobbyDragActive = false;
  private lobbyDragPointerId: number | null = null;
  private lobbyLastDragX = 0;

  // Entities & Pools
  private enemies: ActiveEnemy[] = [];
  private nextEnemyId = 1;
  private pickups: PickupItem[] = [];
  private nextPickupId = 1;
  private chests: LootChestItem[] = [];
  private nextChestId = 1;
  private grenades: ThrownGrenade[] = [];
  private nextGrenadeId = 1;
  private floatingDamages: FloatingDamageText[] = [];
  private shockwaves: ExplosionShockwave[] = [];
  private bullets: Bullet[] = [];
  private particles: Particle[] = [];
  private impactFlashes: ImpactFlash[] = [];

  // Input state (including mobile 2-finger pinch-to-zoom)
  private keysHeld = new Set<string>();
  private mouseShootHeld = false;
  private dragLookActive = false;
  private dragPointerId: number | null = null;
  private lastDragX = 0;
  private lastDragY = 0;
  private activeTouchPointers = new Map<number, { x: number; y: number }>();
  private lastPinchDist: number | null = null;
  private pinchFovOffset = 0;
  private virtualInput: VirtualInputState = {
    moveX: 0,
    moveY: 0,
    shooting: false,
    sprinting: false,
    reloadJustPressed: false,
    lookDeltaX: 0,
    lookDeltaY: 0,
  };

  // Player Settings (Sensitivity & Mobile Graphics Quality)
  private generalSensitivity = 50;
  private scopeSensitivity = 45;
  private graphicsQuality: GraphicsQuality = 'medium';

  // Loop & lifecycle
  private disposed = false;
  private frameId = 0;
  private lastFrameMs = 0;
  private hudEmitAccum = 0;
  private resizeObserver: ResizeObserver | null = null;
  private orientationResizeTimer: number | null = null;

  constructor(container: HTMLElement, onHudUpdate: (snapshot: HudSnapshot) => void) {
    this.container = container;
    this.onHudUpdate = onHudUpdate;
    this.audio = new GameAudio();

    try {
      const saved = localStorage.getItem(STORAGE_KEY_HIGHSCORE);
      if (saved) this.highScore = Math.max(0, parseInt(saved, 10) || 0);
    } catch {
      // ignore storage restrictions
    }

    // Software WebGL detection from GPU renderer string (never user agent)
    this.isSoftwareGl = (() => {
      const gl = document.createElement('canvas').getContext('webgl2');
      if (!gl) return true;
      const ext = gl.getExtension('WEBGL_debug_renderer_info');
      const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
      const gpu = String(gl.getParameter(param));
      gl.getExtension('WEBGL_lose_context')?.loseContext();
      return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
    })();

    this.renderer = new THREE.WebGLRenderer({
      antialias: !this.isSoftwareGl,
      powerPreference: 'high-performance',
    });
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.24;
    this.renderer.setPixelRatio(this.isSoftwareGl ? 1 : Math.min(window.devicePixelRatio || 1, 1.5));
    this.renderer.shadowMap.enabled = !this.isSoftwareGl;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.setSize(container.clientWidth || window.innerWidth, container.clientHeight || window.innerHeight);

    this.renderer.domElement.style.display = 'block';
    this.renderer.domElement.style.width = '100%';
    this.renderer.domElement.style.height = '100%';
    container.appendChild(this.renderer.domElement);

    // Scene & bright sunny Bengali daytime atmosphere (clear blue sky + light airy horizon haze across 1000x1000 map)
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x87cefa);
    this.scene.fog = new THREE.FogExp2(0xc7e6fa, 0.0011);

    // Mandatory studio environment map via RoomEnvironment on all devices
    const pmrem = new THREE.PMREMGenerator(this.renderer);
    const envScene = new RoomEnvironment();
    this.scene.environment = pmrem.fromScene(envScene, 0.04).texture;
    envScene.dispose();
    pmrem.dispose();

    // Camera (FOV 68° for expansive full-screen mobile landscape view; far plane 1650 for full 1000x1000 map)
    const aspect =
      (container.clientWidth || window.innerWidth) /
      Math.max(1, container.clientHeight || window.innerHeight);
    this.camera = new THREE.PerspectiveCamera(68, aspect, 0.15, 1650);

    // Bright sunny Bengali daytime lighting rig across bridge, river, and village
    const ambient = new THREE.AmbientLight(0xfff9ed, 0.52);
    this.scene.add(ambient);

    const hemi = new THREE.HemisphereLight(0xbbe6ff, 0xa8916b, 1.15);
    this.scene.add(hemi);

    this.sunLight = new THREE.DirectionalLight(0xfff4d4, 2.75);
    this.sunLight.position.set(34, 58, -26);
    this.sunLight.castShadow = true;
    this.sunLight.shadow.mapSize.set(1024, 1024);
    this.sunLight.shadow.radius = 2;
    const d = 34;
    this.sunLight.shadow.camera.left = -d;
    this.sunLight.shadow.camera.right = d;
    this.sunLight.shadow.camera.top = d;
    this.sunLight.shadow.camera.bottom = -d;
    this.sunLight.shadow.camera.near = 2;
    this.sunLight.shadow.camera.far = 140;
    this.sunLight.shadow.bias = -0.0005;
    this.sunLight.shadow.normalBias = 0.025;
    this.scene.add(this.sunLight);
    this.scene.add(this.sunLight.target);

    // Crisp daytime sky rim fill + warm front fill so the hero and village stay bright from every angle
    const rimLight = new THREE.DirectionalLight(0xdff3ff, 0.68);
    rimLight.position.set(-30, 24, -45);
    this.scene.add(rimLight);

    const frontFillLight = new THREE.DirectionalLight(0xfff4d8, 0.78);
    frontFillLight.position.set(16, 18, 24);
    this.scene.add(frontFillLight);

    // Procedural Textures, World, WBTC Passenger Bus & Hero
    this.textures = createTextureBundle(this.renderer);
    this.world = buildWestBengalWorld(this.textures);
    this.scene.add(this.world.worldGroup);

    this.busRoute = createBusIntroRoute();
    this.scene.add(this.busRoute.rampMesh);

    this.bus = buildWbtcBus(this.textures);
    this.bus.root.position.set(-13, 0, 8.2);
    this.scene.add(this.bus.root);

    this.hero = buildBengaliHero(this.textures);
    this.hero.root.position.copy(this.heroPos);
    this.hero.root.rotation.y = this.heroYaw;
    this.scene.add(this.hero.root);

    // Kalboishakhi Shrinking Storm Wall (hidden in title lobby, active during match)
    this.stormRig = buildKalboishakhiStormWall();
    this.stormRig.root.visible = false;
    this.scene.add(this.stormRig.root);

    // Pre-allocate bullet & particle pools
    this.initPools();

    // Pre-warm shaders on GPU (skip on software WebGL)
    if (!this.isSoftwareGl) {
      this.renderer.compile(this.scene, this.camera);
    }

    this.bindEvents();
    this.emitHud();

    this.lastFrameMs = performance.now();
    this.tick();
  }

  private initPools(): void {
    // High-readability elongated golden-white player tracers & crisp orange-red enemy tracers
    const playerBulletGeo = new THREE.BoxGeometry(0.055, 0.055, 1.35);
    const enemyBulletGeo = new THREE.SphereGeometry(0.13, 6, 6);
    const playerBulletMat = new THREE.MeshBasicMaterial({ color: 0xfff0a8 });
    const enemyBulletMat = new THREE.MeshBasicMaterial({ color: 0xff4224 });

    for (let i = 0; i < 52; i++) {
      const isPlayer = i < 30;
      const mesh = new THREE.Mesh(
        isPlayer ? playerBulletGeo : enemyBulletGeo,
        isPlayer ? playerBulletMat : enemyBulletMat,
      );
      mesh.visible = false;
      this.scene.add(mesh);
      this.bullets.push({
        active: false,
        fromPlayer: isPlayer,
        mesh,
        pos: new THREE.Vector3(),
        vel: new THREE.Vector3(),
        life: 0,
        damage: isPlayer ? 34 : 11,
        sourceX: 0,
        sourceZ: 0,
      });
    }

    const partGeo = new THREE.BoxGeometry(0.13, 0.13, 0.13);
    for (let i = 0; i < 84; i++) {
      const mat = new THREE.MeshBasicMaterial({ color: 0xffb84d });
      const mesh = new THREE.Mesh(partGeo, mat);
      mesh.visible = false;
      this.scene.add(mesh);
      this.particles.push({
        active: false,
        mesh,
        pos: new THREE.Vector3(),
        vel: new THREE.Vector3(),
        life: 0,
        maxLife: 0.4,
        scale: 1,
      });
    }

    // Pooled 3D impact burst rings for unmistakable hit confirmation on enemies & cover
    const ringGeo = new THREE.RingGeometry(0.11, 0.24, 16);
    for (let i = 0; i < 14; i++) {
      const mat = new THREE.MeshBasicMaterial({
        color: 0xffe066,
        transparent: true,
        opacity: 0.9,
        side: THREE.DoubleSide,
        depthWrite: false,
      });
      const mesh = new THREE.Mesh(ringGeo, mat);
      mesh.visible = false;
      mesh.renderOrder = 20;
      this.scene.add(mesh);
      this.impactFlashes.push({
        active: false,
        mesh,
        material: mat,
        life: 0,
        maxLife: 0.16,
        maxScale: 1.5,
      });
    }
  }

  // --- Public API for React UI ---

  public setGamchaStyle(style: GamchaStyle): void {
    this.gamchaStyle = style;
    this.hero.gamchaMaterial.map =
      style === 'green-white' ? this.textures.gamchaGreenMap : this.textures.gamchaMap;
    this.hero.gamchaMaterial.needsUpdate = true;
    this.lobbyShowcasePulse = 1.0;
    this.audio.unlock();
    this.audio.playPickup('health');
  }

  public setWeaponType(weapon: WeaponType): void {
    this.weaponType = weapon;
    this.hero.rifleGroup.visible = weapon === 'agni47';
    this.hero.shotgunGroup.visible = weapon === 'kalbhairav';
    this.hero.trishulGroup.visible = weapon === 'trishul';
    this.hero.falaGroup.visible = weapon === 'fala';
    this.hero.muzzlePoint.position.set(
      0,
      0.028,
      weapon === 'trishul' ? 1.28 : weapon === 'kalbhairav' ? 0.92 : 0.97,
    );

    // Cancel reload when switching weapons; keep zoom smoothly synced
    this.isReloading = false;
    this.reloadTimer = 0;
    this.reloadDuration = WEAPON_CATALOG[weapon].reloadDuration || 1.15;
    if (weapon === 'fala') {
      this.scopeActive = false;
      this.pinchFovOffset = 0;
    }

    this.lobbyShowcasePulse = 1.0;
    this.audio.unlock();
    this.audio.playReload();
    this.emitHud();
  }

  public toggleScope(): void {
    if (this.phase !== 'playing' || this.busMode !== 'none') return;
    this.scopeActive = !this.scopeActive;
    this.pinchFovOffset = 0;
    if (this.scopeActive) {
      this.isHealing = false;
    }
    this.emitHud();
  }

  public useSanjibani(): void {
    if (this.phase !== 'playing' || this.busMode !== 'none' || this.heroJumpingFromBus) return;
    if (this.isHealing) return;
    if (this.sanjibaniCount <= 0) {
      this.pickupToast = 'সঞ্জীবনী গাছ নেই!';
      this.pickupToastTimer = 1.4;
      this.emitHud();
      return;
    }
    if (this.health >= this.maxHealth) {
      this.pickupToast = 'স্বাস্থ্য ইতিমধ্যেই পূর্ণ!';
      this.pickupToastTimer = 1.4;
      this.emitHud();
      return;
    }
    this.audio.unlock();
    this.isHealing = true;
    this.healTimer = this.healDuration;
    this.scopeActive = false;
    this.isReloading = false;
    this.pickupToast = 'সঞ্জীবনী গাছ ব্যবহার হচ্ছে...';
    this.pickupToastTimer = 1.5;
    this.emitHud();
  }

  public throwGrenade(): void {
    if (this.phase !== 'playing' || this.busMode !== 'none' || this.heroJumpingFromBus) return;
    if (this.grenadeCount <= 0) {
      this.pickupToast = 'বজ্র গোলা নেই!';
      this.pickupToastTimer = 1.4;
      this.emitHud();
      return;
    }

    this.audio.unlock();
    this.audio.playGrenadeThrow();
    this.grenadeCount--;
    this.isHealing = false;
    this.scopeActive = false;

    const mesh = buildBajraGolaMesh();
    const startPos = new THREE.Vector3(this.heroPos.x, 1.55, this.heroPos.z);
    const camForward = _v1.set(0, 0, -1).applyQuaternion(this.camera.quaternion).normalize();
    startPos.addScaledVector(camForward, 0.75);
    mesh.position.copy(startPos);
    this.scene.add(mesh);

    // Smooth parabolic lob trajectory
    const vel = camForward.clone().multiplyScalar(15.5);
    vel.y = Math.max(5.8, vel.y + 5.6);

    this.grenades.push({
      id: this.nextGrenadeId++,
      mesh,
      pos: startPos,
      vel,
      fuseTimer: 3.0,
    });

    this.pickupToast = 'বজ্র গোলা নিক্ষেপ!';
    this.pickupToastTimer = 1.4;
    this.emitHud();
  }

  public openNearestChest(): void {
    if (this.phase !== 'playing' || this.busMode !== 'none' || this.heroJumpingFromBus) return;
    const chest = this.nearestChest;
    if (!chest || chest.opened) return;
    if (chest.pos.distanceTo(this.heroPos) > 3.6) return;

    chest.opened = true;
    this.nearChest = false;
    this.nearestChest = null;
    this.audio.unlock();
    this.audio.playChestOpen();

    // Golden treasure spark burst
    this.spawnParticles(_v1.set(chest.pos.x, 0.75, chest.pos.z), 0xffd24a, 16, 5.2);

    // Rich Battle Royale loot bundle: Ammo + Raksha Kabach + Sanjibani + Bajra Gola + Weapon Supply
    const rewards: string[] = [];

    // 1. Raksha Kabach (50-pt blue Shield Bar)
    if (this.armor < this.maxArmor) {
      this.armor = this.maxArmor;
      this.hero.armorVestOverlay.visible = true;
      rewards.push('রক্ষা কবচ +৫০');
    }

    // 2. Sanjibani Healing Plant (up to 5)
    if (this.sanjibaniCount < this.maxSanjibani) {
      this.sanjibaniCount = Math.min(this.maxSanjibani, this.sanjibaniCount + 1);
      this.sanjibaniCollected++;
      rewards.push('সঞ্জীবনী +১');
    }

    // 3. Bajra Gola Grenade (up to 3)
    if (this.grenadeCount < this.maxGrenades) {
      this.grenadeCount = Math.min(this.maxGrenades, this.grenadeCount + 1);
      rewards.push('বজ্র গোলা +১');
    }

    // 4. Weapon & Ammo top-up (random spotlight weapon + active firearm refill)
    const featuredList: WeaponType[] = ['agni47', 'kalbhairav', 'trishul'];
    const featured = featuredList[chest.id % featuredList.length];
    const featMeta = WEAPON_CATALOG[featured];
    const featSlot = this.weaponSlots[featured];
    const addAmt = featured === 'trishul' ? 6 : featured === 'kalbhairav' ? 8 : 24;
    featSlot.reserve = Math.min(featMeta.maxReserve, featSlot.reserve + addAmt);
    rewards.push(`${featMeta.shortName} গুলি +${toBengaliNumber(addAmt)}`);

    // Also top up active weapon reserve if different
    if (this.weaponType !== 'fala' && this.weaponType !== featured) {
      const aMeta = WEAPON_CATALOG[this.weaponType];
      const aSlot = this.weaponSlots[this.weaponType];
      aSlot.reserve = Math.min(aMeta.maxReserve, aSlot.reserve + aMeta.magSize);
    }

    this.score += 40;
    this.checkHighScore();
    this.pickupToast = `সিন্দুক: ${rewards.slice(0, 3).join(' · ')}`;
    this.pickupToastTimer = 2.6;
    this.emitHud();
  }

  public startGame(): void {
    this.audio.unlock();
    this.clearDynamicEntities();

    const comingFromLobby = this.phase === 'title';

    this.phase = 'playing';
    this.busMode = 'riding_intro';
    this.busAutoDriving = true;
    this.busRouteT = 0.03;
    this.busSpeed = 12;
    this.busSteerAngle = 0;
    this.busInteriorCam = true;
    this.busExitSlowing = false;
    this.busExitSlowTimer = 0;
    this.busDoorOpenAmount = 0;
    this.busDoorAutoHoldTimer = 0;
    this.busInteriorLookYaw = 0;
    this.bus.interior.setDoorOpenAmount(0);
    this.bus.interior.introDriverGroup.visible = true;
    this.nearBus = false;
    this.nearChest = false;
    this.nearestChest = null;
    this.heroJumpingFromBus = false;
    this.heroJumpProgress = 0;

    this.camYaw = Math.PI * 0.5;
    this.camPitch = 0.24;
    this.scopeActive = false;
    this.pinchFovOffset = 0;
    this.activeTouchPointers.clear();
    this.lastPinchDist = null;
    this.currentFov = 68;
    this.camera.fov = 68;
    this.camera.updateProjectionMatrix();
    this.meleeSlashTimer = 0;

    this.health = this.maxHealth;
    this.armor = 0;
    this.hero.armorVestOverlay.visible = false;
    this.sanjibaniCount = 1;
    this.sanjibaniCollected = 0;
    this.isHealing = false;
    this.healTimer = 0;
    this.grenadeCount = 1;
    this.headshots = 0;
    this.bodyshots = 0;
    this.hitMarkerHeadshot = false;

    // Reset all 4 weapon slots cleanly from WEAPON_CATALOG
    for (const wId of WEAPON_SLOT_ORDER) {
      const m = WEAPON_CATALOG[wId];
      this.weaponSlots[wId] = {
        ammo: m.magSize,
        maxAmmo: m.magSize,
        reserve: m.startReserve,
      };
    }
    this.setWeaponType(this.weaponType);

    this.isReloading = false;
    this.reloadTimer = 0;
    this.fireCooldown = 0;
    this.sprintStamina = 1;
    this.score = 0;
    this.kills = 0;
    this.wave = 1;
    this.damageFlash = 0;
    this.damageAngle = null;
    this.hasDamageSource = false;
    this.hitMarker = 0;
    this.camShake = 0;
    this.camRecoilPitch = 0;
    this.camRecoilYaw = 0;
    this.camSprintBlend = 0;
    this.reticleSpread = 0;
    this.pickupToast = null;
    this.lobbyDragActive = false;
    this.lobbyDragPointerId = null;

    // Reset Kalboishakhi Shrinking Safe Zone (full-map 400u start, 4 stages every 90 seconds)
    this.stormCenter.set((Math.random() - 0.5) * 8, 4 + (Math.random() - 0.5) * 8);
    this.stormPhase = 1;
    this.stormRadius = this.initialStormRadius;
    this.stormStartRadius = this.initialStormRadius;
    this.stormTargetRadius = this.initialStormRadius;
    this.stormCountdown = this.stormPhaseInterval;
    this.stormShrinking = false;
    this.stormShrinkElapsed = 0;
    this.outsideStorm = false;
    this.outsideStormElapsed = 0;
    this.stormDrainTimer = 0;
    this.stormTeleportFlash = 0;
    this.stormRig.root.visible = true;
    this.stormRig.root.position.set(this.stormCenter.x, 0, this.stormCenter.y);
    this.stormRig.wallMesh.scale.set(this.stormRadius, 1, this.stormRadius);
    this.stormRig.groundRing.scale.set(this.stormRadius, this.stormRadius, 1);

    this.hero.bodyGroup.scale.set(1, 1, 1);
    this.hero.bodyGroup.position.set(0, 0, 0);
    this.hero.bodyGroup.rotation.set(0, 0, 0);
    this.hero.upperBodyGroup.position.set(0, 0.94, 0);
    this.hero.upperBodyGroup.rotation.set(0, 0, 0);
    this.hero.headGroup.rotation.set(0, 0, 0);
    this.hero.hairTuft.rotation.set(0, 0, 0);
    this.hero.kurtaHem.rotation.set(0, 0, 0);
    this.hero.leftLeg.rotation.set(0, 0, 0);
    this.hero.rightLeg.rotation.set(0, 0, 0);
    this.hero.leftArm.position.set(0, 0, 0);
    this.hero.rightArm.position.set(0, 0, 0);
    this.hero.recoilGroup.position.set(0.115, 0.31, 0.27);
    this.hero.recoilGroup.rotation.set(0, 0, 0);
    this.heroWalkWeight = 0;
    this.heroSprintWeight = 0;
    this.heroAimWeight = 0;
    this.heroAimPitch = 0;
    this.heroTurnLean = 0;
    this.heroStrafeBlend = 0;
    this.heroForwardBlend = 0;
    this.heroVelX = 0;
    this.heroVelZ = 0;
    this.heroSpeedMult = 1.0;
    this.heroFireHoldTimer = 0;
    this.heroLandingCrouch = 0;

    // Spawn Warrior Loot Chests ('যোদ্ধা সিন্দুক') near village mud houses & along the riverbank
    this.spawnInitialWorldLoot();

    // Position the WBTC bus at the west end of the Howrah-style bridge
    this.positionBusOnIntroRoute(this.busRouteT);

    // Seat hero inside the hollow WBTC bus cabin facing forward down the aisle
    this.bus.root.updateMatrixWorld(true);
    this.bus.heroIntroSeat.getWorldPosition(this.heroPos);
    this.hero.root.position.copy(this.heroPos);
    this.heroYaw = this.busYaw;
    this.hero.root.rotation.set(0, this.heroYaw, 0);
    this.hero.leftLeg.rotation.x = -1.16;
    this.hero.rightLeg.rotation.x = -1.16;
    this.hero.leftKnee.rotation.x = 1.16;
    this.hero.rightKnee.rotation.x = 1.16;
    this.hero.leftAnkle.rotation.x = 0.08;
    this.hero.rightAnkle.rotation.x = 0.08;

    // Load Wave 1 AI enemies onto the WBTC bus so they ride across the bridge & exit cleanly along the village road
    this.waveEnemiesToSpawn = [];
    const dropTs = [0.64, 0.70, 0.76, 0.82, 0.88, 0.94];
    const introTypes: EnemyArchetype[] = ['scout', 'scout', 'rusher', 'scout', 'rusher', 'scout'];
    for (let i = 0; i < introTypes.length; i++) {
      this.spawnEnemyOnBus(introTypes[i], i, dropTs[i]);
    }

    this.waveBanner = 'WBTC বাস — হাওড়া সেতু পারাপার';
    this.waveBannerTimer = 3.0;
    this.audio.playBusHorn();

    if (comingFromLobby) {
      // Smoothly sweep camera from the lobby hero right onto the moving WBTC bus!
      this.introStartCamPos.copy(this.camera.position);
      this.introStartLookAt.set(0.15, 1.25, -4.0);
      this.introTransitionProgress = 0;
    } else {
      this.introTransitionProgress = 1;
    }

    this.emitHud();
  }

  public toggleBusCameraView(): void {
    if (this.phase !== 'playing' || this.busMode !== 'riding_intro') return;
    this.busInteriorCam = !this.busInteriorCam;
    this.busInteriorLookYaw = 0;
    this.emitHud();
  }

  public exitBus(): void {
    if (this.phase !== 'playing') return;
    if (this.busMode === 'none') return;

    this.audio.unlock();
    this.bus.root.updateMatrixWorld(true);

    if (this.busMode === 'riding_intro') {
      // Realistic direct ground exit: briefly slow the WBTC bus, hiss air-brakes, swing side door open,
      // then hop straight onto the Howrah Bridge or road surface (no parachute!)
      if (this.busExitSlowing) return;
      this.busExitSlowing = true;
      this.busExitSlowTimer = this.busExitSlowDuration;
      this.audio.playBusDoorBrake();
      this.pickupToast = 'বাস থামছে... দরজা খুলছে';
      this.pickupToastTimer = 1.1;
      this.emitHud();
      return;
    }

    if (this.busMode === 'driving') {
      // Quick grounded hop-out beside the bus onto guaranteed clear road/bridge surface
      this.audio.playBusDoorBrake();
      this.audio.playBusJump();
      this.busDoorAutoHoldTimer = 1.1;
      this.bus.interior.heroDoorwayAnchor.getWorldPosition(this.heroJumpStart);
      this.findSafeBusExitPosition(this.heroJumpEnd, 0.62, 1, 0, false);

      this.heroJumpPeakY = Math.max(this.heroJumpStart.y, this.heroJumpEnd.y) + 0.36;
      this.heroJumpDuration = 0.24;
      this.heroJumpProgress = 0;
      this.heroJumpingFromBus = true;

      this.heroYaw = this.busYaw - Math.PI * 0.5;
      this.hero.root.rotation.set(0, this.heroYaw, 0);
      this.camYaw = this.busYaw;
      this.busMode = 'none';
      this.pickupToast = 'বাস থেকে নেমেছেন';
      this.pickupToastTimer = 1.6;
      this.emitHud();
    }
  }

  private executeDirectGroundExit(): void {
    if (this.busMode !== 'riding_intro') return;

    this.busExitSlowing = false;
    this.busExitSlowTimer = 0;
    this.busDoorAutoHoldTimer = 1.25;
    this.audio.playBusJump();
    this.bus.root.updateMatrixWorld(true);

    // Launch hero directly from the open side passenger doorway onto the bridge deck or village road (zero parachute!)
    this.bus.interior.heroDoorwayAnchor.getWorldPosition(this.heroJumpStart);
    this.findSafeBusExitPosition(this.heroJumpEnd, 0.62, 1, 0, true);

    const dropDiff = Math.abs(this.heroJumpStart.y - this.heroJumpEnd.y);
    this.heroJumpPeakY = Math.max(this.heroJumpStart.y, this.heroJumpEnd.y) + 0.42;
    this.heroJumpDuration = dropDiff > 1.8 ? 0.38 : 0.25;
    this.heroJumpProgress = 0;
    this.heroJumpingFromBus = true;

    this.heroYaw = this.busYaw;
    this.hero.root.rotation.set(0, this.heroYaw, 0);
    this.busMode = 'none';
    this.camYaw = this.busYaw;
    this.camPitch = 0.2;
    this.pickupToast = 'বাস থেকে নেমেছেন — লড়াই শুরু!';
    this.pickupToastTimer = 2.0;
    this.emitHud();
  }

  public enterBus(): void {
    if (this.phase !== 'playing' || this.busMode !== 'none' || this.heroJumpingFromBus) return;
    if (this.busAutoDriving) return;
    const dist = this.heroPos.distanceTo(this.busPos);
    if (dist > 6.2) return;

    this.audio.unlock();
    this.audio.playBusHorn();
    this.busMode = 'driving';
    this.busDoorAutoHoldTimer = 0.65;
    this.bus.interior.introDriverGroup.visible = false;
    this.nearBus = false;
    this.nearChest = false;
    this.isReloading = false;
    this.isHealing = false;
    this.scopeActive = false;
    this.mouseShootHeld = false;
    this.virtualInput.shooting = false;
    this.pickupToast = 'WBTC বাস চালাচ্ছেন!';
    this.pickupToastTimer = 2.0;
    this.emitHud();
  }

  public honkBusHorn(): void {
    if (this.phase !== 'playing' || this.busMode === 'none') return;
    this.audio.unlock();
    this.audio.playBusHorn();
  }

  public setPaused(paused: boolean): void {
    if (paused && this.phase === 'playing') {
      this.phase = 'paused';
      this.keysHeld.clear();
      this.mouseShootHeld = false;
      this.virtualInput.shooting = false;
      this.safeExitPointerLock();
      this.emitHud();
    } else if (!paused && this.phase === 'paused') {
      this.phase = 'playing';
      this.lastFrameMs = performance.now();
      this.emitHud();
    }
  }

  public togglePause(): void {
    if (this.phase === 'playing') {
      this.setPaused(true);
    } else if (this.phase === 'paused') {
      this.setPaused(false);
    }
  }

  public setSensitivity(general: number, scope: number): void {
    this.generalSensitivity = THREE.MathUtils.clamp(general, 0, 100);
    this.scopeSensitivity = THREE.MathUtils.clamp(scope, 0, 100);
  }

  private getGeneralLookFactor(): number {
    return 0.15 + (this.generalSensitivity / 100) * 1.85;
  }

  private getScopeLookFactor(): number {
    return 0.08 + (this.scopeSensitivity / 100) * 0.92;
  }

  private getPixelRatioCap(): number {
    if (this.isSoftwareGl) return 1;
    const dpr = window.devicePixelRatio || 1;
    if (this.graphicsQuality === 'low') return Math.min(dpr, 1.0);
    if (this.graphicsQuality === 'medium') return Math.min(dpr, 1.25);
    return Math.min(dpr, 1.5);
  }

  private applyShadowMapSize(size: number, radius: number): void {
    if (
      this.sunLight.shadow.mapSize.x !== size ||
      this.sunLight.shadow.mapSize.y !== size
    ) {
      if (this.sunLight.shadow.map) {
        this.sunLight.shadow.map.dispose();
        this.sunLight.shadow.map = null;
      }
      this.sunLight.shadow.mapSize.set(size, size);
    }
    this.sunLight.shadow.radius = radius;
    this.sunLight.shadow.needsUpdate = true;
    this.renderer.shadowMap.needsUpdate = true;
  }

  public setGraphicsQuality(quality: GraphicsQuality): void {
    this.graphicsQuality = quality;
    this.renderer.setPixelRatio(this.getPixelRatioCap());

    if (quality === 'low' || this.isSoftwareGl) {
      this.renderer.shadowMap.enabled = false;
      this.sunLight.castShadow = false;
      this.renderer.shadowMap.needsUpdate = true;
    } else if (quality === 'medium') {
      this.renderer.shadowMap.enabled = true;
      this.sunLight.castShadow = true;
      this.applyShadowMapSize(1024, 2);
    } else {
      this.renderer.shadowMap.enabled = true;
      this.sunLight.castShadow = true;
      this.applyShadowMapSize(2048, 2.5);
    }

    const w = this.container.clientWidth || window.innerWidth;
    const h = Math.max(1, this.container.clientHeight || window.innerHeight);
    this.renderer.setSize(w, h, false);
  }

  public setAudioSettings(enabled: boolean, volumePercent: number): void {
    const vol = THREE.MathUtils.clamp(volumePercent / 100, 0, 1);
    this.audio.setSfxVolume(vol);
    this.audio.setMuted(!enabled);
    this.emitHud();
  }

  private safeExitPointerLock(): void {
    try {
      if (document.pointerLockElement === this.renderer.domElement) {
        document.exitPointerLock();
      }
    } catch {
      // Ignore iframe/browser pointer-lock exit rejections
    }
  }

  private updateHeroBlink(dt: number): void {
    if (this.heroBlinkPhase > 0) {
      this.heroBlinkPhase += dt / 0.16;
      if (this.heroBlinkPhase >= 1) {
        this.heroBlinkPhase = 0;
        this.hero.setBlink(0);
      } else {
        this.hero.setBlink(Math.pow(Math.sin(this.heroBlinkPhase * Math.PI), 0.85));
      }
    } else {
      this.heroBlinkTimer -= dt;
      if (this.heroBlinkTimer <= 0) {
        this.heroBlinkPhase = 0.001;
        this.heroBlinkTimer = 2.6 + Math.random() * 3.1;
      }
    }
  }

  public returnToTitle(): void {
    this.clearDynamicEntities();
    this.phase = 'title';
    this.busMode = 'none';
    this.busAutoDriving = false;
    this.busInteriorCam = true;
    this.busExitSlowing = false;
    this.busExitSlowTimer = 0;
    this.busDoorOpenAmount = 0;
    this.busDoorAutoHoldTimer = 0;
    this.busInteriorLookYaw = 0;
    this.bus.interior.setDoorOpenAmount(0);
    this.bus.interior.introDriverGroup.visible = true;
    this.heroJumpingFromBus = false;
    this.nearBus = false;
    this.nearChest = false;
    this.nearestChest = null;
    this.scopeActive = false;
    this.isHealing = false;
    this.armor = 0;
    this.hero.armorVestOverlay.visible = false;
    this.stormRig.root.visible = false;
    this.outsideStorm = false;
    this.outsideStormElapsed = 0;
    this.stormDrainTimer = 0;
    this.stormTeleportFlash = 0;
    this.currentFov = 68;
    this.camera.fov = 68;
    this.camera.updateProjectionMatrix();
    this.heroPos.set(0, 0, 7.2);
    this.lobbyHeroYaw = 0.28;
    this.lobbyHeroTargetYaw = 0.28;
    this.heroYaw = 0.28;
    this.hero.root.position.copy(this.heroPos);
    this.hero.root.rotation.set(0, this.lobbyHeroYaw, 0);
    this.hero.bodyGroup.position.set(0, 0, 0);
    this.hero.bodyGroup.rotation.set(0, 0, 0);
    this.hero.upperBodyGroup.position.set(0, 0.94, 0);
    this.hero.upperBodyGroup.rotation.set(0, 0, 0);
    this.hero.leftLeg.rotation.set(0, 0, 0);
    this.hero.rightLeg.rotation.set(0, 0, 0);
    this.hero.leftKnee.rotation.set(0, 0, 0);
    this.hero.rightKnee.rotation.set(0, 0, 0);
    this.hero.leftAnkle.rotation.set(0, 0, 0);
    this.hero.rightAnkle.rotation.set(0, 0, 0);
    this.hero.headGroup.rotation.set(0, 0, 0);
    this.hero.hairTuft.rotation.set(0, 0, 0);
    this.hero.kurtaHem.rotation.set(0, 0, 0);
    this.hero.leftArm.position.set(0, 0, 0);
    this.hero.rightArm.position.set(0, 0, 0);
    this.hero.recoilGroup.position.set(0.115, 0.31, 0.27);
    this.hero.recoilGroup.rotation.set(0, 0, 0);
    this.hero.setBlink(0);
    this.heroWalkWeight = 0;
    this.heroSprintWeight = 0;
    this.heroAimWeight = 0;
    this.heroAimPitch = 0;
    this.heroTurnLean = 0;
    this.heroStrafeBlend = 0;
    this.heroForwardBlend = 0;
    this.heroVelX = 0;
    this.heroVelZ = 0;
    this.heroSpeedMult = 1.0;
    this.heroFireHoldTimer = 0;
    this.heroLandingCrouch = 0;
    this.camRecoilPitch = 0;
    this.camRecoilYaw = 0;
    this.camSprintBlend = 0;
    this.reticleSpread = 0;
    this.damageAngle = null;
    this.hasDamageSource = false;
    this.prevHeroPos.copy(this.heroPos);
    this.prevHeroYaw = this.lobbyHeroYaw;
    this.introTransitionProgress = 1;
    this.safeExitPointerLock();
    this.emitHud();
  }

  public toggleMute(): void {
    this.audio.unlock();
    this.audio.toggleMute();
    this.emitHud();
  }

  public setVirtualMove(x: number, y: number): void {
    this.virtualInput.moveX = THREE.MathUtils.clamp(x, -1, 1);
    this.virtualInput.moveY = THREE.MathUtils.clamp(y, -1, 1);
  }

  public setVirtualShoot(active: boolean): void {
    if (active) this.audio.unlock();
    this.virtualInput.shooting = active;
  }

  public setVirtualSprint(active: boolean): void {
    this.virtualInput.sprinting = active;
  }

  public triggerReload(): void {
    this.audio.unlock();
    this.virtualInput.reloadJustPressed = true;
  }

  // --- Wave & Entity Management ---

  private clearDynamicEntities(): void {
    for (const e of this.enemies) {
      this.scene.remove(e.rig.root);
    }
    this.enemies = [];
    for (const p of this.pickups) {
      this.scene.remove(p.mesh);
    }
    this.pickups = [];
    for (const c of this.chests) {
      this.scene.remove(c.rig.root);
    }
    this.chests = [];
    this.nearChest = false;
    this.nearestChest = null;
    for (const g of this.grenades) {
      this.scene.remove(g.mesh);
    }
    this.grenades = [];
    for (const fd of this.floatingDamages) {
      this.scene.remove(fd.sprite);
      fd.texture.dispose();
      fd.material.dispose();
    }
    this.floatingDamages = [];
    for (const sw of this.shockwaves) {
      this.scene.remove(sw.mesh);
      sw.mesh.geometry.dispose();
      (sw.mesh.material as THREE.Material).dispose();
    }
    this.shockwaves = [];
    for (const b of this.bullets) {
      b.active = false;
      b.mesh.visible = false;
    }
    for (const pt of this.particles) {
      pt.active = false;
      pt.mesh.visible = false;
    }
    for (const fl of this.impactFlashes) {
      fl.active = false;
      fl.mesh.visible = false;
    }
  }

  private spawnInitialWorldLoot(): void {
    // 1. Warrior Loot Chests ('যোদ্ধা সিন্দুক') beside village mud house verandas & along Hooghly riverbank
    const chestSpots: Array<[number, number, number]> = [
      // Village house porch / veranda spots (outside house circle collider so player walks right up)
      [-12.2, -1.6, 0.35],
      [-13.4, 15.8, 1.25],
      [13.0, 14.5, -1.35],
      [-6.8, 21.8, 0.15],
      [10.2, 21.2, -0.25],
      // Hooghly Riverbank ghat chests
      [-7.8, -14.2, 0.0],
      [8.6, -14.0, 0.0],
    ];
    for (const [cx, cz, rotY] of chestSpots) {
      this.spawnWarriorChest(cx, cz, rotY);
    }

    // Landmark Warrior Loot Chests (Sal Forest, Zamindar Bari downstairs & 2nd-floor terrace, Tram Depot, Extended Ghat)
    for (const anchor of this.world.landmarkChestAnchors) {
      this.spawnWarriorChest(anchor.x, anchor.z, anchor.rotY, anchor.y);
    }

    // 2. Glowing emerald Sanjibani medicinal herb plants ('সঞ্জীবনী গাছ') across grassy village terrain
    const plantSpots: Array<[number, number]> = [
      [-10.5, -10.0],
      [11.8, -9.8],
      [-9.5, 9.8],
      [10.2, 8.8],
      [-1.8, 18.2],
      [-22.5, 4.5],
      [22.5, 4.2],
      [3.5, -12.5],
    ];
    for (const [px, pz] of plantSpots) {
      this.spawnPickup(px, pz, 'sanjibani', true);
    }

    // Extra Sanjibani medicinal herbs across Sal Forest hills, Zamindar Bari garden, Tram Depot & Riverbank Ghat
    for (const herb of this.world.landmarkSanjibaniAnchors) {
      this.spawnPickup(herb.x, herb.z, 'sanjibani', true);
    }

    // 3. Initial Raksha Kabach armor pickups near Village Taxi, Zamindar Bari courtyard & Tram Depot
    this.spawnPickup(3.2, -6.5, 'armor', true);
    this.spawnPickup(98.0, 25.5, 'armor', true);
    this.spawnPickup(0.0, -110.0, 'armor', true);
  }

  private spawnWarriorChest(x: number, z: number, rotY = 0, forcedY?: number): void {
    const pos = new THREE.Vector3(x, forcedY ?? 0, z);
    if (forcedY === undefined) {
      this.resolveCircleWorldCollision(pos, 0.72, false);
      pos.y = this.world.getGroundHeight(pos.x, pos.z);
    } else {
      pos.y = forcedY;
    }

    const rig = buildWarriorChest();
    rig.root.position.copy(pos);
    rig.root.rotation.y = rotY;
    this.scene.add(rig.root);

    this.chests.push({
      id: this.nextChestId++,
      rig,
      pos,
      opened: false,
      openProgress: 0,
      life: 600,
    });
  }

  private spawnFloatingDamage(worldPos: THREE.Vector3, amount: number, isHeadshot: boolean): void {
    const label = `-${toBengaliNumber(amount)}`;
    const { sprite, texture, material } = createFloatingDamageSprite(label, isHeadshot);
    const pos = worldPos.clone();
    pos.x += (Math.random() - 0.5) * 0.32;
    pos.y += isHeadshot ? 0.35 : 0.2;
    pos.z += (Math.random() - 0.5) * 0.32;
    sprite.position.copy(pos);
    this.scene.add(sprite);

    this.floatingDamages.push({
      sprite,
      texture,
      material,
      pos,
      velY: isHeadshot ? 1.85 : 1.35,
      life: isHeadshot ? 1.05 : 0.85,
      maxLife: isHeadshot ? 1.05 : 0.85,
      baseScaleX: sprite.scale.x,
      baseScaleY: sprite.scale.y,
    });
  }

  private beginWave(waveNum: number): void {
    this.wave = waveNum;
    const totalCount = 4 + waveNum * 2;
    const queue: EnemyArchetype[] = [];

    for (let i = 0; i < totalCount; i++) {
      const r = Math.random();
      if (waveNum >= 3 && r < 0.25) {
        queue.push('heavy');
      } else if (waveNum >= 2 && r < 0.52) {
        queue.push('rusher');
      } else {
        queue.push('scout');
      }
    }

    this.waveEnemiesToSpawn = queue;
    this.waveSpawnTimer = 0.6;
    this.waveBanner = `তরঙ্গ ${toBengaliNumber(waveNum)}`;
    this.waveBannerTimer = 2.6;
    this.audio.playWaveStart();

    // Refresh helpful Battle Royale loot near the village square at start of waves >= 2
    if (waveNum >= 2) {
      const anchor = this.world.pickupAnchors[waveNum % this.world.pickupAnchors.length];
      this.spawnWarriorChest(anchor.x, anchor.z, Math.random() * Math.PI * 2);
      const plantAnchor = this.world.pickupAnchors[(waveNum + 2) % this.world.pickupAnchors.length];
      this.spawnPickup(plantAnchor.x, plantAnchor.z, 'sanjibani');
    }
  }

  private spawnEnemy(archetype: EnemyArchetype): void {
    // Pick spawn point furthest from hero for fair telegraphing
    let bestPt = this.world.enemySpawnPoints[0];
    let bestDistSq = -1;
    const tries = 4;
    for (let t = 0; t < tries; t++) {
      const pt =
        this.world.enemySpawnPoints[
          Math.floor(Math.random() * this.world.enemySpawnPoints.length)
        ];
      const dSq = pt.distanceToSquared(this.heroPos);
      if (dSq > bestDistSq) {
        bestDistSq = dSq;
        bestPt = pt;
      }
    }

    const rig = buildEnemyBot(archetype, this.textures);
    const sx = bestPt.x + (Math.random() - 0.5) * 2.5;
    const sz = bestPt.z + (Math.random() - 0.5) * 2.5;
    const sy = this.world.getGroundHeight(sx, sz);
    rig.root.position.set(sx, sy, sz);
    this.scene.add(rig.root);

    const waveHpScale = 1 + (this.wave - 1) * 0.12;
    const maxHp =
      archetype === 'heavy'
        ? Math.round(140 * waveHpScale)
        : archetype === 'rusher'
          ? Math.round(60 * waveHpScale)
          : Math.round(82 * waveHpScale);

    const speed =
      archetype === 'heavy'
        ? 3.1
        : archetype === 'rusher'
          ? 6.1
          : 4.35;

    this.enemies.push({
      id: this.nextEnemyId++,
      archetype,
      rig,
      hp: maxHp,
      maxHp,
      speed,
      radius: archetype === 'heavy' ? 0.72 : 0.55,
      fireRange: archetype === 'rusher' ? 14 : 26,
      fireCooldown: 1.0 + Math.random() * 1.0,
      telegraphTimer: 0,
      strafeDir: Math.random() > 0.5 ? 1 : -1,
      strafeTimer: 1.4 + Math.random() * 1.8,
      walkPhase: Math.random() * Math.PI * 2,
      hitFlashTimer: 0,
      dying: false,
      deathTimer: 0,
      knockback: new THREE.Vector3(),
      busSeatIndex: -1,
      busDropT: -1,
      jumpingFromBus: false,
      jumpProgress: 1,
      jumpDuration: 0.45,
      jumpStart: new THREE.Vector3(),
      jumpEnd: new THREE.Vector3(),
      jumpPeakY: 1.8,
      postLandingSafeTimer: 0.6,
      prevYaw: rig.root.rotation.y,
      yawRate: 0,
      recoil: 0,
      blinkTimer: 1.5 + Math.random() * 3.5,
      blinkPhase: 0,
      moveBlend: 0,
      landingCrouch: 0,
      deathSide: Math.random() > 0.5 ? 1 : -1,
      velX: 0,
      velZ: 0,
      tacticState: archetype === 'rusher' ? 'flank' : 'advance',
      tacticTimer: 1.4 + Math.random() * 1.6,
      coverX: sx,
      coverZ: sz,
      hasCoverSpot: false,
      coverPeekTimer: 1.2 + Math.random() * 1.0,
      coverPeeking: true,
      coverCrouch: 0,
      aimBlend: 0,
      flinchTimer: 0,
      flinchHead: false,
      flinchSide: 1,
      burstRemaining: 0,
      burstDelay: 0,
    });
  }

  private spawnEnemyOnBus(archetype: EnemyArchetype, seatIndex: number, dropT: number): void {
    const rig = buildEnemyBot(archetype, this.textures);
    this.scene.add(rig.root);

    const maxHp = archetype === 'rusher' ? 60 : 82;
    const speed = archetype === 'rusher' ? 5.9 : 4.25;

    this.enemies.push({
      id: this.nextEnemyId++,
      archetype,
      rig,
      hp: maxHp,
      maxHp,
      speed,
      radius: 0.55,
      fireRange: archetype === 'rusher' ? 14 : 26,
      fireCooldown: 1.1 + Math.random() * 0.8,
      telegraphTimer: 0,
      strafeDir: Math.random() > 0.5 ? 1 : -1,
      strafeTimer: 1.4 + Math.random() * 1.6,
      walkPhase: Math.random() * Math.PI * 2,
      hitFlashTimer: 0,
      dying: false,
      deathTimer: 0,
      knockback: new THREE.Vector3(),
      busSeatIndex: seatIndex % this.bus.enemySeats.length,
      busDropT: dropT,
      jumpingFromBus: false,
      jumpProgress: 0,
      jumpDuration: 0.52,
      jumpStart: new THREE.Vector3(),
      jumpEnd: new THREE.Vector3(),
      jumpPeakY: 2.0,
      postLandingSafeTimer: 2.0,
      prevYaw: 0,
      yawRate: 0,
      recoil: 0,
      blinkTimer: 1.2 + Math.random() * 3.6,
      blinkPhase: 0,
      moveBlend: 0,
      landingCrouch: 0,
      deathSide: Math.random() > 0.5 ? 1 : -1,
      velX: 0,
      velZ: 0,
      tacticState: archetype === 'rusher' ? 'flank' : 'advance',
      tacticTimer: 1.5 + Math.random() * 1.5,
      coverX: 0,
      coverZ: 0,
      hasCoverSpot: false,
      coverPeekTimer: 1.2 + Math.random() * 1.0,
      coverPeeking: true,
      coverCrouch: 0,
      aimBlend: 0,
      flinchTimer: 0,
      flinchHead: false,
      flinchSide: 1,
      burstRemaining: 0,
      burstDelay: 0,
    });
  }

  private positionBusOnIntroRoute(t: number): void {
    const clampedT = THREE.MathUtils.clamp(t, 0, 1);
    this.busRoute.curve.getPointAt(clampedT, this.busPos);
    const lookT = Math.min(1, clampedT + 0.012);
    this.busRoute.curve.getPointAt(lookT, _v1);

    if (clampedT >= 0.995) {
      // Keep final west-facing heading at village bus stop
      _v1.set(this.busPos.x - 1, this.busPos.y, this.busPos.z);
    }

    this.bus.root.position.copy(this.busPos);
    this.bus.root.lookAt(_v1);
    this.busYaw = Math.atan2(_v1.x - this.busPos.x, _v1.z - this.busPos.z);

    if (clampedT < 0.35) {
      this.busZoneLabel = 'হাওড়া সেতু';
    } else if (clampedT < 0.62) {
      this.busZoneLabel = 'হুগলি ঘাট র‍্যাম্প';
    } else if (clampedT < 0.82) {
      this.busZoneLabel = 'হলুদ ট্যাক্সি চক';
    } else {
      this.busZoneLabel = 'মাটির গ্রাম সড়ক';
    }
  }

  private spawnPickup(x: number, z: number, kind: PickupKind, persistent = false): void {
    const mesh = buildPickupMesh(kind);
    const py = this.world.getGroundHeight(x, z);
    mesh.position.set(x, py, z);
    this.scene.add(mesh);
    this.pickups.push({
      id: this.nextPickupId++,
      kind,
      mesh,
      pos: new THREE.Vector3(x, py, z),
      life: persistent ? 600 : 32,
    });
  }

  private spawnParticles(pos: THREE.Vector3, colorHex: number, count: number, speed = 5.5): void {
    let spawned = 0;
    for (const p of this.particles) {
      if (p.active) continue;
      p.active = true;
      p.pos.copy(pos);
      p.vel.set(
        (Math.random() - 0.5) * speed * 2,
        1.5 + Math.random() * speed,
        (Math.random() - 0.5) * speed * 2,
      );
      p.maxLife = 0.24 + Math.random() * 0.26;
      p.life = p.maxLife;
      p.scale = 0.7 + Math.random() * 0.9;
      (p.mesh.material as THREE.MeshBasicMaterial).color.setHex(colorHex);
      p.mesh.position.copy(p.pos);
      p.mesh.scale.setScalar(p.scale);
      p.mesh.visible = true;
      spawned++;
      if (spawned >= count) break;
    }
  }

  private spawnImpactFlash(
    pos: THREE.Vector3,
    colorHex: number,
    maxScale = 1.6,
    duration = 0.16,
  ): void {
    for (let i = 0; i < this.impactFlashes.length; i++) {
      const fl = this.impactFlashes[i];
      if (fl.active) continue;
      fl.active = true;
      fl.maxLife = duration;
      fl.life = duration;
      fl.maxScale = maxScale;
      fl.material.color.setHex(colorHex);
      fl.material.opacity = 0.95;
      fl.mesh.position.copy(pos);
      fl.mesh.scale.setScalar(0.35);
      fl.mesh.lookAt(this.camera.position);
      fl.mesh.visible = true;
      return;
    }
  }

  private spawnBullet(
    fromPlayer: boolean,
    origin: THREE.Vector3,
    direction: THREE.Vector3,
    speed: number,
    damage: number,
    sourceX = origin.x,
    sourceZ = origin.z,
  ): void {
    for (const b of this.bullets) {
      if (b.active || b.fromPlayer !== fromPlayer) continue;
      b.active = true;
      b.pos.copy(origin);
      b.vel.copy(direction).normalize().multiplyScalar(speed);
      b.life = 1.65;
      b.damage = damage;
      b.sourceX = sourceX;
      b.sourceZ = sourceZ;
      b.mesh.position.copy(origin);
      _v1.copy(origin).add(b.vel);
      b.mesh.lookAt(_v1);
      b.mesh.visible = true;
      return;
    }
  }

  // --- Combat & Firing ---

  private getEnemyScale(e: ActiveEnemy): number {
    return e.archetype === 'heavy' ? 1.2 : e.archetype === 'rusher' ? 1.0 : 1.06;
  }

  private attemptStartReload(): void {
    const meta = WEAPON_CATALOG[this.weaponType];
    if (meta.isMelee) return;
    const slot = this.weaponSlots[this.weaponType];
    if (this.isReloading || slot.ammo >= slot.maxAmmo || slot.reserve <= 0) return;
    this.isReloading = true;
    this.reloadDuration = meta.reloadDuration;
    this.reloadTimer = this.reloadDuration;
    this.isHealing = false;
    this.scopeActive = false;
    this.audio.playReload();
  }

  private performMeleeSlash(): void {
    const meta = WEAPON_CATALOG.fala;
    this.fireCooldown = meta.fireCooldown;
    this.meleeSlashTimer = 0.24;
    this.heroRecoil = 0.6;
    this.isHealing = false;
    this.audio.playWeaponShot('fala');

    // Align hero forward with camera aim
    this.heroYaw = this.camYaw;
    this.hero.root.rotation.y = this.heroYaw;
    const fwdX = Math.sin(this.camYaw);
    const fwdZ = Math.cos(this.camYaw);
    const heroChest = _v5.set(this.heroPos.x, 1.32, this.heroPos.z);

    // Check grounded enemies within fast melee slash arc (3.3m reach, wide front cone)
    for (const e of this.enemies) {
      if (e.dying || e.busSeatIndex >= 0 || e.jumpingFromBus) continue;
      const dx = e.rig.root.position.x - this.heroPos.x;
      const dz = e.rig.root.position.z - this.heroPos.z;
      const dist = Math.hypot(dx, dz);
      if (dist > 3.35) continue;
      const dot = (dx * fwdX + dz * fwdZ) / Math.max(0.001, dist);
      if (dot < 0.28) continue;

      const s = this.getEnemyScale(e);
      const targetPt = _v3.set(e.rig.root.position.x, 1.35 * s, e.rig.root.position.z);
      if (!this.hasLineOfSight(heroChest, targetPt)) continue;

      // High-aim slash (camPitch < 0.14) lands a lethal critical headshot slash!
      const isHead = this.camPitch < 0.12;
      const hitPos = _v6.set(
        e.rig.root.position.x,
        isHead ? 1.78 * s : 1.25 * s,
        e.rig.root.position.z,
      );
      _v4.set(fwdX, 0, fwdZ);
      this.damageEnemy(e, meta.baseDamage, _v4, isHead, hitPos);
      this.camShake = Math.min(0.28, this.camShake + 0.08);
    }
  }

  private firePlayerWeapon(): void {
    if (this.isReloading || this.fireCooldown > 0) return;
    const meta = WEAPON_CATALOG[this.weaponType];

    // Slot 4 — বাংলার ফলা (fast silent melee slash)
    if (meta.isMelee) {
      this.performMeleeSlash();
      return;
    }

    const slot = this.weaponSlots[this.weaponType];
    if (slot.ammo <= 0) {
      this.fireCooldown = 0.28;
      this.audio.playDryFire();
      if (slot.reserve > 0) this.attemptStartReload();
      return;
    }

    // Firing cancels healing cleanly and holds braced combat stance briefly
    this.isHealing = false;
    this.heroFireHoldTimer = 0.45;

    slot.ammo--;
    this.fireCooldown = meta.fireCooldown;
    this.heroRecoil =
      this.weaponType === 'trishul' ? 1.85 : this.weaponType === 'kalbhairav' ? 1.65 : 1.05;
    this.muzzleFlashTimer = this.weaponType === 'agni47' ? 0.055 : 0.09;
    this.camShake = Math.min(
      0.38,
      this.camShake +
        (this.weaponType === 'trishul'
          ? 0.2
          : this.weaponType === 'kalbhairav'
            ? 0.18
            : 0.08),
    );

    // Tactile PUBG/Free Fire camera recoil kick (upward pitch + subtle horizontal micro-kick) & crosshair bloom
    const recoilScale = this.scopeActive ? 0.58 : 1.0;
    const pitchKick =
      this.weaponType === 'trishul' ? 0.052 : this.weaponType === 'kalbhairav' ? 0.044 : 0.017;
    const yawKick =
      (Math.random() - 0.5) *
      (this.weaponType === 'kalbhairav' ? 0.022 : this.weaponType === 'trishul' ? 0.014 : 0.011);
    this.camRecoilPitch = Math.min(0.11, this.camRecoilPitch + pitchKick * recoilScale);
    this.camRecoilYaw = THREE.MathUtils.clamp(
      this.camRecoilYaw + yawKick * recoilScale,
      -0.035,
      0.035,
    );
    this.reticleSpread = Math.min(
      1.0,
      this.reticleSpread +
        (this.weaponType === 'kalbhairav' ? 0.52 : this.weaponType === 'trishul' ? 0.4 : 0.22),
    );
    this.audio.playWeaponShot(this.weaponType);

    // Determine world aim direction from center camera ray
    const camForward = _v1.set(0, 0, -1).applyQuaternion(this.camera.quaternion).normalize();
    const maxAimDist = this.weaponType === 'trishul' ? 90 : 50;
    const aimTarget = _v2.copy(this.camera.position).addScaledVector(camForward, maxAimDist);
    const heroChest = _v5.set(this.heroPos.x, this.heroPos.y + 1.32, this.heroPos.z);

    // Respect solid obstacles along camera sightline first
    const obsT = this.segmentFirstObstacleT(this.camera.position, aimTarget, true);
    if (obsT < 1) {
      aimTarget.lerpVectors(this.camera.position, aimTarget, obsT);
    }

    // Precision aim-assist that preserves player's Head vs Body aim!
    // When scoped with Trishul Sniper, use tighter cone (0.992) so exact crosshair placement rules;
    // on hip-fire use forgiving cone (0.955) and choose Head if crosshair points closer to head than chest.
    const assistThreshold = this.scopeActive ? 0.992 : 0.955;
    let bestTargetPt: THREE.Vector3 | null = null;
    let bestDot = assistThreshold;

    for (const e of this.enemies) {
      if (e.dying || e.busSeatIndex >= 0 || e.jumpingFromBus) continue;
      const s = this.getEnemyScale(e);
      const ey = e.rig.root.position.y;

      // Evaluate both Head (1.74 * s) and Chest (1.16 * s) centers against camera sightline
      const headY = ey + 1.74 * s;
      const chestY = ey + 1.16 * s;

      for (const yAim of [headY, chestY]) {
        _v3.set(e.rig.root.position.x, yAim, e.rig.root.position.z);
        const toPt = _v4.subVectors(_v3, this.camera.position);
        const dist = toPt.length();
        if (dist > maxAimDist || dist < 1.0) continue;
        toPt.divideScalar(dist);
        const dot = toPt.dot(camForward);
        // Tiny preference for head when aimed cleanly at head height
        const scoreDot = yAim === headY ? dot + 0.0015 : dot;
        if (scoreDot > bestDot && this.hasLineOfSight(heroChest, _v3)) {
          bestDot = scoreDot;
          if (!bestTargetPt) bestTargetPt = new THREE.Vector3();
          bestTargetPt.copy(_v3);
        }
      }
    }

    if (bestTargetPt) {
      aimTarget.copy(bestTargetPt);
    }

    // Align hero facing cleanly with shot direction
    const dx = aimTarget.x - this.heroPos.x;
    const dz = aimTarget.z - this.heroPos.z;
    this.heroYaw = Math.atan2(dx, dz);
    this.hero.root.rotation.y = this.heroYaw;
    this.hero.root.updateMatrixWorld(true);

    // Fire from muzzle (or hero chest if hugging a wall so shots never spawn inside cover)
    const muzzleWorld = _v3;
    this.hero.muzzlePoint.getWorldPosition(muzzleWorld);
    if (this.segmentFirstObstacleT(heroChest, muzzleWorld, true) < 1) {
      muzzleWorld.copy(heroChest);
    }

    const effectiveSpread = this.scopeActive ? meta.spread * 0.25 : meta.spread;
    for (let p = 0; p < meta.pellets; p++) {
      const bulletDir = _v4.subVectors(aimTarget, muzzleWorld).normalize();
      if (effectiveSpread > 0) {
        bulletDir.x += (Math.random() - 0.5) * effectiveSpread;
        bulletDir.y += (Math.random() - 0.5) * effectiveSpread * 0.6;
        bulletDir.z += (Math.random() - 0.5) * effectiveSpread;
        bulletDir.normalize();
      }
      this.spawnBullet(true, muzzleWorld, bulletDir, meta.bulletSpeed, meta.baseDamage);
    }

    this.spawnParticles(
      muzzleWorld,
      this.weaponType === 'trishul' ? 0xfff0a8 : 0xffd166,
      this.weaponType === 'kalbhairav' ? 7 : 4,
      this.weaponType === 'kalbhairav' ? 3.8 : 2.8,
    );

    if (slot.ammo === 0 && slot.reserve > 0) {
      this.attemptStartReload();
    }
  }

  // --- Collision, Safe Bus Exit & Line-of-Sight Helpers ---

  private pushOutOfBusHull(pos: THREE.Vector3, actorRadius: number, forceCheck = false): void {
    if (!forceCheck && this.busPos.y >= 1.15) return;
    const fwdX = Math.sin(this.busYaw);
    const fwdZ = Math.cos(this.busYaw);
    // 3 overlapping circles covering full 8.4m x 2.6m WBTC bus hull with zero mid-body gap
    const offsets = [-2.65, 0.0, 2.65];
    const busCircleR = 1.48;
    for (let k = 0; k < offsets.length; k++) {
      const bx = this.busPos.x + fwdX * offsets[k];
      const bz = this.busPos.z + fwdZ * offsets[k];
      const dx = pos.x - bx;
      const dz = pos.z - bz;
      const minDist = actorRadius + busCircleR;
      const distSq = dx * dx + dz * dz;
      if (distSq < minDist * minDist) {
        if (distSq > 0.0001) {
          const dist = Math.sqrt(distSq);
          const push = minDist - dist;
          pos.x += (dx / dist) * push;
          pos.z += (dz / dist) * push;
        } else {
          // Exactly centered: push cleanly out to the right-side doorway
          pos.x += -fwdZ * minDist;
          pos.z += fwdX * minDist;
        }
      }
    }
  }

  private findSafeBusExitPosition(
    out: THREE.Vector3,
    actorRadius: number,
    preferSideSign = 1,
    alongOffset = 0,
    isIntroRoute = false,
  ): void {
    const fwdX = Math.sin(this.busYaw);
    const fwdZ = Math.cos(this.busYaw);
    // Local -X (right-side animated passenger doorway) in world XZ is (-fwdZ, fwdX)
    const doorRightX = -fwdZ;
    const doorRightZ = fwdX;
    const bounds = this.world.playableBounds;

    // 1. Direct Howrah Bridge Deck Exit (NO parachute — hop straight onto the bridge road surface beside the open door!)
    const onHowrahBridgeDeck =
      this.busPos.y > 4.2 &&
      Math.abs(this.busPos.z + 40) < 6.0 &&
      this.busPos.x >= -62 &&
      this.busPos.x <= 62;
    if (onHowrahBridgeDeck) {
      const bx = THREE.MathUtils.clamp(this.busPos.x + fwdX * (1.7 + alongOffset), -62, 62);
      const bz = THREE.MathUtils.clamp(
        this.busPos.z + doorRightZ * (preferSideSign * 2.48),
        -43.9,
        -36.1,
      );
      out.set(bx, 6.58, bz);
      return;
    }

    // 2. Eastern Viaduct Approach Ramp Exit: step safely onto solid East Ghat road (never into river water)
    if (isIntroRoute && this.busPos.y > 0.65) {
      const gx = THREE.MathUtils.clamp(this.busPos.x - 4.5 + alongOffset * 0.6, 22, 42);
      const gz = THREE.MathUtils.clamp(Math.max(this.busPos.z + 2.5, -17.0), -17.0, 18.0);
      out.set(gx, 0, gz);
      this.resolveCircleWorldCollision(out, actorRadius, false);
      out.y = this.world.getGroundHeight(out.x, out.z, 0);
      return;
    }

    // 3. Direct Road / Ground Exit right outside the open side passenger doorway
    const candidates: Array<[number, number]> = [
      [preferSideSign * 2.85, 1.9 + alongOffset],
      [preferSideSign * 3.85, 0.5 + alongOffset],
      [-preferSideSign * 2.95, 1.6 + alongOffset],
      [preferSideSign * 3.35, -2.1 + alongOffset],
      [0, -5.2],
    ];

    for (let c = 0; c < candidates.length; c++) {
      const [lat, fwd] = candidates[c];
      const cx = THREE.MathUtils.clamp(
        this.busPos.x + doorRightX * lat + fwdX * fwd,
        bounds.minX + 1.8,
        bounds.maxX - 1.8,
      );
      const cz = THREE.MathUtils.clamp(
        this.busPos.z + doorRightZ * lat + fwdZ * fwd,
        bounds.minZ + 1.5,
        bounds.maxZ - 1.8,
      );

      const refY = this.world.getGroundHeight(cx, cz, this.busPos.y);
      out.set(cx, refY, cz);
      this.resolveCircleWorldCollision(out, actorRadius, false);
      if (this.busPos.y < 1.35) {
        this.pushOutOfBusHull(out, actorRadius + 0.45, true);
        this.resolveCircleWorldCollision(out, actorRadius, false);
      }

      let clearOfBus = true;
      if (this.busPos.y < 1.35) {
        for (const off of [-2.65, 0.0, 2.65]) {
          const dx = out.x - (this.busPos.x + fwdX * off);
          const dz = out.z - (this.busPos.z + fwdZ * off);
          if (dx * dx + dz * dz < (actorRadius + 1.52) * (actorRadius + 1.52)) {
            clearOfBus = false;
            break;
          }
        }
      }
      if (clearOfBus) {
        out.y = this.world.getGroundHeight(out.x, out.z, this.busPos.y);
        return;
      }
    }

    // Final guaranteed push-out fallback
    if (this.busPos.y < 1.35) {
      this.pushOutOfBusHull(out, actorRadius + 0.7, true);
    }
    out.x = THREE.MathUtils.clamp(out.x, bounds.minX + 1.5, bounds.maxX - 1.5);
    out.z = THREE.MathUtils.clamp(out.z, bounds.minZ + 1.5, bounds.maxZ - 1.5);
    out.y = this.world.getGroundHeight(out.x, out.z, this.busPos.y);
  }

  private resolveCircleWorldCollision(
    pos: THREE.Vector3,
    actorRadius: number,
    includeBusHull = true,
  ): void {
    const bounds = this.world.playableBounds;
    pos.x = THREE.MathUtils.clamp(pos.x, bounds.minX, bounds.maxX);
    pos.z = THREE.MathUtils.clamp(pos.z, bounds.minZ, bounds.maxZ);

    // Hooghly River water barrier: allow crossing via the Howrah Bridge deck & North/South ramps,
    // while keeping actors safely on bridge guardrails or riverbanks everywhere else
    if (this.world.isWaterBlocked(pos.x, pos.z)) {
      if (pos.y > 1.2) {
        // Actor is elevated on bridge/ramps — clamp cleanly back inside the nearest guardrail lane
        if (pos.z <= -35.2 && pos.z >= -44.8) {
          pos.x = THREE.MathUtils.clamp(pos.x, -65.2, 65.2);
          pos.z = THREE.MathUtils.clamp(pos.z, -44.2, -35.8);
        } else if (pos.x < 0) {
          pos.x = THREE.MathUtils.clamp(pos.x, -20.9, -14.1);
        } else {
          pos.x = THREE.MathUtils.clamp(pos.x, 14.1, 20.9);
        }
      } else {
        // Ground-level riverbank edge: gently block wading into deep river water
        pos.z = pos.z > -45.5 ? -20.4 : -70.6;
      }
    }

    // When walking atop the 2nd-floor Zamindar Bari rooftop terrace (y >= 2.8),
    // skip ground-floor partition wall colliders underneath while staying inside the terrace roof
    const onZamindarTerrace =
      pos.y >= 2.8 && pos.x >= 80 && pos.x <= 116 && pos.z >= 7 && pos.z <= 37;

    const colliders: CircleCollider[] = this.world.circleColliders;
    for (let i = 0; i < colliders.length; i++) {
      const c = colliders[i];
      if (onZamindarTerrace && c.kind === 'ruin' && c.height <= 4.7) continue;
      const dx = pos.x - c.x;
      const dz = pos.z - c.z;
      const minDist = actorRadius + c.radius;
      const distSq = dx * dx + dz * dz;
      if (distSq < minDist * minDist && distSq > 0.00001) {
        const dist = Math.sqrt(distSq);
        const push = minDist - dist;
        pos.x += (dx / dist) * push;
        pos.z += (dz / dist) * push;
      }
    }

    // Solid 3-circle hull collision against the WBTC bus whenever it is on village ground
    if (includeBusHull && this.busPos.y < 1.15) {
      this.pushOutOfBusHull(pos, actorRadius, false);
    }

    pos.x = THREE.MathUtils.clamp(pos.x, bounds.minX, bounds.maxX);
    pos.z = THREE.MathUtils.clamp(pos.z, bounds.minZ, bounds.maxZ);
  }

  /**
   * Parametric XZ ray-segment vs vertical cylinder intersection.
   * Returns earliest t in [0, 1] where segment A->B enters circle (cx, cz, r) within [minY, maxY], or Infinity.
   */
  private segmentHitsCylinderT(
    a: THREE.Vector3,
    b: THREE.Vector3,
    cx: number,
    cz: number,
    radius: number,
    minY: number,
    maxY: number,
  ): number {
    const dx = b.x - a.x;
    const dz = b.z - a.z;
    const fx = a.x - cx;
    const fz = a.z - cz;
    const rSq = radius * radius;
    const aLenSq = dx * dx + dz * dz;

    if (aLenSq < 1e-8) {
      if (fx * fx + fz * fz <= rSq && a.y >= minY && a.y <= maxY) return 0;
      return Infinity;
    }

    const cVal = fx * fx + fz * fz - rSq;
    if (cVal <= 0) {
      if (a.y >= minY && a.y <= maxY) return 0;
    }

    const bVal = 2 * (fx * dx + fz * dz);
    const disc = bVal * bVal - 4 * aLenSq * cVal;
    if (disc < 0) return Infinity;

    const sqrtD = Math.sqrt(disc);
    const t1 = (-bVal - sqrtD) / (2 * aLenSq);
    if (t1 >= 0 && t1 <= 1) {
      const yAt = a.y + (b.y - a.y) * t1;
      if (yAt >= minY && yAt <= maxY) return t1;
    }

    const t2 = (-bVal + sqrtD) / (2 * aLenSq);
    if (t1 < 0 && t2 >= 0) {
      const yAt = a.y;
      if (yAt >= minY && yAt <= maxY) return 0;
    }
    return Infinity;
  }

  /**
   * Returns earliest t in [0, 1] where 3D segment A->B hits ground, mud houses, taxi, trees,
   * cover crates, riverbank parapet walls, or the solid WBTC bus hull; returns Infinity if clear.
   */
  private segmentFirstObstacleT(
    a: THREE.Vector3,
    b: THREE.Vector3,
    includeBus = true,
  ): number {
    let bestT = Infinity;

    // Terrain surface hit check (respects laterite hills & bridge ramps)
    const groundB = this.world.getGroundHeight(b.x, b.z) + 0.05;
    if (b.y <= groundB && a.y > groundB) {
      const tG = (groundB - a.y) / (b.y - a.y);
      if (tG >= 0 && tG <= 1 && tG < bestT) bestT = tG;
    } else if (b.y <= groundB && a.y <= groundB) {
      return 0;
    }

    // All world obstacles (mud houses, Zamindar Bari ruins, vintage trams, stalls, boulders, trees, taxis, crates)
    const colliders = this.world.circleColliders;
    for (let i = 0; i < colliders.length; i++) {
      const c = colliders[i];
      const baseY = c.kind === 'boulder' || c.kind === 'tree' ? this.world.getGroundHeight(c.x, c.z) : 0;
      const t = this.segmentHitsCylinderT(a, b, c.x, c.z, c.radius, baseY, baseY + c.height);
      if (t < bestT) bestT = t;
    }

    // Riverbank brick parapet walls (z = -17.6, height = 0.95)
    if ((a.z > -17.3 && b.z < -17.9) || (a.z < -17.9 && b.z > -17.3)) {
      const tW = (-17.6 - a.z) / (b.z - a.z);
      if (tW >= 0 && tW <= 1 && tW < bestT) {
        const wx = a.x + (b.x - a.x) * tW;
        const wy = a.y + (b.y - a.y) * tW;
        if (Math.abs(wx) > 10 && Math.abs(wx) < 46 && wy <= 0.95) {
          bestT = tW;
        }
      }
    }

    // Solid WBTC bus hull (3 circles along length, height = 3.4m)
    if (includeBus && this.busPos.y < 1.2) {
      const fwdX = Math.sin(this.busYaw);
      const fwdZ = Math.cos(this.busYaw);
      for (const off of [-2.65, 0.0, 2.65]) {
        const bx = this.busPos.x + fwdX * off;
        const bz = this.busPos.z + fwdZ * off;
        const tB = this.segmentHitsCylinderT(a, b, bx, bz, 1.48, 0, 3.45);
        if (tB < bestT) bestT = tB;
      }
    }

    return bestT;
  }

  private hasLineOfSight(from: THREE.Vector3, to: THREE.Vector3): boolean {
    return this.segmentFirstObstacleT(from, to, true) === Infinity;
  }

  // --- Simulation Update ---

  private update(dt: number): void {
    this.worldTime += dt;

    // Ambient world animation (water ripples, swaying coconut palms, bobbing country boat)
    this.world.waterUniforms.uTime.value = this.worldTime;
    this.world.waterBumpTexture.offset.x = (this.worldTime * 0.03) % 1;
    this.world.waterBumpTexture.offset.y = (this.worldTime * 0.015) % 1;

    for (const palm of this.world.swayingPalms) {
      palm.crown.rotation.z = Math.sin(this.worldTime * 1.35 + palm.phase) * 0.045;
      palm.crown.rotation.x = Math.cos(this.worldTime * 1.05 + palm.phase) * 0.035;
    }

    for (let i = 0; i < this.world.bobbingBoats.length; i++) {
      const boat = this.world.bobbingBoats[i];
      const phase = i * 0.95;
      boat.position.y = -1.18 + Math.sin(this.worldTime * 1.55 + phase) * 0.09;
      boat.rotation.z = Math.sin(this.worldTime * 1.25 + phase) * 0.045;
    }

    if (this.phase === 'title') {
      this.titleTime += dt;
      // Free Fire-style 3D Main Lobby: hero stands center-stage in front of West Bengal village,
      // Yellow Ambassador Taxi, coconut palms, Hooghly River, and Howrah-style bridge.
      this.hero.root.position.set(0, 0, 7.2);

      // Scenic background WBTC bus gliding slowly across the Howrah-style bridge in the lobby!
      const lobbyBusT = 0.02 + ((this.titleTime * 0.025) % 0.3);
      this.positionBusOnIntroRoute(lobbyBusT);
      for (const w of this.bus.wheels) {
        w.rotation.x += dt * 4.5;
      }

      // Continuous smooth 360-degree turntable rotation from frame 1 (pauses cleanly while dragging)
      if (!this.lobbyDragActive) {
        this.lobbyHeroTargetYaw += dt * 0.44;
      }
      const prevYaw = this.lobbyHeroYaw;
      const yawDamp = 1 - Math.exp(-10 * dt);
      this.lobbyHeroYaw += (this.lobbyHeroTargetYaw - this.lobbyHeroYaw) * yawDamp;
      this.hero.root.rotation.y = this.lobbyHeroYaw;
      const lobbyYawRate = (this.lobbyHeroYaw - prevYaw) / Math.max(0.001, dt);

      // Lifelike idle breathing, subtle contrapposto weight shift, calm gaze, blinking & breeze
      this.lobbyShowcasePulse = Math.max(0, this.lobbyShowcasePulse - dt * 3.5);
      const breathPhase = this.titleTime * 2.05;
      const breath = Math.sin(breathPhase);
      const swayPhase = this.titleTime * 0.82;
      const popScale = 1 + Math.sin(this.lobbyShowcasePulse * Math.PI) * 0.036;

      this.hero.bodyGroup.position.y = breath * 0.004;
      this.hero.bodyGroup.rotation.y = 0;
      this.hero.bodyGroup.rotation.z = Math.sin(swayPhase) * 0.015;
      this.hero.bodyGroup.scale.set(popScale, popScale, popScale);

      // Thoracic breathing & subtle upper-body posture shift anchored at lumbar waist
      this.hero.upperBodyGroup.position.y = 0.94 + breath * 0.0095;
      this.hero.upperBodyGroup.rotation.x = Math.sin(breathPhase - 0.55) * 0.018;
      this.hero.upperBodyGroup.rotation.y = Math.sin(swayPhase * 0.85) * 0.055;
      this.hero.upperBodyGroup.rotation.z = Math.cos(swayPhase) * 0.014;

      // Natural relaxed contrapposto stance (feet planted cleanly, knees subtly soft)
      this.hero.leftLeg.rotation.x = -0.045;
      this.hero.leftLeg.rotation.z = 0;
      this.hero.rightLeg.rotation.x = 0.05;
      this.hero.rightLeg.rotation.z = 0;
      this.hero.leftKnee.rotation.x = 0.08;
      this.hero.rightKnee.rotation.x = 0.045;
      this.hero.leftAnkle.rotation.x = -0.035;
      this.hero.rightAnkle.rotation.x = -0.09;

      // Calm attentive head motion, involuntary blinking & subtle river-breeze hair/kurta flutter
      this.hero.headGroup.rotation.y =
        Math.sin(this.titleTime * 0.72) * 0.11 + Math.sin(this.titleTime * 1.75) * 0.022;
      this.hero.headGroup.rotation.x = Math.sin(this.titleTime * 1.25) * 0.028 - breath * 0.01;
      this.hero.headGroup.rotation.z = Math.sin(this.titleTime * 0.58) * 0.022;
      this.hero.hairTuft.rotation.x = Math.sin(this.worldTime * 3.2) * 0.032;
      this.hero.hairTuft.rotation.z = Math.cos(this.worldTime * 2.6) * 0.028;
      this.hero.kurtaHem.rotation.x = Math.sin(this.worldTime * 2.3) * 0.024;
      this.hero.kurtaHem.rotation.z = Math.cos(this.worldTime * 1.8) * 0.018;
      this.updateHeroBlink(dt);

      // Subtle breathing settle on arms & carried weapon
      this.hero.leftArm.position.set(0, breath * 0.0045, 0);
      this.hero.rightArm.position.set(0, breath * 0.0045, 0);
      this.hero.recoilGroup.position.set(0.115, 0.31 + breath * 0.0055, 0.27);
      this.hero.recoilGroup.rotation.set(Math.sin(this.titleTime * 1.6) * 0.02, 0, 0);

      // Real-time Verlet cloth simulation on the red-and-white gamcha (Hooghly river breeze + drag-spin whip!)
      this.hero.updateGamchaCloth(dt, this.worldTime, 0, 0, 0, lobbyYawRate, 0.28);

      // Keep shadow frustum locked cleanly on the lobby hero & village square
      this.sunLight.position.set(32, 56, -18);
      this.sunLight.target.position.set(0, 0, 4);

      // Heroic front-facing lobby camera with gentle atmospheric float
      const swayX = Math.sin(this.titleTime * 0.45) * 0.16;
      const swayY = Math.cos(this.titleTime * 0.65) * 0.045;
      this.camera.position.set(-0.2 + swayX, 1.5 + swayY, 11.1);
      this.camera.lookAt(0.14, 1.28, -4.0);
      return;
    }

    if (this.phase !== 'playing') {
      return;
    }

    // Brief hitstop on heavy kill impact for tactile weight
    if (this.hitstopTimer > 0) {
      this.hitstopTimer = Math.max(0, this.hitstopTimer - dt);
      return;
    }

    // Decay UI / feedback / recoil timers
    this.damageFlash = Math.max(0, this.damageFlash - dt * 2.15);
    if (this.damageFlash <= 0.02) {
      this.hasDamageSource = false;
      this.damageAngle = null;
    }
    this.hitMarker = Math.max(0, this.hitMarker - dt * 4.4);
    this.camShake = Math.max(0, this.camShake - dt * 1.9);
    this.camRecoilPitch = THREE.MathUtils.damp(this.camRecoilPitch, 0, 14.5, dt);
    this.camRecoilYaw = THREE.MathUtils.damp(this.camRecoilYaw, 0, 15.5, dt);
    if (Math.abs(this.camRecoilPitch) < 0.0004) this.camRecoilPitch = 0;
    if (Math.abs(this.camRecoilYaw) < 0.0004) this.camRecoilYaw = 0;
    this.heroFireHoldTimer = Math.max(0, this.heroFireHoldTimer - dt);
    if (this.waveBannerTimer > 0) {
      this.waveBannerTimer -= dt;
      if (this.waveBannerTimer <= 0) this.waveBanner = null;
    }
    if (this.pickupToastTimer > 0) {
      this.pickupToastTimer -= dt;
      if (this.pickupToastTimer <= 0) this.pickupToast = null;
    }

    // Camera keyboard orbit assist (Q/E) + touch drag look driven by General & Scope sensitivity sliders
    const generalLook = this.getGeneralLookFactor();
    const lookMult = this.scopeActive ? this.getScopeLookFactor() : generalLook;
    if (this.busMode === 'riding_intro' && this.busInteriorCam) {
      // Allow subtle left/right cabin window glancing over the Howrah Bridge & landmarks
      if (this.keysHeld.has('KeyQ')) this.busInteriorLookYaw += 1.6 * generalLook * dt;
      if (this.keysHeld.has('KeyE')) this.busInteriorLookYaw -= 1.6 * generalLook * dt;
      if (this.virtualInput.lookDeltaX !== 0 || this.virtualInput.lookDeltaY !== 0) {
        this.busInteriorLookYaw -= this.virtualInput.lookDeltaX * 0.0045 * generalLook;
        this.virtualInput.lookDeltaX = 0;
        this.virtualInput.lookDeltaY = 0;
      }
      this.busInteriorLookYaw = THREE.MathUtils.clamp(this.busInteriorLookYaw, -0.68, 0.68);
    } else {
      if (this.keysHeld.has('KeyQ')) this.camYaw += 2.2 * lookMult * dt;
      if (this.keysHeld.has('KeyE')) this.camYaw -= 2.2 * lookMult * dt;
      if (this.virtualInput.lookDeltaX !== 0 || this.virtualInput.lookDeltaY !== 0) {
        this.camYaw -= this.virtualInput.lookDeltaX * 0.0055 * lookMult;
        this.camPitch = THREE.MathUtils.clamp(
          this.camPitch + this.virtualInput.lookDeltaY * 0.0042 * lookMult,
          -0.18,
          0.65,
        );
        this.virtualInput.lookDeltaX = 0;
        this.virtualInput.lookDeltaY = 0;
      }
    }

    // Read unified movement / steering input (Keyboard WASD / Arrows + Virtual Touch Joystick)
    let moveRight = this.virtualInput.moveX;
    let moveForward = this.virtualInput.moveY;
    if (this.keysHeld.has('KeyD') || this.keysHeld.has('ArrowRight')) moveRight += 1;
    if (this.keysHeld.has('KeyA') || this.keysHeld.has('ArrowLeft')) moveRight -= 1;
    if (this.keysHeld.has('KeyW') || this.keysHeld.has('ArrowUp')) moveForward += 1;
    if (this.keysHeld.has('KeyS') || this.keysHeld.has('ArrowDown')) moveForward -= 1;

    const moveLen = Math.hypot(moveRight, moveForward);
    if (moveLen > 1) {
      moveRight /= moveLen;
      moveForward /= moveLen;
    }

    // --- 1. Update WBTC Passenger Bus (Auto Intro Route OR Player Driving OR Coasting Stop) ---
    if (this.busDoorAutoHoldTimer > 0) {
      this.busDoorAutoHoldTimer = Math.max(0, this.busDoorAutoHoldTimer - dt);
    }
    const targetDoorOpen = this.busExitSlowing || this.busDoorAutoHoldTimer > 0 ? 1 : 0;
    this.busDoorOpenAmount += (targetDoorOpen - this.busDoorOpenAmount) * (1 - Math.exp(-11 * dt));
    this.bus.interior.setDoorOpenAmount(this.busDoorOpenAmount);
    this.bus.interior.introDriverGroup.visible = this.busAutoDriving && this.busMode !== 'driving';

    if (this.busAutoDriving) {
      const prevPos = _v2.copy(this.busPos);
      // Smoothly decelerate as the bus approaches its final stop OR briefly brakes when player taps 'বাস থেকে নামুন'
      const endSlowDown =
        this.busRouteT > 0.88 ? THREE.MathUtils.lerp(1.0, 0.35, (this.busRouteT - 0.88) / 0.12) : 1.0;
      const exitBrakeMult = this.busExitSlowing
        ? THREE.MathUtils.lerp(0.14, 0.85, Math.max(0, this.busExitSlowTimer / this.busExitSlowDuration))
        : 1.0;
      this.busRouteT = Math.min(1.0, this.busRouteT + dt * 0.046 * endSlowDown * exitBrakeMult);
      this.positionBusOnIntroRoute(this.busRouteT);

      const movedDist = this.busPos.distanceTo(prevPos);
      this.busSpeed = movedDist / Math.max(0.001, dt);
      for (const w of this.bus.wheels) {
        w.rotation.x += movedDist / 0.54;
      }
      this.bus.chassisGroup.position.y = Math.sin(this.worldTime * 14) * (this.busExitSlowing ? 0.007 : 0.016);

      this.bus.root.updateMatrixWorld(true);

      // Update & auto-drop AI enemy passengers riding seated inside the bus cabin along the route
      for (const e of this.enemies) {
        if (e.dying || e.busSeatIndex < 0) continue;
        if (this.busRouteT >= e.busDropT) {
          this.dropEnemyFromBus(e);
        } else {
          this.bus.enemySeats[e.busSeatIndex].getWorldPosition(e.rig.root.position);
          e.rig.root.rotation.y = this.busYaw;
        }
      }

      // Complete braking + door-opening exit sequence once bus has slowed & side door swung open
      if (this.busExitSlowing && this.busMode === 'riding_intro') {
        this.busExitSlowTimer -= dt;
        if (this.busExitSlowTimer <= 0) {
          this.executeDirectGroundExit();
        }
      }

      // Auto-exit hero at the very end of the route if they stayed on until the last village stop
      if (this.busRouteT >= 0.999) {
        this.busAutoDriving = false;
        this.busSpeed = 0;
        this.bus.chassisGroup.position.y = 0;
        this.bus.root.rotation.set(0, this.busYaw, 0);
        // Drop any straggling bus enemies safely
        for (const e of this.enemies) {
          if (!e.dying && e.busSeatIndex >= 0) this.dropEnemyFromBus(e);
        }
        if (this.busMode === 'riding_intro') {
          this.executeDirectGroundExit();
        }
      }
    } else if (this.busMode === 'driving') {
      // Player-controlled WBTC bus driving around the West Bengal village!
      const accel = 14.5;
      const maxFwd = 15.0;
      const maxRev = -6.0;

      if (Math.abs(moveForward) > 0.05) {
        this.busSpeed += moveForward * accel * dt;
      } else {
        this.busSpeed *= Math.exp(-3.4 * dt);
        if (Math.abs(this.busSpeed) < 0.08) this.busSpeed = 0;
      }
      this.busSpeed = THREE.MathUtils.clamp(this.busSpeed, maxRev, maxFwd);

      const targetSteer = -moveRight * 0.48;
      this.busSteerAngle += (targetSteer - this.busSteerAngle) * (1 - Math.exp(-10 * dt));
      for (const pivot of this.bus.frontWheelPivots) {
        pivot.rotation.y = this.busSteerAngle;
      }

      if (Math.abs(this.busSpeed) > 0.25) {
        const turnSign = this.busSpeed >= 0 ? 1 : -1;
        const turnFactor = Math.min(1, Math.abs(this.busSpeed) / 6.0);
        this.busYaw += this.busSteerAngle * 2.15 * turnFactor * turnSign * dt;
      }

      const bFwdX = Math.sin(this.busYaw);
      const bFwdZ = Math.cos(this.busYaw);
      const prevX = this.busPos.x;
      const prevZ = this.busPos.z;

      this.busPos.x += bFwdX * this.busSpeed * dt;
      this.busPos.z += bFwdZ * this.busSpeed * dt;

      // Keep drivable bus cleanly inside the 1000x1000 map & slide off houses/trees/taxi/river edge
      this.resolveCircleWorldCollision(this.busPos, 1.85, false);
      const busGroundY = this.world.getGroundHeight(this.busPos.x, this.busPos.z, this.busPos.y);
      this.busPos.y += (busGroundY - this.busPos.y) * Math.min(1, dt * 16);

      const actualDist = Math.hypot(this.busPos.x - prevX, this.busPos.z - prevZ);
      if (Math.abs(this.busSpeed) > 2.5 && actualDist < Math.abs(this.busSpeed) * dt * 0.35) {
        this.busSpeed *= 0.55; // gentle bumper bounce on impact
      }

      // Compute gentle road slope pitch for hills & Howrah Bridge crossing ramps
      const frontY = this.world.getGroundHeight(this.busPos.x + bFwdX * 2.4, this.busPos.z + bFwdZ * 2.4, this.busPos.y);
      const backY = this.world.getGroundHeight(this.busPos.x - bFwdX * 2.4, this.busPos.z - bFwdZ * 2.4, this.busPos.y);
      const slopePitch = -Math.atan2(frontY - backY, 4.8);

      this.bus.root.position.copy(this.busPos);
      this.bus.root.rotation.set(slopePitch, this.busYaw, 0);
      this.bus.chassisGroup.rotation.z = -this.busSteerAngle * Math.min(1, Math.abs(this.busSpeed) / 12) * 0.08;
      this.bus.chassisGroup.position.y = Math.sin(this.worldTime * 16) * (Math.abs(this.busSpeed) > 1 ? 0.02 : 0.005);

      const wheelSpin = (this.busSpeed * dt) / 0.54;
      for (const w of this.bus.wheels) {
        w.rotation.x += wheelSpin;
      }

      // Ram enemy bots with the bus!
      if (Math.abs(this.busSpeed) > 4.2) {
        for (const e of this.enemies) {
          if (e.dying || e.busSeatIndex >= 0) continue;
          const dx = e.rig.root.position.x - this.busPos.x;
          const dz = e.rig.root.position.z - this.busPos.z;
          if (dx * dx + dz * dz < 3.1 * 3.1) {
            _v4.set(bFwdX * this.busSpeed, 0, bFwdZ * this.busSpeed);
            _v6.set(e.rig.root.position.x, 1.2, e.rig.root.position.z);
            this.damageEnemy(e, 95, _v4, false, _v6);
            this.camShake = Math.min(0.36, this.camShake + 0.16);
          }
        }
      }

      this.bus.root.updateMatrixWorld(true);
    } else {
      // Bus coasting smoothly to a stop when unmanned on village ground
      if (Math.abs(this.busSpeed) > 0.05) {
        this.busSpeed *= Math.exp(-4.5 * dt);
        const bFwdX = Math.sin(this.busYaw);
        const bFwdZ = Math.cos(this.busYaw);
        this.busPos.x += bFwdX * this.busSpeed * dt;
        this.busPos.z += bFwdZ * this.busSpeed * dt;
        this.resolveCircleWorldCollision(this.busPos, 1.85, false);
        this.busPos.y = this.world.getGroundHeight(this.busPos.x, this.busPos.z, this.busPos.y);
        this.bus.root.position.copy(this.busPos);
        for (const w of this.bus.wheels) {
          w.rotation.x += (this.busSpeed * dt) / 0.54;
        }
      } else {
        this.busSpeed = 0;
      }
      this.bus.chassisGroup.rotation.z *= Math.exp(-8 * dt);
      this.bus.chassisGroup.position.y *= Math.exp(-8 * dt);
    }

    // Sway overhead bus hand-straps naturally with cabin speed and braking inertia
    const strapAmp = 0.04 + Math.min(0.18, Math.abs(this.busSpeed) * 0.012);
    const brakeTilt = this.busExitSlowing ? 0.28 : 0;
    for (let s = 0; s < this.bus.interior.hangingStraps.length; s++) {
      const strap = this.bus.interior.hangingStraps[s];
      strap.rotation.x = brakeTilt + Math.sin(this.worldTime * 4.2 + s * 0.75) * strapAmp;
      strap.rotation.z = Math.cos(this.worldTime * 3.1 + s * 0.55) * strapAmp * 0.65;
    }

    // --- 2. Update Hero Position, Mode & Actions ---
    const fwdX = Math.sin(this.camYaw);
    const fwdZ = Math.cos(this.camYaw);
    const rightX = -fwdZ;
    const rightZ = fwdX;

    if (this.busMode === 'riding_intro') {
      // Hero rides seated inside the hollow WBTC bus cabin, then stands & steps to the opening door when exiting
      this.bus.heroIntroSeat.getWorldPosition(this.heroPos);
      let sitBlend = 1;
      if (this.busExitSlowing) {
        this.bus.interior.heroDoorwayAnchor.getWorldPosition(this.heroDoorwayWorld);
        const stepT = THREE.MathUtils.clamp(
          1 - this.busExitSlowTimer / Math.max(0.01, this.busExitSlowDuration),
          0,
          1,
        );
        const smoothStep = stepT * stepT * (3 - 2 * stepT);
        this.heroPos.lerp(this.heroDoorwayWorld, smoothStep);
        this.heroYaw = this.busYaw - smoothStep * (Math.PI * 0.42);
        sitBlend = 1 - smoothStep;
      } else {
        this.heroYaw = this.busYaw;
      }
      const roadVib = Math.sin(this.worldTime * 14.5) * 0.0055 * sitBlend;
      const busBreath = Math.sin(this.worldTime * 2.15) * 0.007;
      this.hero.leftLeg.rotation.x = THREE.MathUtils.damp(this.hero.leftLeg.rotation.x, -1.16 * sitBlend, 14, dt);
      this.hero.leftLeg.rotation.z = THREE.MathUtils.damp(this.hero.leftLeg.rotation.z, 0, 14, dt);
      this.hero.rightLeg.rotation.x = THREE.MathUtils.damp(this.hero.rightLeg.rotation.x, -1.16 * sitBlend, 14, dt);
      this.hero.rightLeg.rotation.z = THREE.MathUtils.damp(this.hero.rightLeg.rotation.z, 0, 14, dt);
      this.hero.leftKnee.rotation.x = THREE.MathUtils.damp(this.hero.leftKnee.rotation.x, 1.16 * sitBlend, 14, dt);
      this.hero.rightKnee.rotation.x = THREE.MathUtils.damp(this.hero.rightKnee.rotation.x, 1.16 * sitBlend, 14, dt);
      this.hero.leftAnkle.rotation.x = THREE.MathUtils.damp(this.hero.leftAnkle.rotation.x, 0.08 * sitBlend, 14, dt);
      this.hero.rightAnkle.rotation.x = THREE.MathUtils.damp(this.hero.rightAnkle.rotation.x, 0.08 * sitBlend, 14, dt);
      this.hero.bodyGroup.position.y = roadVib;
      this.hero.bodyGroup.rotation.y = THREE.MathUtils.damp(this.hero.bodyGroup.rotation.y, 0, 12, dt);
      this.hero.bodyGroup.rotation.z = THREE.MathUtils.damp(this.hero.bodyGroup.rotation.z, 0, 10, dt);
      this.hero.upperBodyGroup.position.y = 0.94 + busBreath;
      this.hero.upperBodyGroup.rotation.x = THREE.MathUtils.damp(
        this.hero.upperBodyGroup.rotation.x,
        this.busExitSlowing ? 0.14 : 0.03 + busBreath * 1.4,
        10,
        dt,
      );
      this.hero.upperBodyGroup.rotation.y = THREE.MathUtils.damp(
        this.hero.upperBodyGroup.rotation.y,
        Math.sin(this.worldTime * 0.7) * 0.05 * sitBlend,
        8,
        dt,
      );
      this.hero.upperBodyGroup.rotation.z = THREE.MathUtils.damp(this.hero.upperBodyGroup.rotation.z, 0, 10, dt);
      this.hero.root.position.copy(this.heroPos);
      this.hero.root.rotation.set(0, this.heroYaw, 0);
      this.hero.headGroup.rotation.set(
        Math.sin(this.worldTime * 1.1) * 0.03,
        Math.sin(this.worldTime * 0.85) * 0.18,
        Math.sin(this.worldTime * 0.65) * 0.025,
      );
      this.hero.hairTuft.rotation.x = Math.sin(this.worldTime * 4.8) * 0.04;
      this.hero.kurtaHem.rotation.x = Math.sin(this.worldTime * 3.1) * 0.025;
      this.updateHeroBlink(dt);
      this.hero.updateGamchaCloth(dt, this.worldTime, 0.35, 0, this.busSpeed * 0.28, 0, 0.42);
      this.hero.muzzleFlash.visible = false;
      this.hero.muzzleLight.intensity = 0;
      this.nearBus = false;
    } else if (this.busMode === 'driving') {
      // Hero sits visibly in the right-hand-drive cab behind the steering wheel!
      this.bus.heroDriverSeat.getWorldPosition(this.heroPos);
      this.hero.root.position.copy(this.heroPos);
      this.heroYaw = this.busYaw;
      this.hero.root.rotation.set(0, this.heroYaw, 0);
      this.hero.leftLeg.rotation.x = -1.08;
      this.hero.leftLeg.rotation.z = 0;
      this.hero.rightLeg.rotation.x = -1.08;
      this.hero.rightLeg.rotation.z = 0;
      this.hero.leftKnee.rotation.x = 1.08;
      this.hero.rightKnee.rotation.x = 1.08;
      this.hero.leftAnkle.rotation.x = 0.06;
      this.hero.rightAnkle.rotation.x = 0.06;
      this.hero.bodyGroup.position.y = Math.sin(this.worldTime * 15) * (Math.abs(this.busSpeed) > 1 ? 0.008 : 0.003);
      this.hero.bodyGroup.rotation.y = 0;
      this.hero.bodyGroup.rotation.z = 0;
      this.hero.upperBodyGroup.position.y = 0.94 + Math.sin(this.worldTime * 2.2) * 0.006;
      this.hero.upperBodyGroup.rotation.set(
        0.06,
        -this.busSteerAngle * 0.16,
        -this.busSteerAngle * 0.08,
      );
      this.hero.headGroup.rotation.set(0, -this.busSteerAngle * 0.45, 0);
      this.hero.hairTuft.rotation.x = Math.sin(this.worldTime * 5.2) * 0.035;
      this.updateHeroBlink(dt);
      this.hero.updateGamchaCloth(dt, this.worldTime, 0, 0, this.busSpeed * 0.25, 0, 0.35);
      this.hero.muzzleFlash.visible = false;
      this.hero.muzzleLight.intensity = 0;
      this.nearBus = false;
    } else if (this.heroJumpingFromBus) {
      // Direct grounded hop onto the Howrah Bridge deck or village road (no parachute!)
      const prevY = this.heroPos.y;
      this.heroJumpProgress = Math.min(1, this.heroJumpProgress + dt / this.heroJumpDuration);
      const t = this.heroJumpProgress;
      this.heroPos.lerpVectors(this.heroJumpStart, this.heroJumpEnd, t);
      const arc = 4 * t * (1 - t);
      const baseY = THREE.MathUtils.lerp(this.heroJumpStart.y, this.heroJumpEnd.y, t);
      const lift = Math.max(0.2, this.heroJumpPeakY - (this.heroJumpStart.y + this.heroJumpEnd.y) * 0.5);
      this.heroPos.y = baseY + arc * lift;
      this.hero.root.position.copy(this.heroPos);
      // Athletic mid-air stride & forward balance lean
      this.hero.leftLeg.rotation.x = THREE.MathUtils.damp(this.hero.leftLeg.rotation.x, -0.44, 15, dt);
      this.hero.rightLeg.rotation.x = THREE.MathUtils.damp(this.hero.rightLeg.rotation.x, 0.34, 15, dt);
      this.hero.leftKnee.rotation.x = THREE.MathUtils.damp(this.hero.leftKnee.rotation.x, 0.62, 15, dt);
      this.hero.rightKnee.rotation.x = THREE.MathUtils.damp(this.hero.rightKnee.rotation.x, 0.38, 15, dt);
      this.hero.leftAnkle.rotation.x = THREE.MathUtils.damp(this.hero.leftAnkle.rotation.x, 0.22, 15, dt);
      this.hero.rightAnkle.rotation.x = THREE.MathUtils.damp(this.hero.rightAnkle.rotation.x, 0.28, 15, dt);
      this.hero.upperBodyGroup.rotation.x = THREE.MathUtils.damp(this.hero.upperBodyGroup.rotation.x, 0.2, 12, dt);
      this.hero.kurtaHem.rotation.x = THREE.MathUtils.damp(this.hero.kurtaHem.rotation.x, 0.24, 12, dt);
      this.hero.hairTuft.rotation.x = -0.12;
      this.updateHeroBlink(dt);
      const vertVel = (this.heroPos.y - prevY) / Math.max(0.001, dt);
      this.hero.updateGamchaCloth(dt, this.worldTime, 0, vertVel * 0.6, 3.8, 0, 1.2);

      if (this.heroJumpProgress >= 1) {
        this.heroJumpingFromBus = false;
        this.resolveCircleWorldCollision(this.heroPos, 0.58, true);
        this.heroPos.y = this.world.getGroundHeight(
          this.heroPos.x,
          this.heroPos.z,
          this.heroJumpEnd.y,
        );
        this.hero.root.position.copy(this.heroPos);
        this.heroLandingCrouch = 1.0; // Smooth athletic knee-bend impact absorption on landing
        this.camShake = Math.min(0.22, this.camShake + 0.1);
        this.spawnParticles(this.heroPos, 0xd8a872, 10, 3.8);
      }
      this.nearBus = false;
    } else {
      // Standard on-foot third-person tactical shooter movement, strafe & sprint transitions
      const isShooting =
        this.mouseShootHeld || this.keysHeld.has('Space') || this.virtualInput.shooting;
      const isCombatLock = isShooting || this.scopeActive || this.heroFireHoldTimer > 0;

      // Sprint engages smoothly on forward/diagonal movement when not aiming, firing, or healing
      const wantsSprint =
        (this.keysHeld.has('ShiftLeft') || this.keysHeld.has('ShiftRight') || this.virtualInput.sprinting) &&
        moveLen > 0.25 &&
        moveForward > 0.2 &&
        !isCombatLock &&
        !this.isHealing;
      const isSprinting = wantsSprint && this.sprintStamina > 0.08;
      if (isSprinting) {
        this.sprintStamina = Math.max(0, this.sprintStamina - dt * 0.4);
      } else {
        this.sprintStamina = Math.min(1, this.sprintStamina + dt * 0.3);
      }

      // Smoothly transition speed multipliers across sprint, tactical jog, strafe, backpedal, ADS & healing
      let targetSpeedMult = 1.0;
      if (this.isHealing) {
        targetSpeedMult = 0.54;
      } else if (this.scopeActive) {
        targetSpeedMult = 0.62;
      } else if (isSprinting) {
        targetSpeedMult = 1.44;
      } else if (isCombatLock) {
        targetSpeedMult = moveForward < -0.2 ? 0.72 : 0.84;
      } else if (moveForward < -0.25) {
        targetSpeedMult = 0.84;
      } else if (Math.abs(moveRight) > 0.65 && Math.abs(moveForward) < 0.35) {
        targetSpeedMult = 0.92;
      }
      this.heroSpeedMult = THREE.MathUtils.damp(this.heroSpeedMult, targetSpeedMult, 10.5, dt);

      const moveSpeed = 7.4 * this.heroSpeedMult;
      const desiredVx = (fwdX * moveForward + rightX * moveRight) * moveSpeed;
      const desiredVz = (fwdZ * moveForward + rightZ * moveRight) * moveSpeed;

      // Grounded acceleration / deceleration damping for crisp PUBG/Free Fire footwork without abrupt snapping
      const accelRate = moveLen > 0.05 ? 14.5 : 13.0;
      this.heroVelX = THREE.MathUtils.damp(this.heroVelX, desiredVx, accelRate, dt);
      this.heroVelZ = THREE.MathUtils.damp(this.heroVelZ, desiredVz, accelRate, dt);
      if (moveLen <= 0.04 && Math.hypot(this.heroVelX, this.heroVelZ) < 0.06) {
        this.heroVelX = 0;
        this.heroVelZ = 0;
      }

      this.prevHeroPos.copy(this.heroPos);
      this.prevHeroYaw = this.heroYaw;

      this.heroPos.x += this.heroVelX * dt;
      this.heroPos.z += this.heroVelZ * dt;
      this.resolveCircleWorldCollision(this.heroPos, 0.56, true);
      const targetGroundY = this.world.getGroundHeight(this.heroPos.x, this.heroPos.z, this.heroPos.y);
      if (Math.abs(targetGroundY - this.heroPos.y) <= 1.85) {
        this.heroPos.y = targetGroundY;
      } else {
        this.heroPos.y = THREE.MathUtils.lerp(this.heroPos.y, targetGroundY, Math.min(1, dt * 14));
      }
      this.hero.root.position.copy(this.heroPos);

      // Proximity check for re-entering & driving the WBTC bus ('বাসে উঠুন')
      this.nearBus =
        !this.busAutoDriving &&
        this.heroPos.distanceTo(this.busPos) < 5.8;

      // Smooth tactical hero facing: locks briskly to crosshair during combat, flows naturally with travel otherwise
      const velSpeed = Math.hypot(this.heroVelX, this.heroVelZ);
      const desiredYaw = isCombatLock
        ? this.camYaw
        : moveLen > 0.14 && velSpeed > 0.5
          ? Math.atan2(this.heroVelX, this.heroVelZ)
          : this.camYaw;

      let yawDiff = desiredYaw - this.heroYaw;
      while (yawDiff > Math.PI) yawDiff -= Math.PI * 2;
      while (yawDiff < -Math.PI) yawDiff += Math.PI * 2;
      const turnRate = isCombatLock ? 20.5 : moveLen > 0.14 ? 12.0 : 4.2;
      this.heroYaw += yawDiff * (1 - Math.exp(-turnRate * dt));
      this.hero.root.rotation.set(0, this.heroYaw, 0);

      // Convert actual grounded velocity into hero local space for gait, strafe leaning & Verlet gamcha cloth
      const worldVx = (this.heroPos.x - this.prevHeroPos.x) / Math.max(0.001, dt);
      const worldVz = (this.heroPos.z - this.prevHeroPos.z) / Math.max(0.001, dt);
      const actualSpeed = Math.hypot(worldVx, worldVz);
      const sinY = Math.sin(this.heroYaw);
      const cosY = Math.cos(this.heroYaw);
      const localVelZ = worldVx * sinY + worldVz * cosY;
      const localVelX = worldVx * cosY - worldVz * sinY;
      let dYaw = this.heroYaw - this.prevHeroYaw;
      while (dYaw > Math.PI) dYaw -= Math.PI * 2;
      while (dYaw < -Math.PI) dYaw += Math.PI * 2;
      const yawRate = dYaw / Math.max(0.001, dt);

      // Smoothly damped locomotion, sprint, aim, strafe, forward & landing weights (zero snapping!)
      const speedNorm = THREE.MathUtils.clamp(actualSpeed / 7.4, 0, 1.5);
      const isMoving = actualSpeed > 0.25;
      this.heroWalkWeight = THREE.MathUtils.damp(
        this.heroWalkWeight,
        isMoving ? Math.min(1, speedNorm * 1.16) : 0,
        12.0,
        dt,
      );
      this.heroSprintWeight = THREE.MathUtils.damp(
        this.heroSprintWeight,
        isSprinting && speedNorm > 0.82 ? 1 : 0,
        7.5,
        dt,
      );
      this.camSprintBlend = THREE.MathUtils.damp(
        this.camSprintBlend,
        isSprinting && speedNorm > 0.78 ? 1 : 0,
        6.5,
        dt,
      );
      this.heroAimWeight = THREE.MathUtils.damp(
        this.heroAimWeight,
        isCombatLock ? 1 : 0,
        14.5,
        dt,
      );
      this.heroLandingCrouch = THREE.MathUtils.damp(this.heroLandingCrouch, 0, 9.5, dt);
      this.heroTurnLean = THREE.MathUtils.damp(
        this.heroTurnLean,
        THREE.MathUtils.clamp(yawRate * 0.032, -0.14, 0.14),
        10,
        dt,
      );
      this.heroStrafeBlend = THREE.MathUtils.damp(
        this.heroStrafeBlend,
        THREE.MathUtils.clamp(localVelX / 7.2, -1, 1),
        11,
        dt,
      );
      this.heroForwardBlend = THREE.MathUtils.damp(
        this.heroForwardBlend,
        THREE.MathUtils.clamp(localVelZ / 7.4, -1, 1.45),
        11,
        dt,
      );
      this.heroAimPitch = THREE.MathUtils.damp(
        this.heroAimPitch,
        THREE.MathUtils.clamp(this.camPitch - this.camRecoilPitch, -0.45, 0.55),
        16,
        dt,
      );

      // Dynamic reticle spread: settles toward movement/stance floor while firing kicks bloom outward
      const baseReticleSpread = this.scopeActive
        ? 0.04 + speedNorm * 0.12
        : 0.08 + speedNorm * 0.28 + this.heroSprintWeight * 0.26 + this.heroLandingCrouch * 0.18;
      this.reticleSpread = THREE.MathUtils.damp(
        this.reticleSpread,
        Math.min(1.0, baseReticleSpread),
        this.scopeActive ? 12 : 9.5,
        dt,
      );

      // Advance biomechanical gait phase proportionally to actual ground speed (reverses smoothly when backpedaling)
      const strideDir = this.heroForwardBlend < -0.18 ? -1 : 1;
      if (this.heroWalkWeight > 0.02) {
        const cadence = 6.0 + actualSpeed * 0.64;
        this.heroWalkPhase += dt * cadence * strideDir;
      }

      const w = this.heroWalkWeight;
      const sp = this.heroSprintWeight;
      const aim = this.heroAimWeight;
      const crouch = this.heroLandingCrouch;
      const strafeMag = Math.abs(this.heroStrafeBlend);
      const aimBrace = aim * (1 - sp * 0.8);

      // Biomechanical lower-body gait: hip swing, swing-phase knee clearance, lateral strafe abduction & tactical combat stance
      const strideAmp = (0.5 + sp * 0.24) * (1 - aim * 0.18) * (1 - strafeMag * 0.18);
      const sinP = Math.sin(this.heroWalkPhase);
      const cosP = Math.cos(this.heroWalkPhase);
      const lSwingLift = Math.max(0, Math.sin(this.heroWalkPhase + 0.88));
      const rSwingLift = Math.max(0, -Math.sin(this.heroWalkPhase + 0.88));
      const lStanceFlex = Math.max(0, -Math.sin(this.heroWalkPhase - 0.25)) * 0.14;
      const rStanceFlex = Math.max(0, Math.sin(this.heroWalkPhase - 0.25)) * 0.14;

      const lHipTarget =
        THREE.MathUtils.lerp(-0.04 - aimBrace * 0.06, sinP * strideAmp, w) - crouch * 0.42;
      const rHipTarget =
        THREE.MathUtils.lerp(0.05 + aimBrace * 0.05, -sinP * strideAmp, w) - crouch * 0.36;
      const strafeSplay = this.heroStrafeBlend * aim * w;
      const lHipRollTarget = THREE.MathUtils.clamp(
        0.03 * aimBrace + sinP * 0.16 * strafeSplay + Math.max(0, -strafeSplay) * 0.08,
        -0.22,
        0.24,
      );
      const rHipRollTarget = THREE.MathUtils.clamp(
        -0.03 * aimBrace - sinP * 0.16 * strafeSplay - Math.max(0, strafeSplay) * 0.08,
        -0.24,
        0.22,
      );
      const lKneeTarget =
        THREE.MathUtils.lerp(0.075 + aimBrace * 0.12, lSwingLift * (0.74 + sp * 0.32) + lStanceFlex + 0.07 + aimBrace * 0.06, w) +
        crouch * 0.78;
      const rKneeTarget =
        THREE.MathUtils.lerp(0.055 + aimBrace * 0.11, rSwingLift * (0.74 + sp * 0.32) + rStanceFlex + 0.07 + aimBrace * 0.06, w) +
        crouch * 0.72;
      const lAnkleTarget =
        THREE.MathUtils.lerp(-0.03 - aimBrace * 0.05, Math.sin(this.heroWalkPhase - 0.32) * (0.28 + sp * 0.14), w) -
        crouch * 0.32;
      const rAnkleTarget =
        THREE.MathUtils.lerp(-0.05 - aimBrace * 0.05, -Math.sin(this.heroWalkPhase - 0.32) * (0.28 + sp * 0.14), w) -
        crouch * 0.28;

      this.hero.leftLeg.rotation.x = THREE.MathUtils.damp(this.hero.leftLeg.rotation.x, lHipTarget, 18, dt);
      this.hero.leftLeg.rotation.z = THREE.MathUtils.damp(this.hero.leftLeg.rotation.z, lHipRollTarget, 14, dt);
      this.hero.rightLeg.rotation.x = THREE.MathUtils.damp(this.hero.rightLeg.rotation.x, rHipTarget, 18, dt);
      this.hero.rightLeg.rotation.z = THREE.MathUtils.damp(this.hero.rightLeg.rotation.z, rHipRollTarget, 14, dt);
      this.hero.leftKnee.rotation.x = THREE.MathUtils.damp(this.hero.leftKnee.rotation.x, lKneeTarget, 18, dt);
      this.hero.rightKnee.rotation.x = THREE.MathUtils.damp(this.hero.rightKnee.rotation.x, rKneeTarget, 18, dt);
      this.hero.leftAnkle.rotation.x = THREE.MathUtils.damp(this.hero.leftAnkle.rotation.x, lAnkleTarget, 16, dt);
      this.hero.rightAnkle.rotation.x = THREE.MathUtils.damp(this.hero.rightAnkle.rotation.x, rAnkleTarget, 16, dt);

      // Pelvis vertical double-bounce, combat-strafe hip lead, subtle lateral weight shift & landing crouch
      const pelvisYTarget =
        Math.abs(cosP) * (0.04 + sp * 0.024) * w -
        aimBrace * 0.036 -
        crouch * 0.18 +
        (1 - w) * Math.sin(this.worldTime * 2.15) * 0.003;
      const pelvisYawTarget = THREE.MathUtils.clamp(
        this.heroStrafeBlend * 0.28 * aim * w - aimBrace * 0.09,
        -0.34,
        0.34,
      );
      const pelvisRollTarget =
        sinP * (0.028 + sp * 0.018) * w +
        this.heroTurnLean * 0.35 -
        this.heroStrafeBlend * 0.045 * w +
        (1 - w) * Math.sin(this.worldTime * 0.9) * 0.008;
      this.hero.bodyGroup.position.y = THREE.MathUtils.damp(this.hero.bodyGroup.position.y, pelvisYTarget, 16, dt);
      this.hero.bodyGroup.rotation.y = THREE.MathUtils.damp(this.hero.bodyGroup.rotation.y, pelvisYawTarget, 13, dt);
      this.hero.bodyGroup.rotation.z = THREE.MathUtils.damp(this.hero.bodyGroup.rotation.z, pelvisRollTarget, 12, dt);

      // 3-second Sanjibani medicinal plant healing progression (+50 HP)
      if (this.isHealing) {
        this.healTimer -= dt;
        if (this.healTimer <= 0) {
          this.isHealing = false;
          this.sanjibaniCount = Math.max(0, this.sanjibaniCount - 1);
          this.health = Math.min(this.maxHealth, this.health + 50);
          this.audio.playHealComplete();
          this.spawnParticles(_v1.set(this.heroPos.x, 1.15, this.heroPos.z), 0x26f28a, 14, 4.0);
          this.pickupToast = 'সঞ্জীবনী গাছ: স্বাস্থ্য +৫০';
          this.pickupToastTimer = 2.0;
        }
      }

      // Reloading & firing
      if (this.virtualInput.reloadJustPressed) {
        this.virtualInput.reloadJustPressed = false;
        this.attemptStartReload();
      }
      if (this.isReloading) {
        this.reloadTimer -= dt;
        if (this.reloadTimer <= 0) {
          const slot = this.weaponSlots[this.weaponType];
          const needed = slot.maxAmmo - slot.ammo;
          const load = Math.min(needed, slot.reserve);
          slot.ammo += load;
          slot.reserve -= load;
          this.isReloading = false;
        }
      }

      this.fireCooldown = Math.max(0, this.fireCooldown - dt);
      if (isShooting) {
        this.firePlayerWeapon();
      }

      // Weapon recoil, Banglar Fala melee slash swing, reload & healing upper-body kinematics
      this.heroRecoil = THREE.MathUtils.damp(this.heroRecoil, 0, 14.5, dt);
      if (this.heroRecoil < 0.002) this.heroRecoil = 0;

      let slashActive = false;
      let slashSwing = 0;
      let slashTorsoYaw = 0;
      let slashT = 0;
      if (this.meleeSlashTimer > 0) {
        slashActive = true;
        this.meleeSlashTimer = Math.max(0, this.meleeSlashTimer - dt);
        slashT = 1 - this.meleeSlashTimer / 0.24;
        slashSwing = Math.sin(slashT * Math.PI);
        slashTorsoYaw = (0.5 - slashT) * 0.56;
      }

      const breathSpeed = 2.2 + sp * 2.4 + w * 0.8;
      const breathVal = Math.sin(this.worldTime * breathSpeed);
      const sprintRelax = sp * (1 - aim * 0.85) * (slashActive ? 0 : 1);

      // Lumbar upper-body articulation: counter-rotates cleanly against strafe hips to keep rifle locked on target
      const spinePitchTarget =
        0.045 * w +
        0.15 * sprintRelax +
        aimBrace * 0.045 +
        crouch * 0.2 +
        this.heroAimPitch * (0.18 + 0.26 * aim) -
        this.heroRecoil * 0.085 +
        (this.isHealing ? 0.13 : 0) +
        (slashActive ? slashSwing * 0.16 : 0) +
        breathVal * 0.011 * (1 - aim * 0.65);
      const spineYawTarget =
        -this.hero.bodyGroup.rotation.y * (0.85 * aim + 0.25) -
        sinP * (0.1 + sp * 0.07) * w * (1 - aim * 0.78) +
        slashTorsoYaw +
        (this.isReloading ? -0.1 : 0);
      const spineRollTarget =
        this.heroTurnLean * 0.65 -
        this.heroStrafeBlend * (0.065 + aim * 0.03) * w +
        (slashActive ? -slashSwing * 0.09 : 0);

      this.hero.upperBodyGroup.position.y = THREE.MathUtils.damp(
        this.hero.upperBodyGroup.position.y,
        0.94 + breathVal * (0.007 + sp * 0.004),
        14,
        dt,
      );
      this.hero.upperBodyGroup.rotation.x = THREE.MathUtils.damp(
        this.hero.upperBodyGroup.rotation.x,
        spinePitchTarget,
        15,
        dt,
      );
      this.hero.upperBodyGroup.rotation.y = THREE.MathUtils.damp(
        this.hero.upperBodyGroup.rotation.y,
        spineYawTarget,
        16,
        dt,
      );
      this.hero.upperBodyGroup.rotation.z = THREE.MathUtils.damp(
        this.hero.upperBodyGroup.rotation.z,
        spineRollTarget,
        13,
        dt,
      );

      // Vestibulo-ocular head stabilization (counter-rotates against torso twist & tracks aim pitch cleanly)
      const headYawTarget =
        -(this.hero.upperBodyGroup.rotation.y + this.hero.bodyGroup.rotation.y) * 0.7 +
        THREE.MathUtils.clamp(yawDiff * 0.22, -0.25, 0.25) +
        (1 - w) * (1 - aim) * Math.sin(this.worldTime * 0.78) * 0.06;
      const headPitchTarget =
        -this.hero.upperBodyGroup.rotation.x * 0.55 +
        this.heroAimPitch * 0.44 +
        (this.isHealing ? 0.12 : 0);
      const headRollTarget = -this.hero.upperBodyGroup.rotation.z * 0.45;
      this.hero.headGroup.rotation.x = THREE.MathUtils.damp(this.hero.headGroup.rotation.x, headPitchTarget, 16, dt);
      this.hero.headGroup.rotation.y = THREE.MathUtils.damp(this.hero.headGroup.rotation.y, headYawTarget, 16, dt);
      this.hero.headGroup.rotation.z = THREE.MathUtils.damp(this.hero.headGroup.rotation.z, headRollTarget, 14, dt);

      // Subtle wind & gait flutter on front swept hair tuft + lower kurta hem + natural eye blinking
      this.hero.hairTuft.rotation.x = THREE.MathUtils.damp(
        this.hero.hairTuft.rotation.x,
        -speedNorm * 0.065 + Math.sin(this.worldTime * (4.2 + actualSpeed * 0.6)) * (0.022 + speedNorm * 0.03),
        14,
        dt,
      );
      this.hero.hairTuft.rotation.z = THREE.MathUtils.damp(
        this.hero.hairTuft.rotation.z,
        -this.heroTurnLean * 0.5 + Math.cos(this.worldTime * 3.4) * 0.025,
        12,
        dt,
      );
      this.hero.kurtaHem.rotation.x = THREE.MathUtils.damp(
        this.hero.kurtaHem.rotation.x,
        0.04 + speedNorm * 0.095 + Math.abs(sinP) * 0.045 * w,
        14,
        dt,
      );
      this.hero.kurtaHem.rotation.z = THREE.MathUtils.damp(
        this.hero.kurtaHem.rotation.z,
        sinP * 0.055 * w - this.heroTurnLean * 0.45,
        14,
        dt,
      );
      this.updateHeroBlink(dt);

      // Smooth weapon & arm kinematics (figure-8 walk bob, tactical sprint carry, ADS raise, recoil kick, reload dip)
      const fig8X = Math.sin(this.heroWalkPhase) * (0.012 + sp * 0.014) * w * (1 - aim * 0.72);
      const fig8Y = Math.abs(cosP) * (0.012 + sp * 0.012) * w * (1 - aim * 0.74) + breathVal * 0.004;

      if (slashActive) {
        this.hero.recoilGroup.position.set(0.115 - slashSwing * 0.04, 0.31 + slashSwing * 0.035, 0.27 + slashSwing * 0.26);
        this.hero.recoilGroup.rotation.set(-slashSwing * 0.42, (slashT - 0.5) * -1.45, -slashSwing * 0.28);
        this.hero.rightArm.position.set(0, slashSwing * 0.022, slashSwing * 0.042);
        this.hero.leftArm.position.set(0, -slashSwing * 0.01, -slashSwing * 0.02);
      } else {
        const reloadProgress = this.isReloading
          ? THREE.MathUtils.clamp(1 - this.reloadTimer / Math.max(0.01, this.reloadDuration), 0, 1)
          : 0;
        const reloadDip = this.isReloading ? Math.sin(reloadProgress * Math.PI) : 0;

        const targetWeaponX = 0.115 + fig8X - sprintRelax * 0.036 - reloadDip * 0.02;
        const targetWeaponY =
          0.31 + fig8Y + aim * 0.034 - sprintRelax * 0.042 - reloadDip * 0.055 - (this.isHealing ? 0.05 : 0);
        const targetWeaponZ =
          0.27 - this.heroRecoil * 0.088 + aim * 0.024 - sprintRelax * 0.028;
        const targetWeaponPitch =
          -this.heroRecoil * 0.18 +
          this.heroAimPitch * 0.26 * aim +
          sprintRelax * 0.18 +
          reloadDip * 0.28 +
          (this.isHealing ? 0.26 : 0);
        const targetWeaponYaw =
          -sprintRelax * 0.3 - (this.isHealing ? 0.24 : 0) + reloadDip * 0.16;
        const targetWeaponRoll = reloadDip * 0.36 + sprintRelax * 0.15;

        this.hero.recoilGroup.position.x = THREE.MathUtils.damp(this.hero.recoilGroup.position.x, targetWeaponX, 18, dt);
        this.hero.recoilGroup.position.y = THREE.MathUtils.damp(this.hero.recoilGroup.position.y, targetWeaponY, 18, dt);
        this.hero.recoilGroup.position.z = THREE.MathUtils.damp(this.hero.recoilGroup.position.z, targetWeaponZ, 24, dt);
        this.hero.recoilGroup.rotation.x = THREE.MathUtils.damp(this.hero.recoilGroup.rotation.x, targetWeaponPitch, 20, dt);
        this.hero.recoilGroup.rotation.y = THREE.MathUtils.damp(this.hero.recoilGroup.rotation.y, targetWeaponYaw, 16, dt);
        this.hero.recoilGroup.rotation.z = THREE.MathUtils.damp(this.hero.recoilGroup.rotation.z, targetWeaponRoll, 16, dt);

        // Subtle synchronized arm micro-follow so hands stay seated on weapon through recoil & stride
        const armRecoilZ = -this.heroRecoil * 0.038;
        const armFollowY = fig8Y * 0.65 + aim * 0.016 - reloadDip * 0.025;
        this.hero.leftArm.position.x = THREE.MathUtils.damp(this.hero.leftArm.position.x, fig8X * 0.5, 16, dt);
        this.hero.leftArm.position.y = THREE.MathUtils.damp(this.hero.leftArm.position.y, armFollowY - reloadDip * 0.02, 16, dt);
        this.hero.leftArm.position.z = THREE.MathUtils.damp(this.hero.leftArm.position.z, armRecoilZ - reloadDip * 0.028, 20, dt);
        this.hero.rightArm.position.x = THREE.MathUtils.damp(this.hero.rightArm.position.x, fig8X * 0.45, 16, dt);
        this.hero.rightArm.position.y = THREE.MathUtils.damp(this.hero.rightArm.position.y, armFollowY, 16, dt);
        this.hero.rightArm.position.z = THREE.MathUtils.damp(this.hero.rightArm.position.z, armRecoilZ, 22, dt);
      }

      this.hero.updateGamchaCloth(
        dt,
        this.worldTime,
        localVelX,
        0,
        localVelZ,
        yawRate,
        isSprinting ? 0.95 : moveLen > 0.1 ? 0.45 : 0.18,
      );

      if (this.muzzleFlashTimer > 0) {
        this.muzzleFlashTimer -= dt;
        this.hero.muzzleFlash.visible = true;
        this.hero.muzzleFlash.rotation.z = Math.random() * Math.PI * 2;
        this.hero.muzzleLight.intensity = 5.0;
      } else {
        this.hero.muzzleFlash.visible = false;
        this.hero.muzzleLight.intensity = 0;
      }
    }

    // Live directional incoming-damage indicator angle relative to current camera orientation
    if (this.hasDamageSource && this.damageFlash > 0.02) {
      const dmgDx = this.damageSourcePos.x - this.heroPos.x;
      const dmgDz = this.damageSourcePos.z - this.heroPos.z;
      const dotFwd = dmgDx * fwdX + dmgDz * fwdZ;
      const dotRight = dmgDx * rightX + dmgDz * rightZ;
      this.damageAngle = Math.atan2(dotRight, dotFwd);
    }

    // Keep shadow frustum centered around active subject (bus or hero)
    const focusPos = this.busMode !== 'none' ? this.busPos : this.heroPos;
    this.sunLight.position.set(focusPos.x + 32, 56, focusPos.z - 26);
    this.sunLight.target.position.copy(focusPos);

    // Wave spawning & progression (pause wave auto-advance while Wave 1 intro bus is still dropping enemies)
    if (!this.busAutoDriving || this.wave > 1) {
      this.updateWaves(dt);
    }

    // Update Battle Royale systems: enemies, bullets, pickups, Warrior Chests, Bajra Gola grenades,
    // floating 3D damage numbers, Kalboishakhi storm safe zone, particles & 3D impact burst rings
    this.updateEnemies(dt);
    this.updateBullets(dt);
    this.updatePickups(dt);
    this.updateChests(dt);
    this.updateGrenades(dt);
    this.updateFloatingDamages(dt);
    this.updateKalboishakhiStorm(dt);
    this.updateParticles(dt);
    this.updateImpactFlashes(dt);

    // --- 3. Camera Rig (Bus Interior Cabin View / Bus Exterior Chase / Driving / Third-Person Shooter) ---
    if (this.busMode === 'riding_intro') {
      if (this.busInteriorCam) {
        // Realistic Bus Interior View: positioned inside the aisle looking forward past seated rivals,
        // overhead grab rails, driver cabin, and clear panoramic windows over the Howrah Bridge & landmarks
        this.bus.interior.interiorCamPos.getWorldPosition(_camDesired);
        _camDesired.y += Math.sin(this.worldTime * 15) * 0.008;

        this.bus.interior.interiorCamLook.getWorldPosition(_lookAtPt);
        if (Math.abs(this.busInteriorLookYaw) > 0.001) {
          const lx = _lookAtPt.x - _camDesired.x;
          const lz = _lookAtPt.z - _camDesired.z;
          const cosG = Math.cos(this.busInteriorLookYaw);
          const sinG = Math.sin(this.busInteriorLookYaw);
          _lookAtPt.x = _camDesired.x + lx * cosG + lz * sinG;
          _lookAtPt.z = _camDesired.z - lx * sinG + lz * cosG;
        }
      } else {
        // Exterior View toggle: sweeping side-rear chase camera showing the WBTC bus & Howrah Bridge
        const bFwdX = Math.sin(this.busYaw);
        const bFwdZ = Math.cos(this.busYaw);
        const bRightX = -bFwdZ;
        const bRightZ = bFwdX;

        _camDesired.set(
          this.busPos.x - bFwdX * 11.5 - bRightX * 4.8,
          this.busPos.y + 5.1,
          this.busPos.z - bFwdZ * 11.5 - bRightZ * 4.8,
        );
        _lookAtPt.set(
          this.busPos.x + bFwdX * 3.5,
          this.busPos.y + 1.8,
          this.busPos.z + bFwdZ * 3.5,
        );
      }
    } else if (this.busMode === 'driving') {
      // Responsive vehicle chase camera behind the player-driven WBTC bus
      const bFwdX = Math.sin(this.busYaw);
      const bFwdZ = Math.cos(this.busYaw);
      _camDesired.set(
        this.busPos.x - bFwdX * 12.2,
        this.busPos.y + 5.2,
        this.busPos.z - bFwdZ * 12.2,
      );
      _lookAtPt.set(
        this.busPos.x + bFwdX * 5.0,
        this.busPos.y + 1.8,
        this.busPos.z + bFwdZ * 5.0,
      );
    } else {
      // Tactical Third-Person Shooter Camera (PUBG Mobile / Free Fire MAX scale & over-shoulder presence)
      const effYaw = this.camYaw + this.camRecoilYaw;
      const effPitch = THREE.MathUtils.clamp(this.camPitch - this.camRecoilPitch, -0.24, 0.72);
      const effFwdX = Math.sin(effYaw);
      const effFwdZ = Math.cos(effYaw);
      const effRightX = -effFwdZ;
      const effRightZ = effFwdX;

      const combatZoom = this.heroAimWeight * (this.scopeActive ? 0 : 1);
      const gaitSwayX =
        Math.sin(this.heroWalkPhase) * 0.022 * this.heroWalkWeight * (1 - this.heroAimWeight * 0.7);
      const gaitSwayY =
        Math.abs(Math.cos(this.heroWalkPhase)) * 0.024 * this.heroWalkWeight * (1 - this.heroAimWeight * 0.72);

      if (this.scopeActive && this.weaponType === 'trishul') {
        // Crisp over-shoulder Trishul Sniper 4x optic alignment
        _camDesired.set(
          this.heroPos.x - effFwdX * 1.1 + effRightX * 0.4,
          this.heroPos.y + 1.68,
          this.heroPos.z - effFwdZ * 1.1 + effRightZ * 0.4,
        );
        _lookAtPt.set(
          this.heroPos.x + effFwdX * 38 + effRightX * 0.22,
          this.heroPos.y + 1.68 - effPitch * 15.5,
          this.heroPos.z + effFwdZ * 38 + effRightZ * 0.22,
        );
      } else if (this.scopeActive) {
        // Tight Tactical Over-Shoulder ADS Zoom-In (জুম ইন) for Agni-47 / Kalbhairav
        const camDist = 2.25;
        const shoulderRight = 0.56;
        const camHeight = 1.76 + effPitch * 1.15;
        _camDesired.set(
          this.heroPos.x - effFwdX * camDist + effRightX * shoulderRight,
          this.heroPos.y + camHeight,
          this.heroPos.z - effFwdZ * camDist + effRightZ * shoulderRight,
        );
        _camDesired.y = Math.max(this.heroPos.y + 1.28, _camDesired.y);

        _lookAtPt.set(
          this.heroPos.x + effFwdX * 28 + effRightX * 0.26,
          this.heroPos.y + 1.58 - effPitch * 9.5,
          this.heroPos.z + effFwdZ * 28 + effRightZ * 0.26,
        );
      } else {
        // Tighter, eye-level Over-the-Shoulder Camera so hero & human enemies command clear screen scale
        const pinchZoomRatio = THREE.MathUtils.clamp(-this.pinchFovOffset / 24, 0, 1);
        const camDist =
          THREE.MathUtils.lerp(4.25, 2.85, pinchZoomRatio) +
          this.camSprintBlend * 0.36 -
          combatZoom * 0.24;
        const shoulderRight =
          THREE.MathUtils.lerp(0.74, 0.58, pinchZoomRatio) - combatZoom * 0.05 + gaitSwayX;
        const camHeight =
          THREE.MathUtils.lerp(1.98, 1.78, pinchZoomRatio) +
          effPitch * 1.85 +
          gaitSwayY -
          combatZoom * 0.05;
        _camDesired.set(
          this.heroPos.x - effFwdX * camDist + effRightX * shoulderRight,
          this.heroPos.y + camHeight,
          this.heroPos.z - effFwdZ * camDist + effRightZ * shoulderRight,
        );
        _camDesired.y = Math.max(this.heroPos.y + 1.22, _camDesired.y);

        _lookAtPt.set(
          this.heroPos.x + effFwdX * 20 + effRightX * 0.34,
          this.heroPos.y + 1.55 - effPitch * 5.8,
          this.heroPos.z + effFwdZ * 20 + effRightZ * 0.34,
        );
      }

      // Smooth camera obstacle pullback so walls, houses, trees, or bus hull never block the view
      if (!(this.scopeActive && this.weaponType === 'trishul')) {
        _v1.set(
          this.heroPos.x + effRightX * 0.36,
          this.heroPos.y + 1.62,
          this.heroPos.z + effRightZ * 0.36,
        );
        const camObsT = this.segmentFirstObstacleT(_v1, _camDesired, true);
        if (camObsT < 1) {
          const safeT = Math.max(0.28, camObsT - 0.14);
          _camDesired.lerpVectors(_v1, _camDesired, safeT);
        }
      }
    }

    // Smoothly damp camera FOV (bus cabin 68°, Trishul 4x 22°, Tactical OTS ADS 44°, Normal 68° + sprint/combat dynamics)
    const combatFovPull = this.busMode === 'none' && !this.scopeActive ? this.heroAimWeight * 2.6 : 0;
    const sprintFovBoost = this.busMode === 'none' && !this.scopeActive ? this.camSprintBlend * 3.8 : 0;
    const baseFov =
      this.busMode === 'riding_intro' && this.busInteriorCam
        ? 68
        : this.busMode === 'none' && this.scopeActive
          ? this.weaponType === 'trishul'
            ? 22
            : 44
          : 68 + sprintFovBoost - combatFovPull;
    const targetFov =
      this.busMode === 'none'
        ? THREE.MathUtils.clamp(baseFov + this.pinchFovOffset, 22, 76)
        : baseFov;
    if (Math.abs(this.currentFov - targetFov) > 0.05) {
      this.currentFov += (targetFov - this.currentFov) * (1 - Math.exp(-13 * dt));
      this.camera.fov = this.currentFov;
      this.camera.updateProjectionMatrix();
    }

    if (this.introTransitionProgress < 1) {
      this.introTransitionProgress = Math.min(
        1,
        this.introTransitionProgress + dt / this.introTransitionDuration,
      );
      const t = this.introTransitionProgress;
      const ease = t * t * (3 - 2 * t);

      this.camera.position.lerpVectors(this.introStartCamPos, _camDesired, ease);
      if (!(this.busMode === 'riding_intro' && this.busInteriorCam)) {
        this.camera.position.y += Math.sin(ease * Math.PI) * 2.4;
      }
      _camTarget.lerpVectors(this.introStartLookAt, _lookAtPt, ease);
      this.camera.lookAt(_camTarget);
    } else {
      const inBusCabin = this.busMode === 'riding_intro' && this.busInteriorCam;
      const posRate = inBusCabin ? 28 : this.busMode !== 'none' ? 6.5 : this.scopeActive ? 21 : 15;
      const lookRate = inBusCabin ? 26 : this.scopeActive ? 25 : 18;
      const camDamp = 1 - Math.exp(-posRate * dt);
      this.camera.position.lerp(_camDesired, camDamp);

      if (this.camShake > 0.005) {
        this.camera.position.x += (Math.random() - 0.5) * this.camShake;
        this.camera.position.y += (Math.random() - 0.5) * this.camShake;
      }

      _camTarget.lerp(_lookAtPt, 1 - Math.exp(-lookRate * dt));
      this.camera.lookAt(_camTarget);
    }
  }

  private dropEnemyFromBus(e: ActiveEnemy): void {
    const prevSeat = e.busSeatIndex;
    e.busSeatIndex = -1;
    e.rig.telegraphGlow.visible = false;
    e.telegraphTimer = 0;

    // Swing side passenger door briefly open and launch rival warrior cleanly from the doorway
    this.busDoorAutoHoldTimer = Math.max(this.busDoorAutoHoldTimer, 0.72);
    this.bus.interior.heroDoorwayAnchor.getWorldPosition(e.jumpStart);

    // Spread slightly along the road so multiple exiting bots never stack or clip inside bus
    const sideSign = 1;
    const spread = ((prevSeat % 3) - 1) * 1.15;
    this.findSafeBusExitPosition(e.jumpEnd, e.radius + 0.2, sideSign, spread, true);

    e.jumpPeakY = Math.max(e.jumpStart.y, e.jumpEnd.y) + 0.42;
    e.jumpDuration = Math.abs(e.jumpStart.y - e.jumpEnd.y) > 1.8 ? 0.42 : 0.28;
    e.jumpProgress = 0;
    e.jumpingFromBus = true;
    // Full 2.0-second safe phase begins AFTER landing cleanly on the ground!
    e.postLandingSafeTimer = 2.0;
  }

  private updateWaves(dt: number): void {
    const aliveEnemies = this.enemies.filter((e) => !e.dying).length;

    if (this.waveEnemiesToSpawn.length > 0) {
      const maxSimultaneous = Math.min(8, 3 + this.wave);
      if (aliveEnemies < maxSimultaneous) {
        this.waveSpawnTimer -= dt;
        if (this.waveSpawnTimer <= 0) {
          const next = this.waveEnemiesToSpawn.shift()!;
          this.spawnEnemy(next);
          this.waveSpawnTimer = Math.max(0.7, 1.85 - this.wave * 0.12);
        }
      }
    } else if (aliveEnemies === 0) {
      if (this.waveBreakTimer <= 0) {
        this.waveBreakTimer = 2.5;
        this.waveBanner = `তরঙ্গ ${toBengaliNumber(this.wave)} সম্পূর্ণ!`;
        this.waveBannerTimer = 2.2;
        this.score += 150 * this.wave;
        this.checkHighScore();
      } else {
        this.waveBreakTimer -= dt;
        if (this.waveBreakTimer <= 0) {
          this.beginWave(this.wave + 1);
        }
      }
    }
  }

  private updateEnemies(dt: number): void {
    const playerProtectedInBus = this.busMode !== 'none' || this.heroJumpingFromBus;

    for (let i = this.enemies.length - 1; i >= 0; i--) {
      const e = this.enemies[i];

      // Natural eye blinking for every human fighter
      if (!e.dying) {
        if (e.blinkPhase > 0) {
          e.blinkPhase += dt / 0.16;
          if (e.blinkPhase >= 1) {
            e.blinkPhase = 0;
            e.rig.setBlink(0);
          } else {
            e.rig.setBlink(Math.pow(Math.sin(e.blinkPhase * Math.PI), 0.85));
          }
        } else {
          e.blinkTimer -= dt;
          if (e.blinkTimer <= 0) {
            e.blinkPhase = 0.001;
            e.blinkTimer = 2.4 + Math.random() * 3.4;
          }
        }
      }

      // Enemies currently seated inside the WBTC bus cabin never aim, shoot, or move independently
      if (e.busSeatIndex >= 0) {
        e.rig.telegraphGlow.visible = false;
        e.telegraphTimer = 0;
        e.rig.leftLeg.rotation.x = -1.15;
        e.rig.rightLeg.rotation.x = -1.15;
        e.rig.leftKnee.rotation.x = 1.15;
        e.rig.rightKnee.rotation.x = 1.15;
        e.rig.leftAnkle.rotation.x = 0.08;
        e.rig.rightAnkle.rotation.x = 0.08;
        e.rig.upperBodyGroup.position.y = 0.94 + Math.sin(this.worldTime * 2.1 + e.id) * 0.006;
        e.rig.upperBodyGroup.rotation.set(0.03, Math.sin(this.worldTime * 0.6 + e.id) * 0.05, 0);
        e.rig.headGroup.rotation.set(0, Math.sin(this.worldTime * 0.9 + e.id * 1.4) * 0.18, 0);
        e.rig.updateCloth(dt, this.worldTime, this.busSpeed * 0.25, 0, 0.36);
        continue;
      }

      if (e.dying) {
        e.deathTimer += dt;
        const t = Math.min(1, e.deathTimer / 0.44);
        const easeOut = 1 - Math.pow(1 - t, 3);
        const buckle = Math.sin(Math.min(1, e.deathTimer / 0.24) * Math.PI * 0.5);
        // Natural buckling-knee staggered collapse instead of rigid plank tilt
        e.rig.leftKnee.rotation.x = THREE.MathUtils.lerp(e.rig.leftKnee.rotation.x, 1.05 * buckle, Math.min(1, dt * 14));
        e.rig.rightKnee.rotation.x = THREE.MathUtils.lerp(e.rig.rightKnee.rotation.x, 0.72 * buckle, Math.min(1, dt * 14));
        e.rig.leftLeg.rotation.x = THREE.MathUtils.lerp(e.rig.leftLeg.rotation.x, -0.45 * buckle, Math.min(1, dt * 14));
        e.rig.rightLeg.rotation.x = THREE.MathUtils.lerp(e.rig.rightLeg.rotation.x, -0.22 * buckle, Math.min(1, dt * 14));
        e.rig.upperBodyGroup.rotation.x = easeOut * 0.34;
        e.rig.upperBodyGroup.rotation.z = easeOut * 0.22 * e.deathSide;
        e.rig.bodyGroup.rotation.x = -Math.PI * 0.47 * easeOut;
        e.rig.bodyGroup.rotation.z = 0.18 * e.deathSide * easeOut;
        e.rig.bodyGroup.position.y = -0.18 * easeOut;
        e.rig.setBlink(1);
        e.rig.updateCloth(dt, this.worldTime, 0, 0, 0.08);
        e.rig.hpBarBg.visible = false;
        e.rig.telegraphGlow.visible = false;
        if (e.deathTimer > 1.15) {
          this.scene.remove(e.rig.root);
          this.enemies.splice(i, 1);
        }
        continue;
      }

      // Direct grounded hop from open bus side door onto bridge/road before entering combat
      if (e.jumpingFromBus) {
        e.jumpProgress = Math.min(1, e.jumpProgress + dt / e.jumpDuration);
        const t = e.jumpProgress;
        e.rig.root.position.lerpVectors(e.jumpStart, e.jumpEnd, t);
        const arc = 4 * t * (1 - t);
        const baseY = THREE.MathUtils.lerp(e.jumpStart.y, e.jumpEnd.y, t);
        const lift = Math.max(0.18, e.jumpPeakY - (e.jumpStart.y + e.jumpEnd.y) * 0.5);
        e.rig.root.position.y = baseY + arc * lift;
        e.rig.leftLeg.rotation.x = THREE.MathUtils.damp(e.rig.leftLeg.rotation.x, -0.42, 14, dt);
        e.rig.rightLeg.rotation.x = THREE.MathUtils.damp(e.rig.rightLeg.rotation.x, 0.32, 14, dt);
        e.rig.leftKnee.rotation.x = THREE.MathUtils.damp(e.rig.leftKnee.rotation.x, 0.58, 14, dt);
        e.rig.rightKnee.rotation.x = THREE.MathUtils.damp(e.rig.rightKnee.rotation.x, 0.34, 14, dt);
        e.rig.leftAnkle.rotation.x = 0.2;
        e.rig.rightAnkle.rotation.x = 0.25;
        e.rig.upperBodyGroup.rotation.x = THREE.MathUtils.damp(e.rig.upperBodyGroup.rotation.x, 0.18, 12, dt);
        e.rig.updateCloth(dt, this.worldTime, 4.2, 0, 0.85);
        e.rig.telegraphGlow.visible = false;
        e.telegraphTimer = 0;

        if (e.jumpProgress >= 1) {
          e.jumpingFromBus = false;
          this.resolveCircleWorldCollision(e.rig.root.position, e.radius, true);
          e.rig.root.position.y = this.world.getGroundHeight(
            e.rig.root.position.x,
            e.rig.root.position.z,
            e.jumpEnd.y,
          );
          e.landingCrouch = 1.0;
          e.prevYaw = e.rig.root.rotation.y;
          e.postLandingSafeTimer = 2.0; // Strictly 2 seconds after landing on ground before aiming/shooting
          this.spawnParticles(e.rig.root.position, 0xd8a872, 7, 3.6);
        }
        continue;
      }

      // Keep grounded enemies cleanly seated on laterite hills, bridge ramps, and courtyard floors
      e.rig.root.position.y = this.world.getGroundHeight(
        e.rig.root.position.x,
        e.rig.root.position.z,
        e.rig.root.position.y,
      );

      // Count down 2-second post-landing safe timer
      if (e.postLandingSafeTimer > 0) {
        e.postLandingSafeTimer = Math.max(0, e.postLandingSafeTimer - dt);
      }

      // Hit flash & flinch recovery
      if (e.flinchTimer > 0) {
        e.flinchTimer = Math.max(0, e.flinchTimer - dt);
      }
      if (e.hitFlashTimer > 0) {
        e.hitFlashTimer -= dt;
        if (e.hitFlashTimer <= 0) {
          e.rig.flashMaterials.forEach((m, idx) => {
            m.emissive.copy(e.rig.baseEmissives[idx]);
          });
          e.rig.bodyGroup.scale.setScalar(this.getEnemyScale(e));
        }
      }

      // Billboard floating health bar toward camera
      if (e.rig.hpBarBg.visible) {
        e.rig.hpBarBg.lookAt(this.camera.position);
      }

      const toHeroX = this.heroPos.x - e.rig.root.position.x;
      const toHeroZ = this.heroPos.z - e.rig.root.position.z;
      const dist = Math.hypot(toHeroX, toHeroZ) || 0.001;
      const dirX = toHeroX / dist;
      const dirZ = toHeroZ / dist;

      // Check solid wall / obstacle line-of-sight before aiming or shooting
      _v5.set(e.rig.root.position.x, e.rig.root.position.y + 1.32, e.rig.root.position.z);
      _v6.set(this.heroPos.x, this.heroPos.y + 1.25, this.heroPos.z);
      const hasLOS = !playerProtectedInBus && dist <= e.fireRange && this.hasLineOfSight(_v5, _v6);

      const isRusher = e.archetype === 'rusher';
      const isHeavy = e.archetype === 'heavy';
      const desiredRange = isRusher ? 6.2 : isHeavy ? 11.8 : 14.0;

      e.strafeTimer -= dt;
      if (e.strafeTimer <= 0) {
        e.strafeDir = -e.strafeDir;
        e.strafeTimer = 1.4 + Math.random() * 1.9;
      }

      // Tactical state transitions: advance -> seek nearby cover -> hold/peek cover -> flank
      e.tacticTimer -= dt;
      if (!playerProtectedInBus && e.postLandingSafeTimer <= 0) {
        if (e.tacticState === 'hold_cover') {
          const distToCover = Math.hypot(
            e.coverX - e.rig.root.position.x,
            e.coverZ - e.rig.root.position.z,
          );
          if (!e.hasCoverSpot || distToCover > 3.6 || dist < 5.5 || dist > e.fireRange + 4) {
            e.hasCoverSpot = false;
            e.tacticState = isRusher ? 'flank' : 'advance';
            e.tacticTimer = 1.8 + Math.random() * 1.5;
          } else {
            e.coverPeekTimer -= dt;
            if (e.coverPeekTimer <= 0) {
              e.coverPeeking = !e.coverPeeking;
              e.coverPeekTimer = e.coverPeeking
                ? 1.5 + Math.random() * 1.2
                : 0.9 + Math.random() * 0.9;
            }
            if (e.tacticTimer <= 0) {
              e.hasCoverSpot = false;
              e.tacticState = Math.random() < 0.55 ? 'flank' : 'advance';
              e.tacticTimer = 2.2 + Math.random() * 1.8;
            }
          }
        } else if (e.tacticState === 'seek_cover') {
          if (!e.hasCoverSpot) {
            e.hasCoverSpot = this.findCoverSpotForEnemy(e);
            if (!e.hasCoverSpot) {
              e.tacticState = isRusher ? 'flank' : 'advance';
              e.tacticTimer = 1.8 + Math.random() * 1.2;
            }
          }
          if (e.hasCoverSpot) {
            const distToCover = Math.hypot(
              e.coverX - e.rig.root.position.x,
              e.coverZ - e.rig.root.position.z,
            );
            if (distToCover < 0.85) {
              e.tacticState = 'hold_cover';
              e.tacticTimer = 3.2 + Math.random() * 2.4;
              e.coverPeeking = false;
              e.coverPeekTimer = 0.65 + Math.random() * 0.55;
            } else if (e.tacticTimer <= 0) {
              e.hasCoverSpot = false;
              e.tacticState = 'flank';
              e.tacticTimer = 2.0 + Math.random() * 1.4;
            }
          }
        } else if (e.tacticTimer <= 0) {
          // Periodically pick tactical cover or flanking maneuver based on archetype & range
          const coverChance = isRusher ? 0.22 : isHeavy ? 0.55 : 0.65;
          if (dist > 7.5 && dist < e.fireRange + 6 && Math.random() < coverChance) {
            e.hasCoverSpot = this.findCoverSpotForEnemy(e);
            if (e.hasCoverSpot) {
              e.tacticState = 'seek_cover';
              e.tacticTimer = 3.2;
            } else {
              e.tacticState = Math.random() < 0.5 ? 'flank' : 'advance';
              e.tacticTimer = 2.0 + Math.random() * 1.6;
            }
          } else {
            e.tacticState = isRusher ? 'flank' : Math.random() < 0.5 ? 'flank' : 'advance';
            e.tacticTimer = 2.0 + Math.random() * 1.6;
          }
        }
      }

      const isBracingFire =
        (e.telegraphTimer > 0 || e.burstRemaining > 0) &&
        !playerProtectedInBus &&
        e.postLandingSafeTimer <= 0 &&
        hasLOS;
      const isDuckingCover =
        e.tacticState === 'hold_cover' && !e.coverPeeking && !isBracingFire;

      let moveX = 0;
      let moveZ = 0;
      let desiredSpeedScale = 1.0;

      if (playerProtectedInBus || e.postLandingSafeTimer > 0) {
        // Patrol & spread out cleanly around the village during the safe drop-in phase
        moveX += -dirZ * e.strafeDir * 0.72 + dirX * 0.28;
        moveZ += dirX * e.strafeDir * 0.72 + dirZ * 0.28;
        desiredSpeedScale = 0.88;
      } else if (e.tacticState === 'seek_cover' && e.hasCoverSpot) {
        // Sprint deliberately toward chosen cover node
        const cx = e.coverX - e.rig.root.position.x;
        const cz = e.coverZ - e.rig.root.position.z;
        const cDist = Math.hypot(cx, cz) || 0.001;
        moveX += cx / cDist;
        moveZ += cz / cDist;
        desiredSpeedScale = 1.12;
      } else if (e.tacticState === 'hold_cover' && e.hasCoverSpot) {
        if (e.coverPeeking) {
          // Step slightly to the flank edge of cover to establish clean firing line
          const peekX = e.coverX - dirZ * e.strafeDir * 1.35;
          const peekZ = e.coverZ + dirX * e.strafeDir * 1.35;
          const dx = peekX - e.rig.root.position.x;
          const dz = peekZ - e.rig.root.position.z;
          const d = Math.hypot(dx, dz);
          if (d > 0.22) {
            moveX += dx / d;
            moveZ += dz / d;
            desiredSpeedScale = isBracingFire ? 0.3 : 0.78;
          } else {
            desiredSpeedScale = 0;
          }
        } else {
          // Tuck tightly behind cover node and duck
          const dx = e.coverX - e.rig.root.position.x;
          const dz = e.coverZ - e.rig.root.position.z;
          const d = Math.hypot(dx, dz);
          if (d > 0.2) {
            moveX += dx / d;
            moveZ += dz / d;
            desiredSpeedScale = 0.75;
          } else {
            desiredSpeedScale = 0;
          }
        }
      } else if (!hasLOS) {
        // Actively flank around blocking walls/houses/taxi to gain a clean shot
        moveX += dirX * 0.62 - dirZ * e.strafeDir * 0.88;
        moveZ += dirZ * 0.62 + dirX * e.strafeDir * 0.88;
        desiredSpeedScale = isRusher ? 1.08 : 0.96;
      } else {
        // Open-ground combat movement: advance/hold optimal weapon range & plant feet when bracing shots
        if (dist > desiredRange + 1.5) {
          moveX += dirX * (e.tacticState === 'flank' ? 0.78 : 1.0);
          moveZ += dirZ * (e.tacticState === 'flank' ? 0.78 : 1.0);
        } else if (dist < desiredRange - 2.4) {
          moveX -= dirX * 0.55;
          moveZ -= dirZ * 0.55;
        }
        const strafeWeight = e.tacticState === 'flank' ? 0.82 : 0.48;
        moveX += -dirZ * e.strafeDir * strafeWeight;
        moveZ += dirX * e.strafeDir * strafeWeight;
        desiredSpeedScale = isBracingFire ? (isRusher ? 0.52 : 0.28) : 0.92;
      }

      // Soft separation between grounded enemies so they never stack
      for (let j = 0; j < this.enemies.length; j++) {
        if (i === j || this.enemies[j].dying || this.enemies[j].busSeatIndex >= 0) continue;
        const other = this.enemies[j];
        const sx = e.rig.root.position.x - other.rig.root.position.x;
        const sz = e.rig.root.position.z - other.rig.root.position.z;
        const sDistSq = sx * sx + sz * sz;
        if (sDistSq < 3.8 && sDistSq > 0.001) {
          const sDist = Math.sqrt(sDistSq);
          moveX += (sx / sDist) * 1.15;
          moveZ += (sz / sDist) * 1.15;
        }
      }

      const prevEx = e.rig.root.position.x;
      const prevEz = e.rig.root.position.z;
      const mLen = Math.hypot(moveX, moveZ);
      let targetVx = 0;
      let targetVz = 0;
      if (mLen > 0.02 && desiredSpeedScale > 0.01) {
        const invM = 1 / mLen;
        targetVx = moveX * invM * e.speed * desiredSpeedScale;
        targetVz = moveZ * invM * e.speed * desiredSpeedScale;
      }

      // Smooth damped enemy ground velocity for crisp, human acceleration/deceleration
      e.velX = THREE.MathUtils.damp(e.velX, targetVx, 8.8, dt);
      e.velZ = THREE.MathUtils.damp(e.velZ, targetVz, 8.8, dt);
      e.rig.root.position.x += e.velX * dt;
      e.rig.root.position.z += e.velZ * dt;

      // Smoothly damped facing yaw (faces travel when sprinting to cover, locks on hero during engagement)
      let targetYaw = e.rig.root.rotation.y;
      const enemyVelSpeed = Math.hypot(e.velX, e.velZ);
      if (
        (playerProtectedInBus || e.postLandingSafeTimer > 0 || e.tacticState === 'seek_cover') &&
        enemyVelSpeed > 0.65 &&
        !isBracingFire
      ) {
        targetYaw = Math.atan2(e.velX, e.velZ);
      } else {
        targetYaw = Math.atan2(dirX, dirZ);
      }
      let eYawDiff = targetYaw - e.rig.root.rotation.y;
      while (eYawDiff > Math.PI) eYawDiff -= Math.PI * 2;
      while (eYawDiff < -Math.PI) eYawDiff += Math.PI * 2;
      e.prevYaw = e.rig.root.rotation.y;
      e.rig.root.rotation.y += eYawDiff * (1 - Math.exp(-(isBracingFire ? 15.0 : 10.0) * dt));
      let eDYaw = e.rig.root.rotation.y - e.prevYaw;
      while (eDYaw > Math.PI) eDYaw -= Math.PI * 2;
      while (eDYaw < -Math.PI) eDYaw += Math.PI * 2;
      e.yawRate = THREE.MathUtils.damp(e.yawRate, eDYaw / Math.max(0.001, dt), 12, dt);

      // Apply knockback decay
      if (e.knockback.lengthSq() > 0.01) {
        e.rig.root.position.addScaledVector(e.knockback, dt);
        e.knockback.multiplyScalar(Math.exp(-10 * dt));
      }

      this.resolveCircleWorldCollision(e.rig.root.position, e.radius, true);
      e.rig.root.position.y = this.world.getGroundHeight(
        e.rig.root.position.x,
        e.rig.root.position.z,
        e.rig.root.position.y,
      );

      // Smooth biomechanical gait, cover crouch, braced combat stance, hit-flinch & cloth for enemy fighter
      const actualMoveSpeed =
        Math.hypot(e.rig.root.position.x - prevEx, e.rig.root.position.z - prevEz) / Math.max(0.001, dt);
      e.moveBlend = THREE.MathUtils.damp(
        e.moveBlend,
        actualMoveSpeed > 0.3 ? Math.min(1, actualMoveSpeed / Math.max(1, e.speed)) : 0,
        10.5,
        dt,
      );
      e.landingCrouch = THREE.MathUtils.damp(e.landingCrouch, 0, 9.5, dt);
      e.coverCrouch = THREE.MathUtils.damp(e.coverCrouch, isDuckingCover ? 1 : 0, 9.0, dt);
      e.aimBlend = THREE.MathUtils.damp(
        e.aimBlend,
        isBracingFire || (hasLOS && e.tacticState === 'hold_cover' && e.coverPeeking) ? 1 : 0,
        11.0,
        dt,
      );
      e.recoil = THREE.MathUtils.damp(e.recoil, 0, 15, dt);

      if (e.moveBlend > 0.02) {
        e.walkPhase += dt * (4.8 + actualMoveSpeed * 0.94);
      }

      const ew = e.moveBlend;
      const ec = Math.min(1, e.landingCrouch + e.coverCrouch * 0.85);
      const ea = e.aimBlend;
      const eSprinting = (isRusher || e.tacticState === 'seek_cover') && ew > 0.72 && ea < 0.35 ? 1 : 0;
      const eSin = Math.sin(e.walkPhase);
      const eCos = Math.cos(e.walkPhase);
      const eStride = (isHeavy ? 0.42 : isRusher ? 0.66 : 0.54) * (1 - ea * 0.24) * (1 - e.coverCrouch * 0.35);
      const eLeftLift = Math.max(0, Math.sin(e.walkPhase + 0.85));
      const eRightLift = Math.max(0, -Math.sin(e.walkPhase + 0.85));

      // Hit-flinch spring impulse (head snaps back on headshot; shoulder/torso jerks on body hit)
      const flinchMax = e.flinchHead ? 0.24 : 0.16;
      const flinchPulse =
        e.flinchTimer > 0 ? Math.sin((e.flinchTimer / flinchMax) * Math.PI) : 0;

      e.rig.leftLeg.rotation.x = THREE.MathUtils.damp(
        e.rig.leftLeg.rotation.x,
        THREE.MathUtils.lerp(-0.05 - ea * 0.08, eSin * eStride, ew) - ec * 0.44,
        16,
        dt,
      );
      e.rig.rightLeg.rotation.x = THREE.MathUtils.damp(
        e.rig.rightLeg.rotation.x,
        THREE.MathUtils.lerp(0.05 + ea * 0.06, -eSin * eStride, ew) - ec * 0.38,
        16,
        dt,
      );
      e.rig.leftKnee.rotation.x = THREE.MathUtils.damp(
        e.rig.leftKnee.rotation.x,
        THREE.MathUtils.lerp(0.07 + ea * 0.14, eLeftLift * (isRusher ? 0.92 : 0.74) + 0.08 + ea * 0.08, ew) +
          ec * 0.82,
        16,
        dt,
      );
      e.rig.rightKnee.rotation.x = THREE.MathUtils.damp(
        e.rig.rightKnee.rotation.x,
        THREE.MathUtils.lerp(0.05 + ea * 0.12, eRightLift * (isRusher ? 0.92 : 0.74) + 0.08 + ea * 0.08, ew) +
          ec * 0.76,
        16,
        dt,
      );
      e.rig.leftAnkle.rotation.x = THREE.MathUtils.damp(
        e.rig.leftAnkle.rotation.x,
        THREE.MathUtils.lerp(-0.02 - ea * 0.06, Math.sin(e.walkPhase - 0.3) * 0.26, ew) - ec * 0.34,
        15,
        dt,
      );
      e.rig.rightAnkle.rotation.x = THREE.MathUtils.damp(
        e.rig.rightAnkle.rotation.x,
        THREE.MathUtils.lerp(-0.02 - ea * 0.06, -Math.sin(e.walkPhase - 0.3) * 0.26, ew) - ec * 0.28,
        15,
        dt,
      );

      e.rig.bodyGroup.position.y = THREE.MathUtils.damp(
        e.rig.bodyGroup.position.y,
        Math.abs(eCos) * (isHeavy ? 0.028 : 0.045) * ew - ea * 0.045 - ec * 0.24,
        15,
        dt,
      );
      e.rig.bodyGroup.rotation.y = THREE.MathUtils.damp(
        e.rig.bodyGroup.rotation.y,
        -ea * 0.14 + flinchPulse * 0.14 * e.flinchSide,
        14,
        dt,
      );
      e.rig.bodyGroup.rotation.z = THREE.MathUtils.damp(
        e.rig.bodyGroup.rotation.z,
        eSin * (isHeavy ? 0.02 : 0.034) * ew + flinchPulse * 0.08 * e.flinchSide,
        13,
        dt,
      );

      const eBreath = Math.sin(this.worldTime * (2.2 + ew * 1.4) + e.id);
      e.rig.upperBodyGroup.position.y = 0.94 + eBreath * 0.007;
      e.rig.upperBodyGroup.rotation.x = THREE.MathUtils.damp(
        e.rig.upperBodyGroup.rotation.x,
        (eSprinting ? 0.18 : isRusher ? 0.12 : 0.055) * ew +
          ec * 0.24 +
          ea * 0.075 -
          e.recoil * 0.1 -
          flinchPulse * (e.flinchHead ? 0.26 : 0.16),
        16,
        dt,
      );
      e.rig.upperBodyGroup.rotation.y = THREE.MathUtils.damp(
        e.rig.upperBodyGroup.rotation.y,
        ea * 0.14 - eSin * (ea > 0.4 ? 0.025 : 0.11) * ew + flinchPulse * 0.22 * e.flinchSide,
        15,
        dt,
      );
      e.rig.upperBodyGroup.rotation.z = THREE.MathUtils.damp(
        e.rig.upperBodyGroup.rotation.z,
        THREE.MathUtils.clamp(e.yawRate * 0.024, -0.09, 0.09) + flinchPulse * 0.14 * e.flinchSide,
        14,
        dt,
      );

      e.rig.headGroup.rotation.y = THREE.MathUtils.damp(
        e.rig.headGroup.rotation.y,
        -(e.rig.upperBodyGroup.rotation.y + e.rig.bodyGroup.rotation.y) * 0.68 +
          THREE.MathUtils.clamp(eYawDiff * 0.22, -0.24, 0.24) +
          (e.flinchHead ? flinchPulse * 0.34 * e.flinchSide : 0),
        16,
        dt,
      );
      e.rig.headGroup.rotation.x = THREE.MathUtils.damp(
        e.rig.headGroup.rotation.x,
        -e.rig.upperBodyGroup.rotation.x * 0.52 - (e.flinchHead ? flinchPulse * 0.42 : 0),
        16,
        dt,
      );
      e.rig.hairTuft.rotation.x = Math.sin(this.worldTime * (4.0 + actualMoveSpeed * 0.5) + e.id) * (0.02 + ew * 0.035);

      // Clearer weapon posture: raised shoulder-braced aim during bursts, low-ready sprint carry when rushing/moving to cover
      e.rig.weaponPivot.position.y = THREE.MathUtils.damp(
        e.rig.weaponPivot.position.y,
        0.24 + ea * 0.045 - eSprinting * 0.045 - e.coverCrouch * 0.04,
        16,
        dt,
      );
      e.rig.weaponPivot.position.z = THREE.MathUtils.damp(
        e.rig.weaponPivot.position.z,
        0.22 - e.recoil * 0.075 + ea * 0.035 - eSprinting * 0.02,
        22,
        dt,
      );
      e.rig.weaponPivot.rotation.x = THREE.MathUtils.damp(
        e.rig.weaponPivot.rotation.x,
        -e.recoil * 0.2 + (ea > 0.3 ? -0.05 * ea : (eSprinting ? 0.2 : 0.05) * ew) + Math.abs(eCos) * 0.022 * ew,
        20,
        dt,
      );
      e.rig.weaponPivot.rotation.y = THREE.MathUtils.damp(
        e.rig.weaponPivot.rotation.y,
        -eSprinting * 0.28 - e.coverCrouch * 0.22,
        15,
        dt,
      );
      e.rig.leftArm.position.z = THREE.MathUtils.damp(e.rig.leftArm.position.z, -e.recoil * 0.035, 20, dt);
      e.rig.leftArm.position.y = THREE.MathUtils.damp(e.rig.leftArm.position.y, Math.abs(eCos) * 0.01 * ew + ea * 0.015, 16, dt);

      // Update enemy flowing scarf / headband tails / warrior shoulder shawl
      e.rig.updateCloth(dt, this.worldTime, actualMoveSpeed, e.yawRate, 0.22);

      // Combat firing with tactical bursts ONLY when on-foot, safe timer expired, peeking/open, AND clear line-of-sight!
      const canEngage =
        !playerProtectedInBus &&
        e.postLandingSafeTimer <= 0 &&
        hasLOS &&
        !isDuckingCover;
      if (canEngage) {
        if (e.burstRemaining > 0) {
          e.rig.telegraphGlow.visible = false;
          e.burstDelay -= dt;
          if (e.burstDelay <= 0) {
            this.fireEnemyShot(e, dist);
            e.burstRemaining--;
            e.burstDelay = isHeavy ? 0.26 : isRusher ? 0.18 : 0.22;
            if (e.burstRemaining <= 0) {
              e.fireCooldown = isHeavy
                ? 1.7
                : isRusher
                  ? 1.2
                  : Math.max(1.15, 1.9 - this.wave * 0.055);
            }
          }
        } else if (e.telegraphTimer > 0) {
          e.telegraphTimer -= dt;
          e.rig.telegraphGlow.visible = true;
          const pulse = 0.8 + (1 - e.telegraphTimer / 0.45) * 0.72;
          e.rig.telegraphGlow.scale.setScalar(pulse);
          if (e.telegraphTimer <= 0) {
            e.rig.telegraphGlow.visible = false;
            this.fireEnemyShot(e, dist);
            // Short 2-3 round tactical bursts feel much closer to real mobile shooter engagements
            e.burstRemaining = isHeavy ? 2 : 1;
            e.burstDelay = isHeavy ? 0.26 : isRusher ? 0.18 : 0.22;
          }
        } else {
          e.fireCooldown -= dt;
          if (e.fireCooldown <= 0) {
            e.telegraphTimer = isHeavy ? 0.52 : 0.38;
          }
        }
      } else {
        e.rig.telegraphGlow.visible = false;
        e.telegraphTimer = 0;
        e.burstRemaining = 0;
      }
    }
  }

  private findCoverSpotForEnemy(e: ActiveEnemy): boolean {
    const ex = e.rig.root.position.x;
    const ez = e.rig.root.position.z;
    const hx = this.heroPos.x;
    const hz = this.heroPos.z;
    const colliders = this.world.circleColliders;
    const bounds = this.world.playableBounds;

    let bestScore = Infinity;
    let bestX = 0;
    let bestZ = 0;
    let found = false;

    for (let i = 0; i < colliders.length; i++) {
      const c = colliders[i];
      if (c.height < 1.15 || c.radius < 0.45) continue;

      const dEnemyX = c.x - ex;
      const dEnemyZ = c.z - ez;
      const dEnemySq = dEnemyX * dEnemyX + dEnemyZ * dEnemyZ;
      if (dEnemySq < 4.0 || dEnemySq > 18.0 * 18.0) continue;

      const fromHeroX = c.x - hx;
      const fromHeroZ = c.z - hz;
      const fromHeroDist = Math.hypot(fromHeroX, fromHeroZ);
      if (fromHeroDist < 6.5 || fromHeroDist > e.fireRange + 3.0) continue;

      // Shelter point directly behind obstacle away from the player
      const standOff = c.radius + e.radius + 0.5;
      const spotX = c.x + (fromHeroX / fromHeroDist) * standOff;
      const spotZ = c.z + (fromHeroZ / fromHeroDist) * standOff;

      if (
        spotX < bounds.minX + 2 ||
        spotX > bounds.maxX - 2 ||
        spotZ < bounds.minZ + 2 ||
        spotZ > bounds.maxZ - 2 ||
        this.world.isWaterBlocked(spotX, spotZ)
      ) {
        continue;
      }

      // Skip spots already claimed by another living enemy
      let occupied = false;
      for (let j = 0; j < this.enemies.length; j++) {
        const o = this.enemies[j];
        if (o === e || o.dying || !o.hasCoverSpot) continue;
        const odx = o.coverX - spotX;
        const odz = o.coverZ - spotZ;
        if (odx * odx + odz * odz < 4.5) {
          occupied = true;
          break;
        }
      }
      if (occupied) continue;

      const dEnemy = Math.sqrt(dEnemySq);
      const idealHeroDist = e.archetype === 'heavy' ? 12.0 : 14.0;
      const score = dEnemy + Math.abs(fromHeroDist - idealHeroDist) * 0.65;
      if (score < bestScore) {
        bestScore = score;
        bestX = spotX;
        bestZ = spotZ;
        found = true;
      }
    }

    if (found) {
      e.coverX = bestX;
      e.coverZ = bestZ;
    }
    return found;
  }

  private fireEnemyShot(e: ActiveEnemy, distToHero: number): void {
    // Defense-in-depth: never fire while player is inside/jumping from bus or enemy safe timer active
    if (this.busMode !== 'none' || this.heroJumpingFromBus || e.postLandingSafeTimer > 0) return;

    e.rig.root.updateMatrixWorld(true);
    const muzzleWorld = _v1;
    e.rig.muzzlePoint.getWorldPosition(muzzleWorld);

    const aimTarget = _v2.set(this.heroPos.x, this.heroPos.y + 1.25, this.heroPos.z);
    // Verify clean line of sight from actual weapon muzzle too (never shoot through walls!)
    if (!this.hasLineOfSight(muzzleWorld, aimTarget)) return;

    const dir = _v3.subVectors(aimTarget, muzzleWorld).normalize();

    // Fair dodgeable inaccuracy so movement & cover matter
    const spread = e.archetype === 'heavy' ? 0.055 : 0.08;
    dir.x += (Math.random() - 0.5) * spread;
    dir.y += (Math.random() - 0.5) * 0.032;
    dir.z += (Math.random() - 0.5) * spread;
    dir.normalize();

    const dmg = e.archetype === 'heavy' ? 11 : e.archetype === 'rusher' ? 8 : 8;
    const speed = e.archetype === 'heavy' ? 24 : 28;
    e.recoil = 1.0;
    this.spawnBullet(
      false,
      muzzleWorld,
      dir,
      speed,
      dmg,
      e.rig.root.position.x,
      e.rig.root.position.z,
    );
    this.audio.playEnemyShot(distToHero);
  }

  private updateBullets(dt: number): void {
    for (const b of this.bullets) {
      if (!b.active) continue;
      b.life -= dt;

      // Swept continuous segment [prevPos -> nextPos] prevents tunneling through enemies OR solid walls!
      const prevPos = _v5.copy(b.pos);
      b.pos.addScaledVector(b.vel, dt);
      b.mesh.position.copy(b.pos);

      if (b.life <= 0) {
        b.active = false;
        b.mesh.visible = false;
        continue;
      }

      const obsT = this.segmentFirstObstacleT(prevPos, b.pos, true);

      if (b.fromPlayer) {
        // Find earliest swept hit against separate Head vs Body hitboxes BEFORE any solid wall/obstacle
        let hitEnemy: ActiveEnemy | null = null;
        let hitIsHeadshot = false;
        let bestEnemyT = obsT; // Never hit an enemy behind a wall!

        for (let i = 0; i < this.enemies.length; i++) {
          const e = this.enemies[i];
          if (e.dying || e.busSeatIndex >= 0 || e.jumpingFromBus) continue;
          const s = this.getEnemyScale(e);
          const ex = e.rig.root.position.x;
          const ey = e.rig.root.position.y;
          const ez = e.rig.root.position.z;

          // 1. Separate Head Hitbox (upper cranium & face zone: ey + 1.54*s .. ey + 2.04*s)
          const tHead = this.segmentHitsCylinderT(
            prevPos,
            b.pos,
            ex,
            ez,
            0.39 * s,
            ey + 1.54 * s,
            ey + 2.04 * s,
          );
          if (tHead < bestEnemyT) {
            bestEnemyT = tHead;
            hitEnemy = e;
            hitIsHeadshot = true;
          }

          // 2. Separate Body Hitbox (torso & legs zone: ey + 0.02 .. ey + 1.54*s)
          const tBody = this.segmentHitsCylinderT(
            prevPos,
            b.pos,
            ex,
            ez,
            e.radius + 0.3,
            ey + 0.02,
            ey + 1.54 * s,
          );
          if (tBody < bestEnemyT) {
            bestEnemyT = tBody;
            hitEnemy = e;
            hitIsHeadshot = false;
          }
        }

        if (hitEnemy) {
          _v6.lerpVectors(prevPos, b.pos, bestEnemyT);
          this.damageEnemy(hitEnemy, b.damage, b.vel, hitIsHeadshot, _v6);
          b.active = false;
          b.mesh.visible = false;
          continue;
        }
      } else {
        // Enemy bullet: player is 100% invulnerable while inside or jumping off the WBTC bus!
        if (this.busMode === 'none' && !this.heroJumpingFromBus) {
          const tHero = this.segmentHitsCylinderT(
            prevPos,
            b.pos,
            this.heroPos.x,
            this.heroPos.z,
            0.58,
            this.heroPos.y + 0.05,
            this.heroPos.y + 1.95,
          );
          if (tHero < obsT) {
            this.damagePlayer(b.damage, false, b.sourceX, b.sourceZ);
            b.active = false;
            b.mesh.visible = false;
            continue;
          }
        }
      }

      // If bullet hit a wall, mud house, yellow taxi, tree, cover crate, or WBTC bus hull
      if (obsT <= 1) {
        _v6.lerpVectors(prevPos, b.pos, obsT);
        const sparkColor = this.busMode === 'driving' ? 0xffe082 : 0xd8a872;
        this.spawnParticles(_v6, sparkColor, 5, 3.8);
        this.spawnImpactFlash(_v6, 0xffe6ad, 0.85, 0.11);
        b.active = false;
        b.mesh.visible = false;
      }
    }
  }

  private damageEnemy(
    e: ActiveEnemy,
    baseDmg: number,
    bulletVel: THREE.Vector3,
    isHeadshot = false,
    hitPoint?: THREE.Vector3,
  ): void {
    const finalDmg = isHeadshot ? Math.round(baseDmg * 2.5) : Math.round(baseDmg);
    e.hp -= finalDmg;
    e.hitFlashTimer = 0.105;
    e.rig.flashMaterials.forEach((m) => m.emissive.setHex(isHeadshot ? 0xff2828 : 0xffffff));

    // Crisp head/torso hit-flinch reaction & reactive cover-seeking under fire
    e.flinchTimer = isHeadshot ? 0.24 : 0.16;
    e.flinchHead = isHeadshot;
    e.flinchSide = Math.random() > 0.5 ? 1 : -1;
    if (
      e.hp > 0 &&
      e.archetype !== 'rusher' &&
      e.tacticState !== 'hold_cover' &&
      e.tacticState !== 'seek_cover' &&
      Math.random() < 0.65
    ) {
      if (this.findCoverSpotForEnemy(e)) {
        e.hasCoverSpot = true;
        e.tacticState = 'seek_cover';
        e.tacticTimer = 2.8;
      }
    }

    // Track live Headshot vs Body Shot counters
    if (isHeadshot) {
      this.headshots++;
    } else {
      this.bodyshots++;
    }

    // Spawn animated floating 3D damage number above hit point
    const s = this.getEnemyScale(e);
    const dmgOrigin = hitPoint
      ? hitPoint.clone()
      : new THREE.Vector3(
          e.rig.root.position.x,
          e.rig.root.position.y + (isHeadshot ? 1.85 * s : 1.3 * s),
          e.rig.root.position.z,
        );
    this.spawnFloatingDamage(dmgOrigin, finalDmg, isHeadshot);

    // Squash & stretch impact reaction
    e.rig.bodyGroup.scale.set(s * 1.13, s * 0.89, s * 1.13);

    // Knockback along shot direction
    if (bulletVel.lengthSq() > 0.0001) {
      _v1.copy(bulletVel).setY(0).normalize().multiplyScalar(e.archetype === 'heavy' ? 2.6 : 5.4);
      e.knockback.copy(_v1);
    }

    // Update world-space health bar
    e.rig.hpBarBg.visible = true;
    const ratio = Math.max(0, e.hp / e.maxHp);
    e.rig.hpBarFill.scale.x = Math.max(0.001, ratio);

    // Punchy 3D impact burst ring + directional hit sparks
    this.spawnImpactFlash(
      dmgOrigin,
      isHeadshot ? 0xff2b2b : 0xffe07d,
      isHeadshot ? 2.1 : 1.35,
      isHeadshot ? 0.19 : 0.13,
    );
    this.spawnParticles(dmgOrigin, isHeadshot ? 0xff2424 : 0xff9244, isHeadshot ? 13 : 7, isHeadshot ? 6.2 : 5.2);

    if (e.hp <= 0) {
      e.dying = true;
      e.deathTimer = 0;
      this.kills++;
      const pts =
        (e.archetype === 'heavy' ? 180 : e.archetype === 'rusher' ? 130 : 100) +
        (isHeadshot ? 50 : 0);
      this.score += pts;
      this.checkHighScore();
      this.hitMarker = 1.0;
      this.hitMarkerKill = true;
      this.hitMarkerHeadshot = isHeadshot;
      this.hitstopTimer = isHeadshot ? 0.055 : 0.038;
      this.camShake = Math.min(0.36, this.camShake + (isHeadshot ? 0.17 : 0.12));
      if (isHeadshot) {
        this.audio.playHeadshotPing();
      }
      this.audio.playEnemyHit(true);
      this.spawnParticles(
        _v2.set(e.rig.root.position.x, e.rig.root.position.y + 1.2, e.rig.root.position.z),
        0xffa73b,
        15,
        6.8,
      );

      // Spawn a glowing wooden-and-brass Warrior Loot Chest ('যোদ্ধা সিন্দুক') whenever an enemy is defeated!
      this.spawnWarriorChest(e.rig.root.position.x, e.rig.root.position.z, e.rig.root.rotation.y);
    } else {
      this.hitMarker = isHeadshot ? 0.96 : 0.78;
      this.hitMarkerKill = false;
      this.hitMarkerHeadshot = isHeadshot;
      this.camShake = Math.min(0.24, this.camShake + (isHeadshot ? 0.055 : 0.026));
      if (isHeadshot) {
        this.audio.playHeadshotPing();
      } else {
        this.audio.playEnemyHit(false);
      }
    }
  }

  private damagePlayer(
    dmg: number,
    bypassArmor = false,
    sourceX?: number,
    sourceZ?: number,
  ): void {
    // Player is completely invulnerable while inside or leaping off the WBTC bus
    if (this.busMode !== 'none' || this.heroJumpingFromBus) return;

    // Cancel active Sanjibani healing if struck by an enemy bullet
    if (!bypassArmor && this.isHealing) {
      this.isHealing = false;
      this.pickupToast = 'আঘাতে চিকিৎসা ব্যাহত হয়েছে!';
      this.pickupToastTimer = 1.4;
    }

    let remaining = dmg;
    let armorAbsorbed = false;
    if (!bypassArmor && this.armor > 0) {
      // Raksha Kabach (Body Armor) absorbs incoming bullet damage first!
      const absorbed = Math.min(this.armor, remaining);
      this.armor -= absorbed;
      remaining -= absorbed;
      armorAbsorbed = absorbed > 0 && remaining <= 0;
      this.hero.armorVestOverlay.visible = this.armor > 0;
    }

    if (remaining > 0) {
      this.health = Math.max(0, this.health - remaining);
    }

    this.damageFlash = bypassArmor ? Math.max(this.damageFlash, 0.42) : 0.95;
    if (!bypassArmor) {
      if (sourceX !== undefined && sourceZ !== undefined) {
        this.damageSourcePos.set(sourceX, this.heroPos.y, sourceZ);
        this.hasDamageSource = true;
      }
      this.camShake = Math.min(0.42, this.camShake + (armorAbsorbed ? 0.12 : 0.18));
      this.audio.playPlayerHurt(armorAbsorbed);
    }

    if (this.health <= 0) {
      this.phase = 'gameover';
      this.scopeActive = false;
      this.isHealing = false;
      this.keysHeld.clear();
      this.mouseShootHeld = false;
      this.virtualInput.shooting = false;
      this.safeExitPointerLock();
      this.checkHighScore();
      this.emitHud();
    }
  }

  private updatePickups(dt: number): void {
    for (let i = this.pickups.length - 1; i >= 0; i--) {
      const p = this.pickups[i];
      p.life -= dt;
      if (p.kind !== 'sanjibani') {
        p.mesh.rotation.y += dt * 1.8;
        p.mesh.position.y = p.pos.y + Math.sin(this.worldTime * 3.2 + p.id) * 0.1;
      } else {
        p.mesh.rotation.y += dt * 0.7;
      }

      if (this.busMode === 'none' && !this.heroJumpingFromBus) {
        const distSq = p.pos.distanceToSquared(this.heroPos);
        if (distSq < 1.9 * 1.9) {
          let collected = false;
          if (p.kind === 'sanjibani') {
            if (this.sanjibaniCount < this.maxSanjibani) {
              this.sanjibaniCount++;
              this.sanjibaniCollected++;
              this.pickupToast = `সঞ্জীবনী গাছ +১ (${toBengaliNumber(this.sanjibaniCount)}/${toBengaliNumber(this.maxSanjibani)})`;
              this.audio.playPickup('health');
              collected = true;
            }
          } else if (p.kind === 'armor') {
            if (this.armor < this.maxArmor) {
              this.armor = this.maxArmor;
              this.hero.armorVestOverlay.visible = true;
              this.pickupToast = 'রক্ষা কবচ +৫০';
              this.audio.playPickup('health');
              collected = true;
            }
          } else if (p.kind === 'grenade') {
            if (this.grenadeCount < this.maxGrenades) {
              this.grenadeCount++;
              this.pickupToast = 'বজ্র গোলা +১';
              this.audio.playPickup('ammo');
              collected = true;
            }
          } else {
            const targetW: WeaponType = this.weaponType === 'fala' ? 'agni47' : this.weaponType;
            const meta = WEAPON_CATALOG[targetW];
            const slot = this.weaponSlots[targetW];
            slot.reserve = Math.min(meta.maxReserve, slot.reserve + meta.magSize);
            this.pickupToast = `${meta.shortName} গুলি +${toBengaliNumber(meta.magSize)}`;
            this.audio.playPickup('ammo');
            collected = true;
          }

          if (collected) {
            this.pickupToastTimer = 1.9;
            this.scene.remove(p.mesh);
            this.pickups.splice(i, 1);
            continue;
          }
        }
      }

      if (p.life <= 0) {
        this.scene.remove(p.mesh);
        this.pickups.splice(i, 1);
      }
    }
  }

  private updateChests(dt: number): void {
    let closest: LootChestItem | null = null;
    let closestDistSq = 3.25 * 3.25;

    for (let i = this.chests.length - 1; i >= 0; i--) {
      const c = this.chests[i];
      if (c.opened) {
        c.openProgress = Math.min(1, c.openProgress + dt * 4.5);
        c.rig.lidPivot.rotation.x = -c.openProgress * 1.75;
        c.rig.glowRing.visible = false;
        c.rig.innerGlow.visible = c.openProgress < 0.85;
        c.rig.brassMat.emissiveIntensity = 0.08;
        c.life -= dt * 3.5;
        if (c.life <= 0) {
          this.scene.remove(c.rig.root);
          this.chests.splice(i, 1);
        }
        continue;
      }

      // Subtle warm golden chest shimmer
      const shimmer = 0.55 + Math.sin(this.worldTime * 3.8 + c.id) * 0.25;
      c.rig.brassMat.emissiveIntensity = shimmer;
      c.rig.glowRing.rotation.z = this.worldTime * 0.6;

      if (this.busMode === 'none' && !this.heroJumpingFromBus) {
        const dSq = c.pos.distanceToSquared(this.heroPos);
        if (dSq < closestDistSq) {
          closestDistSq = dSq;
          closest = c;
        }
      }
    }

    this.nearestChest = closest;
    this.nearChest = closest !== null;
  }

  private updateGrenades(dt: number): void {
    for (let i = this.grenades.length - 1; i >= 0; i--) {
      const g = this.grenades[i];
      g.fuseTimer -= dt;

      // Parabolic gravity flight & bounce against ground/obstacles
      g.vel.y -= 21 * dt;
      g.pos.addScaledVector(g.vel, dt);
      const gGround = this.world.getGroundHeight(g.pos.x, g.pos.z, g.pos.y) + 0.16;
      if (g.pos.y < gGround) {
        g.pos.y = gGround;
        g.vel.y = Math.abs(g.vel.y) * 0.38;
        g.vel.x *= 0.68;
        g.vel.z *= 0.68;
      }
      this.resolveCircleWorldCollision(g.pos, 0.22, true);
      g.mesh.position.copy(g.pos);
      g.mesh.rotation.x += dt * 7;
      g.mesh.rotation.z += dt * 5;

      // Blinking fuse spark intensity speeds up near detonation
      const spark = g.mesh.getObjectByName('fuseSpark') as THREE.Mesh | undefined;
      if (spark) {
        const rate = g.fuseTimer < 1.0 ? 28 : 12;
        spark.visible = Math.sin(this.worldTime * rate) > 0;
      }

      if (g.fuseTimer <= 0) {
        this.detonateGrenade(g.pos);
        this.scene.remove(g.mesh);
        this.grenades.splice(i, 1);
      }
    }

    // Animate fiery explosion shockwave rings
    for (let i = this.shockwaves.length - 1; i >= 0; i--) {
      const sw = this.shockwaves[i];
      sw.life -= dt;
      if (sw.life <= 0) {
        this.scene.remove(sw.mesh);
        sw.mesh.geometry.dispose();
        (sw.mesh.material as THREE.Material).dispose();
        this.shockwaves.splice(i, 1);
        continue;
      }
      const p = 1 - sw.life / sw.maxLife;
      const scale = 0.6 + p * 7.5;
      sw.mesh.scale.set(scale, scale, 1);
      (sw.mesh.material as THREE.MeshBasicMaterial).opacity = (1 - p) * 0.85;
    }
  }

  private detonateGrenade(center: THREE.Vector3): void {
    this.audio.playGrenadeExplosion();
    this.camShake = Math.min(0.62, this.camShake + 0.45);
    this.spawnParticles(center, 0xff6e1f, 24, 9.5);
    this.spawnParticles(_v1.set(center.x, center.y + 0.4, center.z), 0xffe066, 14, 7.2);

    // Expanding fiery ground shockwave ring
    const ringGeo = new THREE.RingGeometry(0.65, 1.0, 32);
    const ringMat = new THREE.MeshBasicMaterial({
      color: 0xff8c2b,
      transparent: true,
      opacity: 0.85,
      side: THREE.DoubleSide,
      depthWrite: false,
    });
    const ringMesh = new THREE.Mesh(ringGeo, ringMat);
    ringMesh.rotation.x = -Math.PI / 2;
    ringMesh.position.set(center.x, 0.14, center.z);
    this.scene.add(ringMesh);
    this.shockwaves.push({ mesh: ringMesh, life: 0.42, maxLife: 0.42 });

    // Area damage (7.4m blast radius) to all grounded enemies
    const blastR = 7.4;
    for (const e of this.enemies) {
      if (e.dying || e.busSeatIndex >= 0 || e.jumpingFromBus) continue;
      const dist = e.rig.root.position.distanceTo(center);
      if (dist <= blastR) {
        const falloff = 1 - (dist / blastR) * 0.62;
        const dmg = Math.round(125 * falloff);
        _v4.subVectors(e.rig.root.position, center).setY(0);
        const hitPt = new THREE.Vector3(e.rig.root.position.x, 1.35, e.rig.root.position.z);
        this.damageEnemy(e, dmg, _v4, false, hitPt);
      }
    }
  }

  private updateFloatingDamages(dt: number): void {
    for (let i = this.floatingDamages.length - 1; i >= 0; i--) {
      const fd = this.floatingDamages[i];
      fd.life -= dt;
      if (fd.life <= 0) {
        this.scene.remove(fd.sprite);
        fd.texture.dispose();
        fd.material.dispose();
        this.floatingDamages.splice(i, 1);
        continue;
      }
      const progress = 1 - fd.life / fd.maxLife;
      fd.pos.y += fd.velY * dt * (1 - progress * 0.45);
      fd.sprite.position.copy(fd.pos);
      // Punchy scale-pop on entry then gentle fade out
      const pop = progress < 0.16 ? 0.75 + (progress / 0.16) * 0.4 : 1.15 - progress * 0.2;
      fd.sprite.scale.set(fd.baseScaleX * pop, fd.baseScaleY * pop, 1);
      fd.material.opacity = progress > 0.55 ? 1 - (progress - 0.55) / 0.45 : 1;
    }
  }

  private updateKalboishakhiStorm(dt: number): void {
    this.stormRig.uniforms.uTime.value = this.worldTime;
    this.stormTeleportFlash = Math.max(0, this.stormTeleportFlash - dt * 0.72);

    // Pause storm countdown while still watching the intro WBTC bridge bus ride
    if (this.busMode === 'riding_intro') {
      this.outsideStorm = false;
      this.outsideStormElapsed = 0;
      this.stormDrainTimer = 0;
      return;
    }

    // 4 contraction stages every 90 seconds from huge full-map 550u down to 22u showdown
    const stageRadii = [this.initialStormRadius, 260, 130, 58, 22];

    if (this.stormShrinking) {
      this.stormShrinkElapsed += dt;
      const t = Math.min(1, this.stormShrinkElapsed / this.stormShrinkDuration);
      const ease = t * t * (3 - 2 * t);
      this.stormRadius = THREE.MathUtils.lerp(this.stormStartRadius, this.stormTargetRadius, ease);
      if (t >= 1) {
        this.stormShrinking = false;
        this.stormPhase = Math.min(stageRadii.length, this.stormPhase + 1);
        this.stormCountdown = this.stormPhaseInterval;
      }
    } else if (this.stormPhase < stageRadii.length) {
      this.stormCountdown -= dt;
      if (this.stormCountdown <= 0) {
        this.stormShrinking = true;
        this.stormShrinkElapsed = 0;
        this.stormStartRadius = this.stormRadius;
        this.stormTargetRadius = stageRadii[this.stormPhase];
        this.stormCountdown = 0;
        this.audio.playStormWarning();
        this.waveBanner = 'কালবৈশাখী বলয় সংকুচিত হচ্ছে!';
        this.waveBannerTimer = 2.8;
      }
    }

    this.stormRig.wallMesh.scale.set(this.stormRadius, 1, this.stormRadius);
    this.stormRig.groundRing.scale.set(this.stormRadius, this.stormRadius, 1);

    // Check if player is outside the safe circle
    const checkPos = this.busMode === 'driving' ? this.busPos : this.heroPos;
    const distFromCenter = Math.hypot(
      checkPos.x - this.stormCenter.x,
      checkPos.z - this.stormCenter.y,
    );
    this.outsideStorm = distFromCenter > this.stormRadius;

    if (this.outsideStorm && !this.heroJumpingFromBus) {
      // Ultra-slow minimal HP drain: strictly 1 HP every 5 seconds (max 12 HP over 60 seconds)
      this.outsideStormElapsed += dt;
      this.stormDrainTimer += dt;

      while (this.stormDrainTimer >= 5.0) {
        this.stormDrainTimer -= 5.0;
        if (this.busMode === 'driving') {
          this.health = Math.max(0, this.health - 1);
          this.damageFlash = Math.max(this.damageFlash, 0.22);
          if (this.health <= 0) {
            this.busMode = 'none';
            this.hero.root.visible = true;
            this.damagePlayer(1, true);
            return;
          }
        } else {
          this.health = Math.max(0, this.health - 1);
          this.damageFlash = Math.max(this.damageFlash, 0.22);
          if (this.health <= 0) {
            this.damagePlayer(1, true);
            return;
          }
        }
      }

      // After 60 full seconds outside, Kalboishakhi wind automatically teleports player inside the Safe Zone
      if (this.outsideStormElapsed >= this.outsideStormDuration) {
        this.triggerKalboishakhiTeleport();
      }
    } else {
      // Re-entering the Safe Zone immediately stops drain and resets the 60-second timer
      this.outsideStormElapsed = 0;
      this.stormDrainTimer = 0;
    }
  }

  private triggerKalboishakhiTeleport(): void {
    const departPos = _v2.copy(this.busMode === 'driving' ? this.busPos : this.heroPos);

    // Safely dismount if driving the bus so the wind drops the hero cleanly onto walkable ground
    if (this.busMode === 'driving') {
      this.busMode = 'none';
      this.busSpeed = 0;
      this.hero.root.visible = true;
    }
    this.scopeActive = false;

    const bounds = this.world.playableBounds;
    const safeMaxR = Math.max(3.2, this.stormRadius - 2.4);
    const sampleMaxR = Math.min(safeMaxR, 145);
    const dest = _v3.set(this.stormCenter.x, 0, this.stormCenter.y);

    // Active grounded enemies inside or close to the current safe zone
    const activeEnemies = this.enemies.filter((e) => {
      if (e.dying || e.busSeatIndex >= 0 || e.jumpingFromBus) return false;
      const d = Math.hypot(
        e.rig.root.position.x - this.stormCenter.x,
        e.rig.root.position.z - this.stormCenter.y,
      );
      return d <= this.stormRadius + 4;
    });

    const clampInsideSafeZone = (pt: THREE.Vector3) => {
      pt.x = THREE.MathUtils.clamp(pt.x, bounds.minX + 1.5, bounds.maxX - 1.5);
      pt.z = THREE.MathUtils.clamp(pt.z, bounds.minZ + 1.5, bounds.maxZ - 1.5);
      const dx = pt.x - this.stormCenter.x;
      const dz = pt.z - this.stormCenter.y;
      const d = Math.hypot(dx, dz);
      if (d > safeMaxR && d > 0.001) {
        pt.x = this.stormCenter.x + (dx / d) * safeMaxR;
        pt.z = this.stormCenter.y + (dz / d) * safeMaxR;
      }
      if (this.world.isWaterBlocked(pt.x, pt.z)) {
        pt.z = pt.z > -45.5 ? -18.5 : -74.0;
      }
      this.resolveCircleWorldCollision(pt, 0.62, true);
      pt.y = this.world.getGroundHeight(pt.x, pt.z);
    };

    // 50% chance to drop near an active enemy warrior; 50% chance to drop at a distant safe spot
    const placeNearEnemy = activeEnemies.length > 0 && Math.random() < 0.5;

    if (placeNearEnemy) {
      const targetEnemy = activeEnemies[Math.floor(Math.random() * activeEnemies.length)];
      let bestFound = false;
      for (let attempt = 0; attempt < 12; attempt++) {
        const ang = Math.random() * Math.PI * 2;
        const dist = 5.8 + Math.random() * 3.8;
        dest.set(
          targetEnemy.rig.root.position.x + Math.cos(ang) * dist,
          0,
          targetEnemy.rig.root.position.z + Math.sin(ang) * dist,
        );
        clampInsideSafeZone(dest);
        const finalDistToCenter = Math.hypot(
          dest.x - this.stormCenter.x,
          dest.z - this.stormCenter.y,
        );
        if (finalDistToCenter <= this.stormRadius - 1.2) {
          bestFound = true;
          break;
        }
      }
      if (!bestFound) {
        dest.set(this.stormCenter.x, 0, this.stormCenter.y);
        clampInsideSafeZone(dest);
      }
    } else {
      // Distant quiet location inside the Safe Zone (farthest from active enemies)
      let bestScore = -Infinity;
      const candidate = _v4;
      for (let attempt = 0; attempt < 16; attempt++) {
        const ang = Math.random() * Math.PI * 2;
        const rad = sampleMaxR * (0.2 + Math.sqrt(Math.random()) * 0.72);
        candidate.set(
          this.stormCenter.x + Math.cos(ang) * rad,
          0,
          this.stormCenter.y + Math.sin(ang) * rad,
        );
        clampInsideSafeZone(candidate);

        let nearestEnemyDist = 30;
        for (const e of activeEnemies) {
          const d = Math.hypot(
            candidate.x - e.rig.root.position.x,
            candidate.z - e.rig.root.position.z,
          );
          if (d < nearestEnemyDist) nearestEnemyDist = d;
        }
        const distFromDepart = Math.hypot(candidate.x - departPos.x, candidate.z - departPos.z);
        const score = nearestEnemyDist * 1.4 + Math.min(24, distFromDepart) * 0.45;
        if (score > bestScore) {
          bestScore = score;
          dest.copy(candidate);
        }
      }
    }

    // Swirling departure wind burst
    this.spawnParticles(_v1.set(departPos.x, 1.0, departPos.z), 0x7ceeff, 16, 7.5);
    this.spawnParticles(_v1.set(departPos.x, 1.3, departPos.z), 0xc7a6ff, 12, 6.2);

    // Teleport hero cleanly into the Safe Zone on valid solid terrain
    this.heroPos.copy(dest);
    this.heroPos.y = this.world.getGroundHeight(this.heroPos.x, this.heroPos.z);
    this.hero.root.position.copy(this.heroPos);

    // Swirling arrival wind burst + dust eddy
    this.spawnParticles(_v1.set(this.heroPos.x, 0.9, this.heroPos.z), 0x82f0ff, 20, 8.2);
    this.spawnParticles(_v1.set(this.heroPos.x, 1.2, this.heroPos.z), 0xffe296, 14, 6.5);

    this.stormTeleportFlash = 1.0;
    this.camShake = Math.min(0.62, this.camShake + 0.45);
    this.audio.playStormTeleport();
    this.waveBanner = 'কালবৈশাখী ঝড় আপনাকে উড়িয়ে নিয়ে এসেছে!';
    this.waveBannerTimer = 3.8;

    this.outsideStormElapsed = 0;
    this.stormDrainTimer = 0;
    this.outsideStorm = false;
    this.emitHud();
  }

  private updateParticles(dt: number): void {
    for (const p of this.particles) {
      if (!p.active) continue;
      p.life -= dt;
      if (p.life <= 0) {
        p.active = false;
        p.mesh.visible = false;
        continue;
      }
      p.vel.y -= 14 * dt;
      p.pos.addScaledVector(p.vel, dt);
      if (p.pos.y < 0.05) {
        p.pos.y = 0.05;
        p.vel.y *= -0.35;
      }
      p.mesh.position.copy(p.pos);
      const t = p.life / p.maxLife;
      p.mesh.scale.setScalar(p.scale * t);
    }
  }

  private updateImpactFlashes(dt: number): void {
    for (let i = 0; i < this.impactFlashes.length; i++) {
      const fl = this.impactFlashes[i];
      if (!fl.active) continue;
      fl.life -= dt;
      if (fl.life <= 0) {
        fl.active = false;
        fl.mesh.visible = false;
        continue;
      }
      const p = 1 - fl.life / fl.maxLife;
      const scale = 0.38 + (1 - Math.pow(1 - p, 2)) * fl.maxScale;
      fl.mesh.scale.setScalar(scale);
      fl.mesh.lookAt(this.camera.position);
      fl.material.opacity = (1 - p) * 0.92;
    }
  }

  private checkHighScore(): void {
    if (this.score > this.highScore) {
      this.highScore = this.score;
      try {
        localStorage.setItem(STORAGE_KEY_HIGHSCORE, String(this.highScore));
      } catch {
        // ignore storage errors
      }
    }
  }

  // --- Render Loop with Software-WebGL Pacing ---

  private afterDraw(cb: () => void): void {
    const gl = this.renderer.getContext() as WebGL2RenderingContext;
    const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
    gl.flush();
    const poll = () => {
      if (this.disposed) return;
      const state = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
      if (state === gl.UNSIGNALED) {
        this.frameId = window.setTimeout(poll, 5);
      } else {
        if (sync) gl.deleteSync(sync);
        this.frameId = window.setTimeout(cb, 80);
      }
    };
    this.frameId = window.setTimeout(poll, 5);
  }

  private tick = (): void => {
    if (this.disposed) return;

    const now = performance.now();
    const rawDt = (now - this.lastFrameMs) / 1000;
    this.lastFrameMs = now;
    const dt = Math.min(Math.max(rawDt, 0.001), 0.05);

    this.update(dt);
    this.renderer.render(this.scene, this.camera);

    // Emit HUD snapshot at ~20Hz so React never throttles the 60fps WebGL loop
    this.hudEmitAccum += dt;
    if (this.hudEmitAccum >= 0.05) {
      this.hudEmitAccum = 0;
      this.emitHud();
    }

    if (this.isSoftwareGl) {
      this.afterDraw(this.tick);
    } else {
      this.frameId = requestAnimationFrame(this.tick);
    }
  };

  private emitHud(): void {
    const alive = this.enemies.filter((e) => !e.dying).length;
    const activeSlot = this.weaponSlots[this.weaponType];
    const locPos = this.busMode !== 'none' ? this.busPos : this.heroPos;
    this.onHudUpdate({
      phase: this.phase,
      busMode: this.busMode,
      nearBus: this.nearBus,
      nearChest: this.nearChest,
      busZoneLabel: this.busMode === 'riding_intro' ? this.busZoneLabel : null,
      locationName: this.world.getLocationName(locPos.x, locPos.z, locPos.y),
      busSpeedKmh: Math.round(Math.abs(this.busSpeed) * 3.6),
      busRouteProgress: this.busRouteT,
      busInteriorCam: this.busInteriorCam,
      busExitSlowing: this.busExitSlowing,
      health: Math.ceil(this.health),
      maxHealth: this.maxHealth,
      armor: Math.ceil(this.armor),
      maxArmor: this.maxArmor,
      activeWeapon: this.weaponType,
      weapons: {
        agni47: { ...this.weaponSlots.agni47 },
        kalbhairav: { ...this.weaponSlots.kalbhairav },
        trishul: { ...this.weaponSlots.trishul },
        fala: { ...this.weaponSlots.fala },
      },
      scopeActive: this.scopeActive,
      ammo: activeSlot.ammo,
      maxAmmo: activeSlot.maxAmmo,
      reserveAmmo: activeSlot.reserve,
      isReloading: this.isReloading,
      reloadProgress: this.isReloading
        ? 1 - Math.max(0, this.reloadTimer / Math.max(0.01, this.reloadDuration))
        : 1,
      sanjibaniCount: this.sanjibaniCount,
      sanjibaniCollected: this.sanjibaniCollected,
      maxSanjibani: this.maxSanjibani,
      isHealing: this.isHealing,
      healProgress: this.isHealing
        ? 1 - Math.max(0, this.healTimer / this.healDuration)
        : 0,
      grenadeCount: this.grenadeCount,
      maxGrenades: this.maxGrenades,
      headshots: this.headshots,
      bodyshots: this.bodyshots,
      stormPhase: this.stormPhase,
      stormCountdown: Math.ceil(this.stormCountdown),
      stormShrinking: this.stormShrinking,
      outsideStorm: this.outsideStorm,
      outsideStormRemaining: this.outsideStorm
        ? Math.max(0, Math.ceil(this.outsideStormDuration - this.outsideStormElapsed))
        : this.outsideStormDuration,
      stormTeleportFlash: this.stormTeleportFlash,
      stormRadius: Math.round(this.stormRadius),
      score: this.score,
      highScore: this.highScore,
      kills: this.kills,
      wave: this.wave,
      enemiesRemaining: alive + this.waveEnemiesToSpawn.length,
      waveBanner: this.waveBanner,
      damageFlash: this.damageFlash,
      damageAngle: this.damageAngle,
      hitMarker: this.hitMarker,
      hitMarkerKill: this.hitMarkerKill,
      hitMarkerHeadshot: this.hitMarkerHeadshot,
      reticleSpread: this.reticleSpread,
      muted: this.audio.isMuted(),
      sprintRatio: this.sprintStamina,
      pickupToast: this.pickupToast,
    });
  }

  // --- Event Listeners ---

  private onKeyDown = (e: KeyboardEvent): void => {
    if (['Space', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(e.code)) {
      e.preventDefault();
    }

    if (this.phase === 'title' && (e.code === 'Enter' || e.code === 'Space')) {
      this.startGame();
      return;
    }

    if (e.code === 'Escape' || e.code === 'KeyP') {
      if (this.phase === 'playing' || this.phase === 'paused') {
        this.togglePause();
      }
      return;
    }

    if (this.phase !== 'playing') return;

    // Bus Jump/Exit, Re-Enter, OR Open Warrior Loot Chest ('F')
    if (e.code === 'KeyF') {
      if (this.busMode !== 'none') {
        this.exitBus();
      } else if (this.nearChest) {
        this.openNearestChest();
      } else if (this.nearBus) {
        this.enterBus();
      }
      return;
    }
    if (e.code === 'Space' && this.busMode === 'riding_intro') {
      this.exitBus();
      return;
    }
    if ((e.code === 'KeyV' || e.code === 'KeyC') && this.busMode === 'riding_intro') {
      this.toggleBusCameraView();
      return;
    }
    if (e.code === 'KeyH' && this.busMode !== 'none') {
      this.honkBusHorn();
      return;
    }

    // Battle Royale Quick-Switch Weapons (1-4), Scope (X), Sanjibani Heal (H/V), Bajra Gola (G)
    if (this.busMode === 'none') {
      if (e.code === 'Digit1') {
        this.setWeaponType('agni47');
        return;
      }
      if (e.code === 'Digit2') {
        this.setWeaponType('kalbhairav');
        return;
      }
      if (e.code === 'Digit3') {
        this.setWeaponType('trishul');
        return;
      }
      if (e.code === 'Digit4') {
        this.setWeaponType('fala');
        return;
      }
      if (e.code === 'KeyG') {
        this.throwGrenade();
        return;
      }
      if (e.code === 'KeyH' || e.code === 'KeyV') {
        this.useSanjibani();
        return;
      }
      if (e.code === 'KeyX') {
        this.toggleScope();
        return;
      }
    }

    this.keysHeld.add(e.code);
    if (e.code === 'KeyR') {
      this.attemptStartReload();
    }
    if (e.code === 'KeyM') {
      this.toggleMute();
    }
  };

  private onKeyUp = (e: KeyboardEvent): void => {
    this.keysHeld.delete(e.code);
  };

  private onWindowBlur = (): void => {
    this.keysHeld.clear();
    this.mouseShootHeld = false;
    this.dragLookActive = false;
    this.dragPointerId = null;
    this.activeTouchPointers.clear();
    this.lastPinchDist = null;
    this.lobbyDragActive = false;
    this.lobbyDragPointerId = null;
    this.virtualInput.shooting = false;
  };

  private onPointerDown = (e: PointerEvent): void => {
    if (e.target !== this.renderer.domElement) return;

    // Free Fire-style lobby: drag left/right to rotate the 3D Bengali hero
    if (this.phase === 'title') {
      this.lobbyDragActive = true;
      this.lobbyDragPointerId = e.pointerId;
      this.lobbyLastDragX = e.clientX;
      return;
    }

    if (this.phase !== 'playing') return;
    this.audio.unlock();

    if (e.pointerType === 'mouse') {
      if (e.button === 2 && this.busMode === 'none') {
        this.toggleScope();
        return;
      }
      if (e.button === 0) {
        this.mouseShootHeld = true;
      }
      // Allow smooth mouse drag camera turning on left or right button
      this.dragLookActive = true;
      this.dragPointerId = e.pointerId;
      this.lastDragX = e.clientX;
      this.lastDragY = e.clientY;
    } else {
      // Track active canvas touches for smooth single-finger look AND 2-finger mobile pinch-to-zoom
      this.activeTouchPointers.set(e.pointerId, { x: e.clientX, y: e.clientY });
      if (this.activeTouchPointers.size === 2) {
        this.dragLookActive = false;
        this.dragPointerId = null;
        const pts = Array.from(this.activeTouchPointers.values());
        this.lastPinchDist = Math.hypot(pts[0].x - pts[1].x, pts[0].y - pts[1].y);
      } else if (this.activeTouchPointers.size === 1) {
        this.lastPinchDist = null;
        this.dragLookActive = true;
        this.dragPointerId = e.pointerId;
        this.lastDragX = e.clientX;
        this.lastDragY = e.clientY;
      }
    }
  };

  private onPointerMove = (e: PointerEvent): void => {
    if (this.phase === 'title') {
      if (this.lobbyDragActive && e.pointerId === this.lobbyDragPointerId) {
        const dx = e.clientX - this.lobbyLastDragX;
        this.lobbyLastDragX = e.clientX;
        this.lobbyHeroTargetYaw += dx * 0.011;
      }
      return;
    }

    if (this.phase !== 'playing') return;

    if (document.pointerLockElement === this.renderer.domElement) {
      const lookMult = this.scopeActive
        ? this.getScopeLookFactor()
        : this.getGeneralLookFactor();
      this.camYaw -= e.movementX * 0.0032 * lookMult;
      this.camPitch = THREE.MathUtils.clamp(
        this.camPitch + e.movementY * 0.0024 * lookMult,
        -0.12,
        0.65,
      );
      return;
    }

    // Mobile 2-finger pinch-to-zoom on canvas
    if (e.pointerType !== 'mouse' && this.activeTouchPointers.has(e.pointerId)) {
      this.activeTouchPointers.set(e.pointerId, { x: e.clientX, y: e.clientY });
      if (this.activeTouchPointers.size === 2 && this.busMode === 'none') {
        const pts = Array.from(this.activeTouchPointers.values());
        const dist = Math.hypot(pts[0].x - pts[1].x, pts[0].y - pts[1].y);
        if (this.lastPinchDist !== null) {
          const delta = dist - this.lastPinchDist;
          // Spread fingers -> zoom in (lower FOV); pinch closer -> zoom out (wider FOV)
          this.pinchFovOffset = THREE.MathUtils.clamp(
            this.pinchFovOffset - delta * 0.14,
            -26,
            10,
          );
          if (!this.scopeActive && this.pinchFovOffset <= -18) {
            this.scopeActive = true;
            this.pinchFovOffset = 0;
            this.emitHud();
          } else if (this.scopeActive && this.pinchFovOffset >= 8) {
            this.scopeActive = false;
            this.pinchFovOffset = 0;
            this.emitHud();
          }
        }
        this.lastPinchDist = dist;
        return;
      }
    }

    if (this.dragLookActive && e.pointerId === this.dragPointerId) {
      const dx = e.clientX - this.lastDragX;
      const dy = e.clientY - this.lastDragY;
      this.lastDragX = e.clientX;
      this.lastDragY = e.clientY;
      this.virtualInput.lookDeltaX += dx;
      this.virtualInput.lookDeltaY += dy;
    }
  };

  private onPointerUp = (e: PointerEvent): void => {
    if (e.pointerId === this.lobbyDragPointerId) {
      this.lobbyDragActive = false;
      this.lobbyDragPointerId = null;
    }
    if (e.pointerType === 'mouse' && e.button === 0) {
      this.mouseShootHeld = false;
    }
    if (this.activeTouchPointers.has(e.pointerId)) {
      this.activeTouchPointers.delete(e.pointerId);
      if (this.activeTouchPointers.size < 2) {
        this.lastPinchDist = null;
      }
      if (this.activeTouchPointers.size === 1) {
        const [remainingId, pt] = Array.from(this.activeTouchPointers.entries())[0];
        this.dragLookActive = true;
        this.dragPointerId = remainingId;
        this.lastDragX = pt.x;
        this.lastDragY = pt.y;
      }
    }
    if (e.pointerId === this.dragPointerId && !this.activeTouchPointers.has(e.pointerId)) {
      this.dragLookActive = false;
      this.dragPointerId = null;
    }
  };

  private onContextMenu = (e: MouseEvent): void => {
    if (this.phase === 'playing') {
      e.preventDefault();
    }
  };

  private onResize = (): void => {
    const w = this.container.clientWidth || window.innerWidth;
    const h = Math.max(1, this.container.clientHeight || window.innerHeight);
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
    this.renderer.setPixelRatio(this.getPixelRatioCap());
    this.renderer.setSize(w, h, false);
  };

  private onOrientationOrFullscreenChange = (): void => {
    this.onResize();
    if (this.orientationResizeTimer !== null) {
      window.clearTimeout(this.orientationResizeTimer);
    }
    this.orientationResizeTimer = window.setTimeout(() => {
      if (!this.disposed) this.onResize();
    }, 120);
  };

  private bindEvents(): void {
    window.addEventListener('keydown', this.onKeyDown);
    window.addEventListener('keyup', this.onKeyUp);
    window.addEventListener('blur', this.onWindowBlur);
    window.addEventListener('resize', this.onResize);
    window.addEventListener('orientationchange', this.onOrientationOrFullscreenChange);
    document.addEventListener('fullscreenchange', this.onOrientationOrFullscreenChange);
    document.addEventListener('webkitfullscreenchange', this.onOrientationOrFullscreenChange);
    window.visualViewport?.addEventListener('resize', this.onResize);
    if (typeof ResizeObserver !== 'undefined') {
      this.resizeObserver = new ResizeObserver(() => this.onResize());
      this.resizeObserver.observe(this.container);
    }
    this.renderer.domElement.addEventListener('pointerdown', this.onPointerDown);
    window.addEventListener('pointermove', this.onPointerMove);
    window.addEventListener('pointerup', this.onPointerUp);
    window.addEventListener('pointercancel', this.onPointerUp);
    this.renderer.domElement.addEventListener('contextmenu', this.onContextMenu);
  }

  public dispose(): void {
    this.disposed = true;
    cancelAnimationFrame(this.frameId);
    clearTimeout(this.frameId);
    if (this.orientationResizeTimer !== null) {
      window.clearTimeout(this.orientationResizeTimer);
      this.orientationResizeTimer = null;
    }
    if (this.resizeObserver) {
      this.resizeObserver.disconnect();
      this.resizeObserver = null;
    }

    window.removeEventListener('keydown', this.onKeyDown);
    window.removeEventListener('keyup', this.onKeyUp);
    window.removeEventListener('blur', this.onWindowBlur);
    window.removeEventListener('resize', this.onResize);
    window.removeEventListener('orientationchange', this.onOrientationOrFullscreenChange);
    document.removeEventListener('fullscreenchange', this.onOrientationOrFullscreenChange);
    document.removeEventListener('webkitfullscreenchange', this.onOrientationOrFullscreenChange);
    window.visualViewport?.removeEventListener('resize', this.onResize);
    this.renderer.domElement.removeEventListener('pointerdown', this.onPointerDown);
    window.removeEventListener('pointermove', this.onPointerMove);
    window.removeEventListener('pointerup', this.onPointerUp);
    window.removeEventListener('pointercancel', this.onPointerUp);
    this.renderer.domElement.removeEventListener('contextmenu', this.onContextMenu);

    this.scene.traverse((obj) => {
      if ((obj as THREE.Mesh).isMesh) {
        const mesh = obj as THREE.Mesh;
        mesh.geometry?.dispose();
        if (Array.isArray(mesh.material)) {
          mesh.material.forEach((m) => m.dispose());
        } else {
          mesh.material?.dispose();
        }
      }
    });

    this.textures.disposeAll();
    this.audio.dispose();
    this.renderer.dispose();
    if (this.renderer.domElement.parentNode === this.container) {
      this.container.removeChild(this.renderer.domElement);
    }
  }
}
